rootProject.name = "MusicPlay"
include(":app")
