<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = (int)$_SESSION['user_id'];

// Single optimized query with ambiguous columns fixed
$sql = "SELECT 
    /* Current user data */
    cu.username AS current_username, 
    cu.profile_pic AS current_profile_pic, 
    cu.verified AS current_verified,
    cu.premium AS current_premium,
    
    /* Connected user data */
    u.id AS connected_id,
    u.username AS connected_username,
    u.profile_pic AS connected_profile_pic,
    u.verified AS connected_verified,
    u.premium AS connected_premium,
    s.peer_id,
    
    /* Friend request status */
    fr.id AS friend_request_id,
    fr.status AS friend_request_status,
    fr.sender_id = ? AS is_sender,
    
    /* Matching interests - now explicitly using ui1.tag_name */
    (SELECT GROUP_CONCAT(ui1.tag_name) 
     FROM user_interests ui1
     JOIN user_interests ui2 ON ui1.tag_name = ui2.tag_name
     WHERE ui1.user_id = ? AND ui2.user_id = u.id) AS matching_interests
    
FROM users cu
LEFT JOIN chat_connections cc ON 
    (cc.user1_id = ? OR cc.user2_id = ?) AND 
    (cc.user1_id = ? OR cc.user2_id = ?) AND
    (cc.user1_id != cc.user2_id)
LEFT JOIN users u ON u.id = CASE 
    WHEN cc.user1_id = ? THEN cc.user2_id 
    WHEN cc.user2_id = ? THEN cc.user1_id 
END
LEFT JOIN status s ON u.id = s.user_id
LEFT JOIN friend_requests fr ON 
    ((fr.sender_id = ? AND fr.receiver_id = u.id) OR 
     (fr.sender_id = u.id AND fr.receiver_id = ?)) AND
    fr.status IN ('pending', 'accepted')
WHERE cu.id = ?
LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiiiiiiiiii", 
    $user_id, $user_id, 
    $user_id, $user_id, $user_id, $user_id,
    $user_id, $user_id,
    $user_id, $user_id,
    $user_id
);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

// Process the fetched data
$current_user = [
    'username' => $data['current_username'] ?? null,
    'profile_pic' => $data['current_profile_pic'] ?? 'assets/default_dp.png',
    'verified' => $data['current_verified'] ?? 0,
    'premium' => $data['current_premium'] ?? 0
];

$connected_user = null;
if (!empty($data['connected_id'])) {
    $connected_user = [
        'id' => $data['connected_id'],
        'username' => $data['connected_username'],
        'profile_pic' => $data['connected_profile_pic'] ?? 'assets/default_dp.png',
        'verified' => $data['connected_verified'],
        'premium' => $data['connected_premium'],
        'peer_id' => $data['peer_id']
    ];
}

// Determine friend request status
$friend_request_accepted = ($data['friend_request_status'] ?? '') === 'accepted';
$friend_request_pending = ($data['friend_request_status'] ?? '') === 'pending';
$is_receiver = $friend_request_pending && !($data['is_sender'] ?? false);
$pending_request_id = $friend_request_pending ? ($data['friend_request_id'] ?? null) : null;

// Check image upload permission
$show_image_upload = ($current_user['premium'] == 1 || ($connected_user && $connected_user['premium'] == 1));

// Process matching interests
$matching_interests = [];
if (!empty($data['matching_interests'])) {
    $matching_interests = explode(',', $data['matching_interests']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chat</title>
<!-- Bootstrap - Always latest -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome - Always latest -->
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css" rel="stylesheet">
<style>
    body {
    background-color: #fafafa;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
}
#chat-container {
    width: 100%;
    max-width: 600px; 
    margin: 0 auto;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    height: 100vh;
    background-color: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
#header {
    width: 100%;
    padding: 10px 15px; 
    text-align: center;
    background-color: #fff;
    border-bottom: 1px solid #dbdbdb;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    box-sizing: border-box;
}
.back-btn {
    background: transparent;
    border: none;
    color: var(--text-dark);
    font-size: 20px;
    cursor: pointer;
    padding: 8px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    transition: all 0.3s;
}
.back-btn:hover {
    background-color: #f0f0f0;
}
.user-info {
    display: flex;
    align-items: center;
    gap: 10px;
}
.profile-pic {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
}
.username {
    font-weight: 600;
    font-size: 14px;
    max-width: 150px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    display: inline-block;
    vertical-align: middle;
}
.verified-badge {
    width: 12px;
    height: 12px;
}
#status-message {
    padding: 8px 15px;
    font-size: 12px;
    color: #8e8e8e;
    text-align: center;
    background-color: #fafafa;
    border-bottom: 1px solid #dbdbdb;
    width: 100%;
    box-sizing: border-box;
}
#chat-box {
    flex: 1;
    overflow-y: auto; 
    padding: 15px;
    background-color: #fafafa;
    background-image: url('assets/chat-bg.png');
    background-size: cover;
    background-attachment: fixed;
    display: flex;
    flex-direction: column;
    width: 100%;
    margin-bottom: 50px;
    box-sizing: border-box;
}

#input-area {
    width: 100%;
    max-width: 600px;
    display: flex; 
    align-items: center; 
    padding: 10px 15px;
    background-color: #fff;
    border-top: 1px solid #dbdbdb;
    position: fixed;
    bottom: 0;
    box-sizing: border-box;
    gap: 4px;
}
.input-wrapper {
    flex: 1;
    position: relative;
    display: flex;
    align-items: center;
}
#message-input {
    width: 100%;
    padding: 10px 45px 10px 15px;
    border-radius: 20px;
    border: 1px solid #dbdbdb;
    background-color: #fafafa;
    font-size: 14px;
    outline: none;
    box-sizing: border-box;
}
#send-btn {
    position: absolute;
    right: 8px;
    top: 50%;
    transform: translateY(-50%);
    background: #0095f6;
    color: white;
    border: none;
    border-radius: 15px;
    padding: 5px 12px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}

#send-btn:hover {
    background: #0077cc;
}

#skip-btn {
    background: red;
    color: white;
    border: none;
    border-radius: 15px;
    padding: 5px 12px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}
#skip-btn:hover {
    background-color: #fafafa;
}
#file-upload-btn {
    margin-right: 10px;
    color: #262626;
    background: none;
    border: none;
    cursor: pointer;
}

/* Message Styles */
.message {
    margin: 5px 0;
    padding: 8px 16px;
    border-radius: 18px;
    max-width: 70%;
    min-width: 40px;
    width: fit-content;
    word-wrap: break-word;
    font-size: 14px;
    line-height: 1.4;
    position: relative;
    box-sizing: border-box;
    transition: transform 0.2s ease, opacity 0.2s ease;
}
.message[data-length="1"],
.message[data-length="2"] {
    padding: 8px 12px;
}
.received {
    background-color: #fff;
    border: 1px solid #dbdbdb;
    align-self: flex-start;
    margin-right: auto;
    border-bottom-left-radius: 4px;
}
.sent {
    background-color: #0095f6;
    color: white;
    align-self: flex-end;
    margin-left: auto;
    border-bottom-right-radius: 4px;
}
.message-time {
    font-size: 10px;
    color: #8e8e8e;
    margin-top: 4px;
    text-align: right;
}
.received .message-time {
    color: #8e8e8e;
}
.sent .message-time {
    color: rgba(255,255,255,0.7);
}

/* Action Button Styles */
.action-btn {
    background: none;
    border: none;
    color: #0095f6;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    padding: 5px 10px;
    border-radius: 4px;
}
.action-btn:hover {
    background-color: #fafafa;
}

/* Image Message Styles */
.message img {
    max-width: 100%;
    height: auto;
    border-radius: 12px;
    margin-bottom: 4px;
}
.sent img {
    border: 2px solid #0095f6;
}
.received img {
    border: 2px solid #dbdbdb;
}

/* Friend Status Styles */
.friend-status {
    font-size: 12px;
    color: #8e8e8e;
    margin-left: 5px;
    font-weight: normal;
}
.friend-status.friends {
    color: #0095f6;
    font-weight: bold;
}

/* Loading States */
.temp-message {
    opacity: 0.7;
}
.progress-text {
    font-size: 10px;
    color: #8e8e8e;
    margin-top: 4px;
}
.loading-spinner {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 3px solid rgba(0,0,0,.1);
    border-radius: 50%;
    border-top-color: #0095f6;
    animation: spin 1s ease-in-out infinite;
}
@keyframes spin {
    to { transform: rotate(360deg); }
}
</style>
</head>
<body>
<div id="chat-container">
<div id="header">
<button class="back-btn" onclick="history.back()">
                <i class="fas fa-arrow-left"></i>
            </button>
    <div class="user-info">
        <?php if ($connected_user): ?>
            <!-- Show connected user's details -->
            <img src="<?= htmlspecialchars($connected_user['profile_pic'] ?? 'assets/default_dp.png') ?>" class="profile-pic" alt="Profile">
            <span class="username"><?= htmlspecialchars($connected_user['username'] ?? 'User') ?></span>
            <?php if ($connected_user['verified'] == 1): ?>
                <img src="assets/verified.png" class="verified-badge" alt="Verified">
            <?php endif; ?>
            
            <!-- Friend status indicator -->
            <?php if ($friend_request_accepted): ?>
                <span class="friend-status friends">Friend</span>
            <?php elseif ($friend_request_pending): ?>
                <?php if ($is_receiver): ?>
                    <button id="accept-friend-btn" class="action-btn">Accept Request</button>
                <?php else: ?>
                    <span class="friend-status">Request Sent</span>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>
            <!-- Show current user's details when not connected -->
            <img src="<?= htmlspecialchars($current_user['profile_pic'] ?? 'assets/default-profile.png') ?>" class="profile-pic" alt="Profile">
            <span class="username"><?= htmlspecialchars($current_user['username'] ?? 'User') ?></span>
            <?php if ($current_user['verified'] == 1): ?>
                <img src="assets/verified.png" class="verified-badge" alt="Verified">
            <?php endif; ?>
        <?php endif; ?>
    </div>
    
    <!-- Friend request button (only shown when appropriate) -->
    <?php if ($connected_user && !$friend_request_accepted && !$friend_request_pending): ?>
        <button id="add-friend-btn" class="action-btn">Add Friend</button>
    <?php endif; ?>
</div>
    
    <div id="status-message">
        <?php if ($connected_user): ?>
            <span>Connected with <?= htmlspecialchars($connected_user['username']) ?></span>
            <?php if (!empty($matching_interests)): ?>
                <br><small>Common interests: <?= implode(', ', array_map('htmlspecialchars', $matching_interests)) ?></small>
            <?php endif; ?>
        <?php else: ?>
            <span>Looking for someone to chat with...</span>
        <?php endif; ?>
    </div>
    
    <div id="chat-box"></div>
    
    <div id="input-area">
        <?php if (isset($show_image_upload) && $show_image_upload): ?>
            <button id="file-upload-btn"><i class="fas fa-paperclip"></i></button>
            <input type="file" id="file-upload" accept="image/*" style="display: none;">
        <?php endif; ?>
        <div class="input-wrapper">
            <input type="text" id="message-input" placeholder="Message...">
            <button id="send-btn" class="action-btn">Send</button>
        </div>
        <button id="skip-btn" class="action-btn">Skip</button>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/peerjs@latest/dist/peerjs.min.js"></script>
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.18.0/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const chatApp = {
    peer: null,
    conn: null,
    isReconnecting: false,
    receivedChunks: {},
    imageMetadata: {},
    
    init: function() {
        this.fetchExistingPeerId().then(() => {
            this.initPeerConnection();
            this.setupEventListeners();
        });
    },
    
    fetchExistingPeerId: function() {
        return fetch('update_chatstatus.php?get_peer_id=1')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success' && data.data.peer_id) {
                    localStorage.setItem('myPeerId', data.data.peer_id);
                }
            })
            .catch(error => {
                console.error('Error fetching peer ID:', error);
            });
    },
    
    initPeerConnection: function() {
        if (this.isReconnecting) return;
        
        const peerConfig = {
            config: {
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' },
                    { urls: 'stun:stun1.l.google.com:19302' }
                ]
            },
            debug: 1
        };
        
        // Use existing peer ID from localStorage or let PeerJS generate one
        this.peer = new Peer(localStorage.getItem('myPeerId') || undefined, peerConfig);
        
        this.peer.on('open', id => {
            // Only store in localStorage, don't update in database
            localStorage.setItem('myPeerId', id);
            this.updateStatus('online');
            
            <?php if ($connected_user && isset($connected_user['peer_id'])): ?>
                this.connectToPeer('<?= $connected_user['peer_id'] ?>');
            <?php endif; ?>
        });
        
        this.peer.on('connection', conn => {
            if (this.conn && this.conn.open) {
                conn.close();
                return;
            }
            this.conn = conn;
            this.setupConnectionHandlers();
            this.updateUIStatus('Connected!');
        });
        
        this.peer.on('error', this.handlePeerError.bind(this));
    },
    
    connectToPeer: function(peerId) {
        if (!peerId) return;
        
        if (this.conn) this.conn.close();
        
        this.conn = this.peer.connect(peerId, {
            reliable: true,
            serialization: 'json'
        });
        
        this.setupConnectionHandlers();
        this.updateUIStatus('Connecting...');
    },
    
    setupConnectionHandlers: function() {
        if (!this.conn) return;
        
        this.conn.on('open', () => {
            this.updateUIStatus('Connected!');
            this.startConnectionMonitoring();
        });
        
        this.conn.on('data', this.handleIncomingData.bind(this));
        this.conn.on('close', this.handleConnectionClose.bind(this));
        this.conn.on('error', this.handleConnectionError.bind(this));
    },
    
    updateStatus: function(status) {
        fetch('update_chatstatus.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `status=${encodeURIComponent(status)}`
        }).catch(error => {
            console.error('Error updating status:', error);
        });
    },
    
    handleIncomingData: function(data) {
        if (data.type === 'image-metadata') {
            this.imageMetadata = data;
            this.receivedChunks[data.messageId] = {
                chunks: [],
                total: data.totalChunks
            };
            this.addTempMessage(data.filename, 'receiving');
        } 
        else if (data.type === 'image-chunk') {
            this.processImageChunk(data);
        } 
        else {
            this.addMessage(data, 'received');
        }
    },
    
    processImageChunk: function(chunkData) {
        const messageId = chunkData.messageId;
        if (!this.receivedChunks[messageId]) return;
        
        this.receivedChunks[messageId].chunks[chunkData.chunkIndex] = chunkData.data;
        
        if (this.receivedChunks[messageId].chunks.length === this.imageMetadata.totalChunks) {
            const imageData = {
                type: 'image',
                data: this.receivedChunks[messageId].chunks.join(''),
                filename: this.imageMetadata.filename,
                width: this.imageMetadata.width,
                height: this.imageMetadata.height
            };
            
            this.removeTempMessages(this.imageMetadata.filename);
            this.addMessage(imageData, 'received');
            delete this.receivedChunks[messageId];
        }
    },
    
    sendMessage: function() {
        const input = document.getElementById('message-input');
        const message = input.value.trim();
        
        if (message && this.conn?.open) {
            this.conn.send(message);
            this.addMessage(message, 'sent');
            input.value = '';
        }
    },
    
    sendImage: function(file) {
        if (!this.conn?.open) {
            Swal.fire('Error', 'Not connected', 'error');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = e => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                canvas.width = Math.min(img.width, 800);
                canvas.height = Math.min(img.height, 800);
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                
                canvas.toBlob(blob => {
                    const reader = new FileReader();
                    reader.onload = e => {
                        const imgData = {
                            type: 'image',
                            data: e.target.result,
                            filename: file.name,
                            width: canvas.width,
                            height: canvas.height
                        };
                        
                        const tempMsg = this.addTempMessage(file.name, 'sending');
                        this.conn.send(imgData);
                        this.removeTempMessages(file.name);
                        this.addMessage(imgData, 'sent');
                    };
                    reader.readAsDataURL(blob);
                }, 'image/jpeg', 0.7);
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    },
    
    addMessage: function(content, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        
        if (typeof content === 'object' && content.type === 'image') {
            const img = document.createElement('img');
            img.src = content.data;
            img.style.maxWidth = '200px';
            img.style.maxHeight = '300px';
            messageDiv.appendChild(img);
        } else {
            messageDiv.textContent = content;
        }
        
        document.getElementById('chat-box').appendChild(messageDiv);
        this.scrollChatToBottom();
    },
    
    addTempMessage: function(content, type) {
        const div = document.createElement('div');
        div.className = `message temp-message ${type}`;
        div.textContent = type === 'sending' ? 'Sending image...' : 'Receiving image...';
        div.dataset.filename = content;
        document.getElementById('chat-box').appendChild(div);
        this.scrollChatToBottom();
        return div;
    },
    
    removeTempMessages: function(filename) {
        document.querySelectorAll(`.temp-message[data-filename="${filename}"]`)
            .forEach(el => el.remove());
    },
    
    scrollChatToBottom: function() {
        const chatBox = document.getElementById('chat-box');
        chatBox.scrollTop = chatBox.scrollHeight;
    },
    
    updateUIStatus: function(text) {
        document.getElementById('status-message').textContent = text;
    },
    
    handlePeerError: function(err) {
        if (err.type === 'unavailable-id') {
            localStorage.removeItem('myPeerId');
            this.reconnect(true);
        }
    },
    
    handleConnectionClose: function() {
        this.updateUIStatus('Disconnected');
        this.updateStatus('offline');
        Swal.fire('Disconnected', 'Connection closed', 'info')
            .then(() => this.reconnect());
    },
    
    handleConnectionError: function(err) {
        this.updateUIStatus('Connection error');
        Swal.fire('Error', err.message || 'Connection error', 'error');
    },
    
    reconnect: function(forceNew = false) {
        if (this.isReconnecting) return;
        this.isReconnecting = true;
        
        if (this.conn) this.conn.close();
        if (this.peer) this.peer.destroy();
        if (forceNew) localStorage.removeItem('myPeerId');
        
        setTimeout(() => {
            this.initPeerConnection();
            this.isReconnecting = false;
        }, forceNew ? 1000 : 3000);
    },
    
    setupEventListeners: function() {
        document.getElementById('send-btn').addEventListener('click', () => this.sendMessage());
        document.getElementById('message-input').addEventListener('keypress', e => {
            if (e.key === 'Enter') this.sendMessage();
        });
        
        <?php if ($show_image_upload): ?>
            document.getElementById('file-upload-btn').addEventListener('click', () => {
                document.getElementById('file-upload').click();
            });
            
            document.getElementById('file-upload').addEventListener('change', e => {
                const file = e.target.files[0];
                if (file?.type.match('image.*')) this.sendImage(file);
                e.target.value = '';
            });
        <?php endif; ?>
        
        <?php if ($connected_user && !$friend_request_accepted && !$friend_request_pending): ?>
            document.getElementById('add-friend-btn').addEventListener('click', this.sendFriendRequest.bind(this));
        <?php endif; ?>
        
        <?php if ($connected_user && $friend_request_pending && $is_receiver): ?>
            document.getElementById('accept-friend-btn').addEventListener('click', this.acceptFriendRequest.bind(this));
        <?php endif; ?>
        
        document.getElementById('skip-btn').addEventListener('click', this.skipConnection.bind(this));
        
        window.addEventListener('beforeunload', () => {
            this.updateStatus('offline');
            if (this.conn) this.conn.close();
            if (this.peer) this.peer.destroy();
        });
    },
    
    sendFriendRequest: function() {
        fetch('send_friend_request.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `receiver_id=${<?= $connected_user['id'] ?? 'null' ?>}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', 'Friend request sent', 'success');
                document.getElementById('add-friend-btn').textContent = 'Request Sent';
            } else {
                Swal.fire('Error', data.message || 'Failed', 'error');
            }
        })
        .catch(error => {
            Swal.fire('Error', 'Request failed', 'error');
        });
    },
    
    acceptFriendRequest: function() {
        fetch('accept_friend_request.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `request_id=${<?= $pending_request_id ?? 'null' ?>}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success', 'You are now friends', 'success');
                document.getElementById('accept-friend-btn').textContent = 'Friends';
            } else {
                Swal.fire('Error', data.message || 'Failed', 'error');
            }
        })
        .catch(error => {
            Swal.fire('Error', 'Request failed', 'error');
        });
    },
    
    skipConnection: function() {
        Swal.fire({
            title: 'Skip chat?',
            text: "Find someone new to chat with?",
            icon: 'question',
            showCancelButton: true
        }).then(result => {
            if (result.isConfirmed) {
                fetch('skip.php', { method: 'POST' })
                    .finally(() => location.reload());
            }
        });
    }
};

// Initialize when ready
document.addEventListener('DOMContentLoaded', () => chatApp.init());
</script>
</body>
</html>