<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die(json_encode(['status' => 'error', 'message' => 'User not logged in']));
}

$user_id = $_SESSION['user_id'];

// GET request to fetch current status
if (isset($_GET['get_status'])) {
    $stmt = $conn->prepare("SELECT active_status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($current_status);
    $stmt->fetch();
    $stmt->close();
    
    echo $current_status;
    exit();
}

// POST request to update status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle sendBeacon FormData
    if (isset($_POST['status'])) {
        $new_status = (int)$_POST['status'];
    } else {
        die(json_encode(['status' => 'error', 'message' => 'No status provided']));
    }

    // First get current status from database
    $stmt = $conn->prepare("SELECT active_status FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($current_status);
    $stmt->fetch();
    $stmt->close();

    // Only update if current status is 0 or 1 (not 2 or 3)
    if ($current_status === 0 || $current_status === 1) {
        $stmt = $conn->prepare("UPDATE users SET active_status = ?, last_activity = NOW() WHERE id = ?");
        $stmt->bind_param("ii", $new_status, $user_id);
        
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Status updated']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Update failed']);
        }
        $stmt->close();
    } else {
        echo json_encode(['status' => 'success', 'message' => 'Status not updated (current status is protected)']);
    }
    exit();
}

echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
?>