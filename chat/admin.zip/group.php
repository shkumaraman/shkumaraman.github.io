<?php
session_start();
include 'db.php';

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if user is premium
$sql_premium = "SELECT premium FROM users WHERE id = ?";
$stmt_premium = $conn->prepare($sql_premium);
$stmt_premium->bind_param("i", $user_id);
$stmt_premium->execute();
$result_premium = $stmt_premium->get_result();
$is_premium = $result_premium->fetch_assoc()['premium'] == 1;

// Get current user's peer ID
$sql_peer = "SELECT peer_id FROM status WHERE user_id = ?";
$stmt_peer = $conn->prepare($sql_peer);
$stmt_peer->bind_param("i", $user_id);
$stmt_peer->execute();
$result_peer = $stmt_peer->get_result();
$current_user_peer_id = $result_peer->num_rows > 0 ? $result_peer->fetch_assoc()['peer_id'] : null;

// Get all active users in the group
$sql_users = "SELECT u.id, u.username, u.profile_pic, u.verified, s.peer_id 
              FROM users u
              LEFT JOIN status s ON u.id = s.user_id
              WHERE u.id IN (SELECT DISTINCT sender_id FROM group_chat) OR u.id = ?";
$stmt_users = $conn->prepare($sql_users);
$stmt_users->bind_param("i", $user_id);
$stmt_users->execute();
$result_users = $stmt_users->get_result();
$group_members = [];
while ($row = $result_users->fetch_assoc()) {
    $group_members[$row['id']] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Chat</title>
    <!-- Bootstrap CSS (Always latest 5.x) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS (Always latest) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --online-color: #4CAF50;
            --offline-color: #e0e0e0;
            --card-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s ease;
        }

        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            background-color: var(--card-bg);
            color: var(--text-dark);
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: var(--card-shadow);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
        }

        .back-btn:hover {
            background-color: rgba(0, 0, 0, 0.05);
        }

        .chat-container {
            width: 100%;
            max-width: 600px;
            margin: auto;
            background: white;
            height: 90vh;
            display: flex;
            flex-direction: column;
        }

        .chat-box {
            flex: 1;
            overflow-y: auto;
            padding: 10px;
            background: #fff;
            margin: 50px 0 50px 0;
            display: flex;
            flex-direction: column;
        }

        .chat-message {
            margin: 5px 0;
            padding: 8px 16px;
            border-radius: 18px;
            max-width: 70%;
            min-width: 40px;
            width: fit-content;
            word-wrap: break-word;
            font-size: 14px;
            line-height: 1.4;
            position: relative;
            box-sizing: border-box;
        }

        .received {
            background-color: #fff;
            border: 1px solid #dbdbdb;
            align-self: flex-start;
            margin-right: auto;
            border-bottom-left-radius: 4px;
        }

        .sent {
            background-color: #0095f6;
            color: white;
            align-self: flex-end;
            margin-left: auto;
            border-bottom-right-radius: 4px;
        }

        #input-area {
            width: 100%;
            max-width: 600px;
            display: flex; 
            align-items: center; 
            padding: 10px 15px;
            background-color: #fff;
            border-top: 1px solid #dbdbdb;
            position: fixed;
            bottom: 0;
            box-sizing: border-box;
        }

        #message-input {
            width: 100%;
            padding: 10px 70px 10px 15px;
            border-radius: 20px;
            border: 1px solid #dbdbdb;
            background-color: #fafafa;
            font-size: 14px;
            outline: none;
            box-sizing: border-box;
        }

        #send-btn {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: #0095f6;
            color: white;
            border: none;
            border-radius: 15px;
            padding: 5px 12px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
        }

        #new-message-indicator {
            position: fixed;
            bottom: 70px;
            left: 50%;
            transform: translateX(-50%);
            background: #075e54;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            display: none;
            z-index: 1000;
        }

        .user-info {
            display: flex;
            align-items: center;
            margin-bottom: 2px;
        }

        .user-avatar {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 5px;
        }

        .username {
            font-size: 12px;
            font-weight: 500;
        }

        .verified-badge {
            width: 12px;
            height: 12px;
            margin-left: 3px;
        }

        .message-time {
            font-size: 10px;
            text-align: right;
            margin-top: 2px;
            color: #666;
        }

        .chat-image {
            max-width: 100%;
            max-height: 200px;
            border-radius: 10px;
            margin-top: 5px;
        }

        #media-btn {
            margin-right: 10px;
            color: #262626;
            background: none;
            border: none;
            cursor: pointer;
        }

        #media-input {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Group Chat</h4>
        <div style="width: 40px;"></div>
    </div>
    
    <div class="chat-container">
        <!-- Chat Box -->
        <div class="chat-box" id="chat-box">
            <!-- Messages will be loaded here via AJAX -->
        </div>

        <!-- New Messages Button -->
        <div id="new-message-indicator" onclick="scrollToBottom()">
            New Messages ↓
        </div>
    </div>
        <!-- Chat Footer -->
        <div id="input-area">
        <?php if($is_premium): ?>
                <button id="media-btn" title="Send Image">
                    <i class="fas fa-paperclip fa-lg"></i>
                </button>
                <input type="file" id="media-input" accept="image/*">
         <?php endif; ?>
            <input type="text" id="message-input" placeholder="Type a message...">
            <button id="send-btn" class="action-btn">
                Send
            </button>
        </div>
        
    <script src="https://cdn.jsdelivr.net/npm/peerjs@latest/dist/peerjs.min.js"></script>
    <script src="https://code.jquery.com/jquery-latest.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.18.0/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>

    <script>
    $(document).ready(function () {
        const chatBox = $("#chat-box");
        const messageInput = $("#message-input");
        const newMessageIndicator = $("#new-message-indicator");
        let isUserAtBottom = true;
        
        let peer;
        let connections = {};
        
        // Function to update active_status
        function sendHeartbeat(status) {
            $.ajax({
                url: "update_status.php",
                method: "POST",
                data: { status: status },
                success: function (response) {
                    console.log("Status updated to", status, "Server Response:", response);
                },
                error: function (xhr, status, error) {
                    console.error("Error updating status: " + error);
                }
            });
        }

        // Set status to active (1) when page loads
        sendHeartbeat(1);

        // Handle tab visibility change
        document.addEventListener('visibilitychange', function () {
            if (document.visibilityState === 'hidden') {
                // Tab is hidden - set inactive
                sendHeartbeat(0);
            } else {
                // Tab is visible again - set active
                sendHeartbeat(1);
            }
        });

        // Handle page unload (user closes the tab or navigates away)
        window.addEventListener('beforeunload', function () {
            const formData = new FormData();
            formData.append("status", "0");
            navigator.sendBeacon("update_status.php", formData);
        });
        
        function initializePeerJS() {
            peer = new Peer('<?= $current_user_peer_id ?>', {
                debug: 2,
                config: {
                    'iceServers': [
                        { url: 'stun:stun.l.google.com:19302' },
                        { url: 'stun:stun1.l.google.com:19302' },
                        { url: 'stun:stun2.l.google.com:19302' }
                    ]
                }
            });
            
            peer.on('open', function(id) {
                console.log('My peer ID is: ' + id);
                
                <?php foreach($group_members as $member_id => $member): ?>
                    <?php if($member_id != $user_id && !empty($member['peer_id'])): ?>
                        connectToPeer('<?= $member['peer_id'] ?>');
                    <?php endif; ?>
                <?php endforeach; ?>
            });
            
            peer.on('connection', function(connection) {
                setupConnectionHandlers(connection);
            });
        }
        
        function connectToPeer(peerId) {
            if (connections[peerId]) return;
            
            const conn = peer.connect(peerId, {
                reliable: true,
                serialization: 'json'
            });
            
            setupConnectionHandlers(conn);
            connections[peerId] = conn;
        }
        
        function setupConnectionHandlers(conn) {
            conn.on('open', function() {
                console.log('Connected to: ' + conn.peer);
            });
            
            conn.on('data', function(data) {
                if (data.type === 'group_message') {
                    addMessageToChat(data.sender_id, data.message, data.timestamp, false, data.media);
                }
            });
        }
        
        function broadcastMessage(message, media = null) {
            const messageData = {
                type: 'group_message',
                sender_id: <?= $user_id ?>,
                message: message,
                timestamp: new Date().toISOString(),
                media: media
            };
            
            Object.values(connections).forEach(conn => {
                if (conn.open) {
                    conn.send(messageData);
                }
            });
        }
        
        function addMessageToChat(senderId, message, timestamp, isSent, media = null) {
            const member = <?= json_encode($group_members) ?>[senderId];
            const username = member ? member.username.substring(0, 10) : 'Unknown';
            const profilePic = member?.profile_pic ? 'uploads/'+member.profile_pic : 'assets/default_dp.png';
            const verifiedBadge = member?.verified == 1 ? 
                '<img src="assets/verified.png" class="verified-badge" alt="✓">' : '';
            
            const messageClass = isSent ? 'sent' : 'received';
            const messageTime = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
            
            let mediaElement = '';
            if (media) {
                mediaElement = `<img src="uploads/${media}" class="chat-image" alt="Sent image">`;
            }
            
            const messageElement = `
                <div class="chat-message ${messageClass}">
                    ${!isSent ? `
                    <div class="user-info">
                        <img src="${profilePic}" class="user-avatar">
                        <span class="username">${username}</span>
                        ${verifiedBadge}
                    </div>
                    ` : ''}
                    <div>${message}</div>
                    ${mediaElement}
                    <div class="message-time" style="text-align: ${isSent ? 'right' : 'left'}">
                        ${messageTime}
                    </div>
                </div>
            `;
            
            chatBox.append(messageElement);
            
            if (isUserAtBottom) {
                scrollToBottom();
            } else {
                newMessageIndicator.show();
            }
        }

        function fetchMessages() {
            $.ajax({
                url: "fetch_gc.php",
                type: "GET",
                success: function (response) {
                    const wasAtBottom = isUserAtBottom;
                    chatBox.html(response);

                    if (wasAtBottom) {
                        scrollToBottom();
                    }
                }
            });
        }

        function sendMessage() {
    const message = messageInput.val().trim();

    if (message) {
        broadcastMessage(message);
        addMessageToChat(<?= $user_id ?>, message, new Date().toISOString(), true);
        messageInput.val("");
        
        $.ajax({
            url: "send_gc.php",
            type: "POST",
            data: { 
                message: message
            },
            dataType: 'json', // Expect JSON response
            success: function(response) {
                if (!response.success) {
                    console.error('Error sending message:', response.error);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    }
}

  function sendMedia(file) {
    if (!file) return;
    
    // Check if file is an image
    if (!file.type.match('image.*')) {
        Swal.fire('Error', 'Only image files are allowed', 'error');
        return;
    }
    
    // Show loading indicator
    const swal = Swal.fire({
        title: 'Uploading...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    const formData = new FormData();
    formData.append('media', file);
    formData.append('message', 'Image shared');
    
    $.ajax({
        url: 'send_gc.php',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json', // Expect JSON response
        success: function(response) {
            swal.close();
            if (response.success) {
                broadcastMessage(response.message, response.filename);
                addMessageToChat(<?= $user_id ?>, response.message, new Date().toISOString(), true, response.filename);
            } else {
                Swal.fire('Error', response.error || 'Failed to send image', 'error');
            }
        },
        error: function(xhr, status, error) {
            swal.close();
            Swal.fire('Error', 'Failed to send image: ' + error, 'error');
        }
    });
}

        function scrollToBottom() {
            chatBox.scrollTop(chatBox[0].scrollHeight);
            newMessageIndicator.hide();
        }

        // Event listeners
        $("#send-btn").click(sendMessage);
        messageInput.keypress(function (e) {
            if (e.which === 13) sendMessage();
        });

        <?php if($is_premium): ?>
            $("#media-btn").click(function() {
                $("#media-input").click();
            });
            
            $("#media-input").change(function() {
                if (this.files && this.files[0]) {
                    sendMedia(this.files[0]);
                    this.value = ''; // Reset input
                }
            });
        <?php endif; ?>

        chatBox.on("scroll", function () {
            isUserAtBottom = chatBox.scrollTop() + chatBox.innerHeight() >= chatBox[0].scrollHeight - 10;
        });

        initializePeerJS();
        fetchMessages();
        setInterval(fetchMessages, 10000);
    });
    </script>
</body>
</html>