<?php
session_start();
include 'db.php'; // Database connection

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user details including premium status
$sql_user = "SELECT username, email, profile_pic, active_status, verified, premium, premium_expiry, gender FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user = $result_user->fetch_assoc();

// Update user information
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];

    $status = $_POST['status'];
    // Map status to active_status (1 and 0 for auto, 2 for online, 3 for offline)
    if ($status === 'auto') {
        $active_status = ($user['active_status'] == 1 || $user['active_status'] == 0) ? 1 : 0;
    } elseif ($status === 'online') {
        $active_status = 2;  // Manual Online
    } elseif ($status === 'offline') {
        $active_status = 3;  // Manual Offline
    }

    // Password update
    if (!empty($_POST['password']) && $_POST['password'] === $_POST['confirm_password']) {
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $sql_password = "UPDATE users SET password = ? WHERE id = ?";
        $stmt_password = $conn->prepare($sql_password);
        $stmt_password->bind_param("si", $password, $user_id);
        $stmt_password->execute();
    } else if (!empty($_POST['password'])) {
        $errors[] = "Passwords do not match.";
    }

    // Update profile picture
    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/";
        $imageFileType = strtolower(pathinfo($_FILES["profile_pic"]["name"], PATHINFO_EXTENSION));
        $allowed_types = ["jpg", "png", "jpeg", "gif"];

        // Check file type
        if (in_array($imageFileType, $allowed_types)) {
            // Generate random filename with dp_ prefix
            $random_string = bin2hex(random_bytes(8)); // 16 character random string
            $new_filename = "dp_" . $random_string . "." . $imageFileType;
            $target_file = $target_dir . $new_filename;

            if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                // Delete old profile picture if it exists and isn't the default
                if (!empty($user['profile_pic']) && $user['profile_pic'] !== 'assets/default_dp.png') {
                    @unlink($user['profile_pic']);
                }
                
                $sql_pic = "UPDATE users SET profile_pic = ? WHERE id = ?";
                $stmt_pic = $conn->prepare($sql_pic);
                $stmt_pic->bind_param("si", $target_file, $user_id);
                $stmt_pic->execute();
            } else {
                $errors[] = "There was an error uploading the file.";
            }
        } else {
            $errors[] = "Invalid file type. Only JPG, PNG, JPEG, or GIF are allowed.";
        }
    }

    // Update username, email, active_status, verified, and gender
    if (empty($errors)) {
        // Set verified status based on the form input
        $verified = isset($_POST['verified']) ? (int)$_POST['verified'] : $user['verified']; // Use the submitted value or keep the current value

        // Update the user details
        $sql_update = "UPDATE users SET username = ?, email = ?, active_status = ?, verified = ?, gender = ? WHERE id = ?";
        $stmt_update = $conn->prepare($sql_update);
        $stmt_update->bind_param("ssiisi", $username, $email, $active_status, $verified, $gender, $user_id);

        // Execute the query and check for errors
        if ($stmt_update->execute()) {
            $_SESSION['success'] = "Profile updated successfully!";
            header("Location: settings.php");
            exit();
        } else {
            error_log("SQL Error: " . $stmt_update->error);
            $errors[] = "Failed to update profile. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Settings</title>
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
          :root {
            --bg-color: #ffffff;
            --text-color: #121212;
            --card-bg: #f8f9fa;
            --border-color: #e0e0e0;
            --primary-color: #4361ee;
            --hover-color: #f0f0f0;
        }
         body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;          
           }
        .container {
            max-width: 600px;
            margin-top: 80px;
            padding: 0;
        }
        .form-group {
            margin-bottom: 15px;
            padding: 0 16px;
        }
        .form-control {
            padding: 12px;
            background-color: #fafafa;
            border: 1px solid #dbdbdb;
            border-radius: 6px;
        }
        .form-control:focus {
            background-color: white;
            border-color: #b2b2b2;
            box-shadow: none;
        }
        .btn-upload {
            margin: 15px 0;
            background-color: #0095f6;
            border: none;
            border-radius: 4px;
            color: white;
            font-weight: 600;
            padding: 8px;
        }
        
        .radio-group {
            display: flex;
            gap: 10px;
        }
        .radio-group label {
            display: inline-block;
            padding: 8px 16px;
            background-color: #f0f0f0;
            border: 1px solid #dbdbdb;
            border-radius: 20px;
            color: #262626;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        .radio-group input[type="radio"],
        .radio-group input[type="checkbox"] {
            display: none;
        }
        .radio-group input[type="radio"]:checked + label,
        .radio-group input[type="checkbox"]:checked + label {
            background-color: #0095f6;
            color: white;
            border-color: #0095f6;
        }
        .profile-info {
            display: flex;
            align-items: center;
            margin: 20px 16px;
            padding-bottom: 20px;
            border-bottom: 1px solid #dbdbdb;
        }
        .profile-pic-container {
            width: 80px;
            height: 80px;
        }
        .profile-pic {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 1px solid #dbdbdb;
        }
        .status {
            margin-left: 20px;
        }
        .badge {
            font-size: 14px;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 4px;
        }
        .badge.bg-success {
            background-color: #0095f6 !important;
        }
        label {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 8px;
            display: block;
            color: #262626;
        }
        h4 {
            font-weight: 600;
            font-size: 16px;
            margin: 0;
        }
        .text-muted {
            font-size: 12px;
            color: #8e8e8e;
            margin-top: 4px;
        }
.profile-photo-upload .form-group {
  margin: 20px 0;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.profile-photo-upload .file-upload {
  position: relative;
  display: inline-block;
}

.profile-photo-upload .file-upload-btn {
  border: 1px solid #dbdbdb;
  color: #0095f6;
  background-color: white;
  padding: 6px 12px;
  border-radius: 4px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  position: relative;
  z-index: 1;
}

.profile-photo-upload .file-input {
  position: absolute;
  left: 0;
  top: 0;
  opacity: 0;
  height: 100%;
  width: 100%;
  cursor: pointer;
  z-index: 2;
}

.preview img {
  width: 80px;
  max-width: 100px;
  border-radius: 5px;
  border: 1px solid #ccc;
  margin-top: 10px;
}
    </style>
</head>
<body>
<?php include('menu.php'); ?>
<div class="container">
    <form method="POST" enctype="multipart/form-data">
        <div class="profile-info">
            <div class="profile-pic-container">
                <?php if (!empty($user['profile_pic'])): ?>
                    <img src="<?= $user['profile_pic'] ?>" class="profile-pic" alt="Profile Picture">
                <?php else: ?>
                    <img src="assets/default_dp.png" class="profile-pic" alt="Profile Picture">
                <?php endif; ?>
            </div>
            <div class="status">
                <?php if ($user['premium'] == 1): ?>
                    <span class="badge bg-success">Premium</span>
                    <p class="text-muted">Expiry: <?= date("d M Y", strtotime($user['premium_expiry'])) ?></p>
                <?php else: ?>
                    <span class="badge bg-secondary">Free</span>
                <?php endif; ?>
            </div>
        </div>
        
<div class="profile-photo-upload">
  <div class="form-group">
    <label for="profile_pic">Change Profile Photo</label>
    <div class="file-upload">
      <input type="file" name="profile_pic" id="profile_pic" class="file-input" accept="image/*">
      <button type="button" class="file-upload-btn">Select Image</button>
    </div>
    <div class="preview">
      <img id="imagePreview" src="#" alt="Image Preview" style="display: none;">
    </div>
  </div>
</div>

        <div class="form-group">
            <label for="username">Name</label>
            <input type="text" name="username" class="form-control" value="<?= $user['username'] ?>" required>
        </div>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" name="email" class="form-control" value="<?= $user['email'] ?>" required>
        </div>

        <div class="form-group">
            <label>Gender</label>
            <div class="radio-group">
                <input type="radio" name="gender" value="Male" id="male" <?= $user['gender'] == 'Male' ? 'checked' : '' ?>>
                <label for="male">Male</label>

                <input type="radio" name="gender" value="Female" id="female" <?= $user['gender'] == 'Female' ? 'checked' : '' ?>>
                <label for="female">Female</label>
            </div>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" class="form-control" placeholder="Enter new password">
        </div>

        <div class="form-group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password">
        </div>

        <div class="form-group">
            <label>Status</label>
            <div class="radio-group">
                <input type="radio" name="status" value="auto" id="auto" <?= $user['active_status'] == 1 || $user['active_status'] == 0 ? 'checked' : '' ?>>
                <label for="auto">Auto</label>

                <input type="radio" name="status" value="online" id="online" <?= $user['active_status'] == 2 ? 'checked' : '' ?>>
                <label for="online">Online</label>

                <input type="radio" name="status" value="offline" id="offline" <?= $user['active_status'] == 3 ? 'checked' : '' ?>>
                <label for="offline">Offline</label>
            </div>
        </div>

        <!-- Verified Toggle -->
        <?php if ($user['premium'] != 0): ?>
    <div class="form-group">
        <label>Verification Status</label>
        <div class="radio-group">
            <input type="radio" name="verified" value="1" id="verified" <?= $user['verified'] == 1 ? 'checked' : '' ?>>
            <label for="verified">Verified</label>

            <input type="radio" name="verified" value="0" id="unverified" <?= $user['verified'] == 0 ? 'checked' : '' ?>>
            <label for="unverified">Unverified</label>
        </div>
    </div>
<?php endif; ?>

        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-upload w-100">Update Profile</button>
        </div>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Update file upload button text when file is selected
    document.getElementById('profile_pic').addEventListener('change', function(e) {
        var fileName = e.target.files[0] ? e.target.files[0].name : "Select Image";
        document.querySelector('.file-upload-btn').textContent = fileName;
    });
    
  const input = document.getElementById('profile_pic');
  const preview = document.getElementById('imagePreview');

  input.addEventListener('change', function() {
    const file = this.files[0];
    if (file && file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = function(e) {
        preview.src = e.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(file);
    } else {
      preview.style.display = 'none';
      preview.src = '#';
    }
  });

</script>
</body>
</html>