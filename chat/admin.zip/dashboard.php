<?php
include('init.php');
include('db.php');

// Check if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Fetch maintenance status from the settings table
$sql = "SELECT maintenance FROM settings LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $maintenance = $row['maintenance'];

    // Redirect to maintenance.html if maintenance mode is enabled
    if ($maintenance == 1) {
        header('Location: maintenance.html');
        exit();
    }
}

// Get user info (username and premium status)
$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = $user_id";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

// Check if user gender is set
$showGenderPopup = false;
if (empty($user['gender'])) {
    $showGenderPopup = true;
}

// Handle gender submission from popup
if (isset($_POST['select_gender'])) {
    $selectedGender = $_POST['select_gender'];
    $conn->query("UPDATE users SET gender = '$selectedGender' WHERE id = $user_id");
    header("Location: dashboard.php");
    exit();
}

// Fetch existing gender and tags for the user
$gender = 'Both';
$tags = [];

$fetchInterestsQuery = "SELECT gender, tag_name FROM user_interests WHERE user_id = $user_id";
$interestsResult = $conn->query($fetchInterestsQuery);

if ($interestsResult->num_rows > 0) {
    while ($row = $interestsResult->fetch_assoc()) {
        $gender = $row['gender'];
        if ($row['tag_name']) {
            $tags[] = $row['tag_name'];
        }
    }
}

// Fetch Instagram and Telegram links from the settings table
$sql = "SELECT instagram, telegram FROM settings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $settings = $result->fetch_assoc();
    $instagramLink = $settings['instagram'];
    $telegramLink = $settings['telegram'];
} else {
    $instagramLink = '#';
    $telegramLink = '#';
}

// Handle form submission for gender and tags
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['gender'])) {
    $gender = $_POST['gender'];
    $tags = isset($_POST['tags']) ? explode(',', $_POST['tags']) : [];

    $conn->query("UPDATE user_interests SET gender = '$gender' WHERE user_id = $user_id");

    if (!empty($tags)) {
        $conn->query("DELETE FROM user_interests WHERE user_id = $user_id AND tag_name IS NOT NULL");

        foreach ($tags as $tag) {
            $tag = strtoupper($conn->real_escape_string($tag));
            $conn->query("INSERT INTO user_interests (user_id, gender, tag_name) VALUES ($user_id, '$gender', '$tag')");
        }
    }

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
    :root {
      --primary-color: #0095f6;
      --secondary-color: #8e8e8e;
      --bg-color: #fafafa;
      --card-bg: #ffffff;
      --border-color: #dbdbdb;
      --text-dark: #262626;
      --text-light: #8e8e8e;
      --error-color: #ff4757;
      --premium-color: #ffd700;
      --story-gradient: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
    }

    /* ===== BASE STYLES ===== */
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background-color: var(--bg-color);
      margin: 0;
      padding: 0;
      min-height: 100vh;
      position: relative;
      padding-bottom: 180px;
    }

    /* ===== STORY STYLES ===== */
    .story-container {
      display: flex;
      justify-content: center;
      margin-bottom: 20px;
    }

    .story-ring {
      display: inline-block;
      width: 106px;
      height: 106px;
      border-radius: 50%;
      padding: 3px;
      background: var(--story-gradient);
      cursor: pointer;
      transition: transform 0.2s ease;
    }

    .story-ring:hover {
      transform: scale(1.05);
    }

    .story-pic {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid var(--card-bg);
      display: block;
    }

    .story-pic.default {
      background-color: #e0e0e0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .story-pic.default i {
      font-size: 40px;
      color: #999;
    }

    /* ===== MAIN CONTENT STYLES ===== */
    .main-content {
      padding-top: 80px;
      padding-bottom: 20px;
    }

    .profile-section {
      padding: 20px;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .profile-pic {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid var(--card-bg);
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      margin-bottom: 15px;
    }

    .username {
      font-size: 18px;
      font-weight: 600;
      color: var(--text-dark);
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .verified-badge {
      width: 18px;
      height: 18px;
    }

    .social-icons {
      display: flex;
      gap: 20px;
      justify-content: center;
      margin: 20px 0;
    }

    .social-icon {
      font-size: 28px;
      color: var(--text-dark);
      transition: all 0.3s;
    }

    .social-icon:hover {
      color: var(--primary-color);
      transform: scale(1.1);
    }

    /* ===== BOTTOM SECTION STYLES ===== */
    .bottom-section {
      position: fixed;
      bottom: 58px;
      left: 0;
      width: 100%;
      background-color: var(--card-bg);
      padding: 20px;
      border-radius: 20px 20px 0 0;
      box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
      z-index: 3;
    }
    
    /* ===== GENDER SELECTION STYLES ===== */
    .gender-selection {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-bottom: 20px;
      flex-wrap: wrap;
    }

    .gender-box {
      position: relative;
      padding: 10px 20px;
      border: 2px solid var(--border-color);
      border-radius: 30px;
      cursor: pointer;
      font-size: 16px;
      transition: all 0.3s;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    /* Hide the default radio button */
    .gender-box input[type="radio"] {
      position: absolute;
      opacity: 0;
      width: 0;
      height: 0;
    }

    /* Style for the label */
    .gender-box label {
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
      z-index: 1;
    }

    /* Hover effect */
    .gender-box:hover {
      border-color: var(--primary-color);
    }

    /* Selected gender box effect - red outline outside */
    .gender-box input[type="radio"]:checked + label::before {
      content: "";
      position: absolute;
      top: -4px;
      left: -4px;
      right: -4px;
      bottom: -4px;
      border: 2px solid red;
      border-radius: 35px;
      z-index: 0;
      pointer-events: none;
    }

    /* ===== FORM COMPONENTS ===== */
    .tags-container {
      max-height: 100px;
      overflow-y: auto;
      margin: 5px 0;
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .tag {
      display: inline-flex;
      align-items: center;
      background-color: #e0f1ff;
      color: var(--primary-color);
      padding: 6px 12px;
      border-radius: 30px;
      font-size: 14px;
      font-weight: 500;
    }

    .remove-tag {
      margin-left: 8px;
      cursor: pointer;
      font-weight: bold;
      color: var(--primary-color);
    }

    #tagInput {
      width: 100%;
      padding: 12px;
      border: 1px solid var(--border-color);
      border-radius: 10px;
      margin-bottom: 15px;
    }

    .button-container {
      display: flex;
      gap: 15px;
      margin-top: 20px;
    }

    .btn {
      flex: 1;
      padding: 12px;
      border-radius: 10px;
      font-weight: 600;
      transition: all 0.3s;
    }

    .btn-danger {
      background-color: var(--error-color);
      border: none;
      color: white;
    }

    .btn-warning {
      background-color: var(--premium-color);
      border: none;
      color: #000;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    /* ===== MODAL STYLES ===== */
    .modal-content {
      border-radius: 12px;
      overflow: hidden;
    }

    .modal-header {
      border-bottom: none;
      padding: 16px 24px 0 24px;
    }

    .modal-body {
      padding: 24px;
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      gap: 15px;
    }

    .modal-body .btn {
      padding: 12px 20px;
      font-size: 15px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-width: 100px;
      border-radius: 8px;
      text-align: center;
      gap: 6px;
    }

    .modal-body .btn i {
      font-size: 20px;
      margin-bottom: 5px;
    }

    /* ===== RESPONSIVE STYLES ===== */
    @media (max-width: 768px) {
      body {
        padding-bottom: 200px;
      }
      
      .profile-pic {
        width: 80px;
        height: 80px;
      }
      
      .bottom-section {
        padding: 15px;
      }
      
      .gender-box {
        padding: 8px 15px;
        font-size: 14px;
      }
    }

    @media (max-width: 480px) {
      .story-ring {
        width: 86px;
        height: 86px;
      }
    }
    </style>
</head>
<body>
    <!-- Header and Menu are included from menu.php -->
 <?php include('menu.php'); ?>
    <div class="main-content">
        <div class="profile-section">
            <?php if ($user): ?>
                <a href="story.php" class="story-ring">
                    <?php if (!empty($user['profile_pic'])): ?>
                        <img src="<?= htmlspecialchars($user['profile_pic']) ?>" class="profile-pic" alt="Profile Picture">
                    <?php else: ?>
                        <img src="assets/default_dp.png" class="profile-pic" alt="Default Profile Picture">
                    <?php endif; ?>
                </a>

                <div class="username">
                    <?= htmlspecialchars($user['username']) ?>
                    <?php if (!empty($user['verified']) && $user['verified'] == 1): ?>
                        <img src="assets/verified.png" class="verified-badge" alt="Verified User">
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="username">User details not found</div>
            <?php endif; ?>
        </div>
        
        <!-- Social Icons -->
        <div class="social-icons">
            <a href="<?php echo $instagramLink; ?>" target="_blank" class="social-icon">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="<?php echo $telegramLink; ?>" target="_blank" class="social-icon">
                <i class="fab fa-telegram"></i>
            </a>
        </div>

        <!-- Bottom Section - Fixed at bottom -->
        <div class="bottom-section">
            <!-- Gender selection section -->
            <h4 class="text-center mb-3">Select Gender Interest</h4>
            <form method="POST" id="interestForm">
                <div class="gender-selection">
                    <div class="gender-box">
                        <input type="radio" id="male" name="gender" value="Male" <?php echo ($gender == 'Male') ? 'checked' : ''; ?>>
                        <label for="male">♂️ Male</label>
                    </div>
                    <div class="gender-box">
                        <input type="radio" id="female" name="gender" value="Female" <?php echo ($gender == 'Female') ? 'checked' : ''; ?>>
                        <label for="female">♀️ Female</label>
                    </div>
                    <div class="gender-box">
                        <input type="radio" id="both" name="gender" value="Both" <?php echo ($gender == 'Both') ? 'checked' : ''; ?>>
                        <label for="both">❤️ Both</label>
                    </div>
                </div>

                <!-- User tags section -->
                <h4 class="text-center mb-3">Your Tags</h4>
                <div class="tags-container" id="tagsContainer">
                    <?php foreach ($tags as $tag): ?>
                        <div class="tag" data-tag="<?= htmlspecialchars($tag) ?>">
                            <?= htmlspecialchars($tag) ?> 
                            <span class="remove-tag" onclick="removeTag(this)">×</span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Tag input form -->
                <input type="text" id="tagInput" class="form-control" placeholder="Type and press Enter to add tags...">

                <!-- Hidden input to store tags array -->
                <input type="hidden" id="tagsArray" name="tags" value="<?php echo htmlspecialchars(implode(',', $tags)); ?>">

                <div class="button-container">
                    <button type="submit" name="save" class="btn btn-danger">Save</button>
                    <button type="button" name="start" class="btn btn-warning" onclick="startAction()">Chat</button>
                </div>
            </form>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="chatModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <h5 class="modal-title">Choose Chat Type</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="d-flex justify-content-around flex-wrap gap-2">
                            <a href="chat.php" class="btn btn-primary">
                                <i class="fas fa-message me-2"></i> Text Chat
                            </a>
                            <a href="vc.php" class="btn btn-danger">
                                <i class="fas fa-video me-2"></i> Video Call
                            </a>
                            <a href="group.php" class="btn btn-success">
                                <i class="fas fa-user-friends me-2"></i> Group Chat
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($showGenderPopup): ?>
        <style>
        #genderPopupWrapper {
            display: none;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            z-index: 9999;
        }
        .genderPopupBox {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
            width: 320px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.2);
        }
        .genderPopupBox h3 {
            margin-bottom: 20px;
            font-size: 20px;
        }
        .genderPopupOption {
            display: inline-block;
            margin: 10px;
        }
        .genderPopupOption button {
            padding: 12px 25px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            background-color: #007bff;
            color: white;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        .genderPopupOption button:hover {
            background-color: #0056b3;
        }
        </style>

        <script>
            window.onload = function () {
                document.getElementById("genderPopupWrapper").style.display = "flex";
            };
            function handleGenderChoice(gender) {
                document.getElementById("popupGenderInput").value = gender;
                document.getElementById("popupGenderForm").submit();
            }
        </script>

        <div id="genderPopupWrapper">
            <div class="genderPopupBox">
                <h3>Please select your gender</h3>
                <form id="popupGenderForm" method="post">
                    <input type="hidden" id="popupGenderInput" name="select_gender">
                    <div class="genderPopupOption">
                        <button type="button" onclick="handleGenderChoice('Male')">Male</button>
                    </div>
                    <div class="genderPopupOption">
                        <button type="button" onclick="handleGenderChoice('Female')">Female</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Bootstrap Bundle JS (includes Popper) -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>

        <!-- jQuery -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function () {
            // DOM Elements
            const tagInput = document.getElementById("tagInput");
            const tagsContainer = document.getElementById("tagsContainer");
            const tagsArrayInput = document.getElementById("tagsArray");
            const interestForm = document.getElementById("interestForm");

            // User data from PHP
            const isPremium = <?php echo $user['premium']; ?>; // 1 or 0

            // Initialize all functionality
            initTags();
            initFormSubmission();
            initGenderSelection();

            // Tag Management Functions
            function initTags() {
                // Add tag when Enter is pressed
                tagInput.addEventListener("keypress", function (event) {
                    if (event.key === "Enter" && tagInput.value.trim() !== "") {
                        addTag(tagInput.value.trim());
                        tagInput.value = "";
                        event.preventDefault();
                    }
                });

                // Handle tag removal via event delegation
                tagsContainer.addEventListener("click", function(e) {
                    if (e.target.classList.contains("remove-tag")) {
                        e.target.parentElement.remove();
                        updateTagsArray();
                    }
                });
            }

            function addTag(tagText) {
                // Check if tag already exists
                if ([...tagsContainer.children].some(tag => tag.getAttribute("data-tag") === tagText)) {
                    return;
                }

                // Create new tag element
                const tag = document.createElement("div");
                tag.classList.add("tag");
                tag.innerHTML = `${tagText} <span class="remove-tag">×</span>`;
                tag.setAttribute("data-tag", tagText);
                tagsContainer.appendChild(tag);
                updateTagsArray();
            }

            function updateTagsArray() {
                const tags = [...tagsContainer.getElementsByClassName("tag")].map(tag =>
                    tag.getAttribute("data-tag")
                );
                tagsArrayInput.value = tags.join(",");
            }

            // Gender Selection Handling
            function initGenderSelection() {
                if (isPremium) return; // Skip for premium users
                
                const genderInputs = document.querySelectorAll('.gender-selection input[name="gender"]');
                
                genderInputs.forEach(input => {
                    input.addEventListener('click', function(e) {
                        if (this.value === "Male" || this.value === "Female") {
                            e.preventDefault();
                            window.location.href = "plan.php";
                        }
                    });
                    
                    // Visual indication for non-premium users
                    if (input.value === "Male" || input.value === "Female") {
                        const label = input.nextElementSibling;
                        label.style.position = "relative";
                        label.insertAdjacentHTML('afterend', '<span class="premium-lock">👑</span>');
                    }
                });
            }

            // Form Submission Handling
            function initFormSubmission() {
                interestForm.addEventListener("submit", function (event) {
                    const selectedGender = document.querySelector('input[name="gender"]:checked')?.value;
                    if (!isPremium && (selectedGender === "Male" || selectedGender === "Female")) {
                        event.preventDefault();
                        window.location.href = "plan.php";
                    } else {
                        updateTagsArray();
                    }
                });
            }

            // UI Functions
            function startAction() {
                $('#chatModal').modal('show');
            }

            function removeTag(element) {
                element.parentElement.remove();
                updateTagsArray();
            }

            // Expose Functions Globally
            window.startAction = startAction;
            window.removeTag = removeTag;
        });
        </script>
</body>
</html>