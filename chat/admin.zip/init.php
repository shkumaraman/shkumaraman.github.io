<?php
// Set the session timeout duration (7 days)
$session_timeout = 604800;  // 7 days (7 * 24 * 60 * 60 = 604800 seconds)

// Set the session expiration time (7 days) before starting the session
ini_set('session.gc_maxlifetime', $session_timeout);  // Set session timeout
session_set_cookie_params($session_timeout);  // Set session cookie expiration time

// Start the session
session_start();

// Check if the session has expired
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > $session_timeout) {
    // If session has expired, destroy the session
    session_unset();     // Unset all session variables
    session_destroy();   // Destroy the session
}

// Update last activity time to the current time
$_SESSION['last_activity'] = time();

?>
