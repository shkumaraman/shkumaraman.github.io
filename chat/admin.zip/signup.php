<?php
session_start();
include('db.php');

if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['signup'])) {
    // Get input data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate inputs
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required";
    }
    elseif ($password !== $confirm_password) {
        $error = "Passwords do not match";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    }
    elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters";
    }
    else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if user exists using prepared statement
        $check_sql = "SELECT id FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $check_result = $stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error = "Username or email already exists";
        } else {
            // Start transaction
            $conn->begin_transaction();
            
            try {
                // Insert new user with prepared statement
                $insert_sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($insert_sql);
                $stmt->bind_param("sss", $username, $email, $hashed_password);
                
                if ($stmt->execute()) {
                    $user_id = $stmt->insert_id;
                    $_SESSION['user_id'] = $user_id;
                    
                    // Generate random UUID for peer_id
                    $peer_id = bin2hex(random_bytes(16));
                    
                    // Insert into status table
                    $status_sql = "INSERT INTO status (user_id, peer_id) VALUES (?, ?)";
                    $stmt = $conn->prepare($status_sql);
                    $stmt->bind_param("is", $user_id, $peer_id);
                    $stmt->execute();
                    
                    // Commit transaction
                    $conn->commit();
                    
                    header('Location: dashboard.php');
                    exit();
                } else {
                    throw new Exception("Registration failed. Please try again.");
                }
            } catch (Exception $e) {
                // Rollback transaction if any error occurs
                $conn->rollback();
                $error = $e->getMessage();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --error-color: #ff4757;
            --error-light: #fff0f0;
            --primary-color: #4b7bec;
            --dark-color: #2f3542;
            --gray-color: #a4b0be;
            --success-color: #2ed573;
        }
        
        body {
            background-color: #f1f2f6;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        
        .error-card {
            width: 100%;
            max-width: 450px;
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            animation: fadeInUp 0.5s ease-out;
            border-top: 4px solid var(--error-color);
        }
        
        .error-header {
            background-color: var(--error-color);
            color: white;
            padding: 25px;
            text-align: center;
        }
        
        .error-icon {
            font-size: 50px;
            margin-bottom: 15px;
        }
        
        .error-title {
            font-size: 24px;
            font-weight: 600;
            margin: 0;
        }
        
        .error-body {
            padding: 30px;
            text-align: center;
        }
        
        .error-message {
            color: var(--error-color);
            background-color: var(--error-light);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid var(--error-color);
            font-size: 16px;
            text-align: left;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 140px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #3a6fd9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(75, 123, 236, 0.2);
        }
        
        .btn-error {
            background-color: var(--error-color);
            border-color: var(--error-color);
            color: white;
        }
        
        .btn-error:hover {
            background-color: #e84141;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 71, 87, 0.2);
        }
        
        .additional-options {
            margin-top: 25px;
            font-size: 14px;
            color: var(--gray-color);
        }
        
        .additional-options a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.2s;
        }
        
        .additional-options a:hover {
            text-decoration: underline;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 576px) {
            .error-card {
                max-width: 100%;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 10px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php if (!empty($error)): ?>
    <div class="error-card">
        <div class="error-header">
            <div class="error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2 class="error-title">Signup Failed</h2>
        </div>
        <div class="error-body">
            <div class="error-message">
                <i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="window.history.back();">
                    <i class="fas fa-arrow-left"></i> Go Back
                </button>
                <button class="btn btn-error" onclick="window.location.reload();">
                    <i class="fas fa-sync-alt"></i> Try Again
                </button>
            </div>
            
            <div class="additional-options">
                Already have an account? <a href="index.php">Login here</a>
            </div>
        </div>
    </div>
    <?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
 <script>
        // Add button click animation
        document.querySelectorAll('.btn').forEach(button => {
            button.addEventListener('mousedown', function() {
                this.style.transform = 'translateY(0)';
            });
            button.addEventListener('mouseup', function() {
                this.style.transform = 'translateY(-2px)';
            });
        });
    </script>
</body>
</html>