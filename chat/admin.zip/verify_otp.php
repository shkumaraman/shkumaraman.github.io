<?php
session_start();
require 'db.php';  // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['otp'])) {
    $otp = $_POST['otp'];
    $email = $_SESSION['otp_email'];

    // Fetch the OTP and OTP expiry from the database
    $stmt = $conn->prepare("SELECT otp, otp_expiry FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && $user['otp'] == $otp && strtotime($user['otp_expiry']) > time()) {
        echo 'success';  // OTP is valid
    } else {
        echo 'failure';  // OTP is invalid or expired
    }

    $stmt->close();
}
?>