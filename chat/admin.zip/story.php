<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// API Endpoint
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';

    // 1. Upload Story
    if ($action === 'upload') {
        $caption = trim($_POST['caption'] ?? '');
        $images = $_FILES['images'];
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 day'));

        $image_urls = [];
        foreach ($images['tmp_name'] as $key => $tmp_name) {
            if ($images['error'][$key] !== UPLOAD_ERR_OK) continue;
            
            $ext = pathinfo($images['name'][$key], PATHINFO_EXTENSION);
            $filename = 'story_' . uniqid() . '_' . $user_id . '.' . $ext;
            $upload_dir = 'uploads/stories/';
            
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $image_path = $upload_dir . $filename;
            
            if (move_uploaded_file($tmp_name, $image_path)) {
                $image_urls[] = $image_path;
            }
        }

        if (empty($image_urls)) {
            echo json_encode(['status' => 'error', 'message' => 'No valid images uploaded']);
            exit;
        }

        // Insert first image as group leader
        $stmt = $conn->prepare("INSERT INTO stories (user_id, image_url, caption, sequence, expires_at) VALUES (?, ?, ?, 1, ?)");
        $stmt->bind_param("isss", $user_id, $image_urls[0], $caption, $expires_at);
        $stmt->execute();
        $group_id = $stmt->insert_id;

        // Update group_id for the first story
        $conn->query("UPDATE stories SET group_id = $group_id WHERE id = $group_id");

        // Insert remaining images
        for ($i = 1; $i < count($image_urls); $i++) {
            $seq = $i + 1;
            $stmt = $conn->prepare("INSERT INTO stories (user_id, group_id, image_url, sequence, expires_at) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisis", $user_id, $group_id, $image_urls[$i], $seq, $expires_at);
            $stmt->execute();
        }

        echo json_encode(['status' => 'success', 'group_id' => $group_id]);
        exit;
    }

    // 2. Fetch Stories - MODIFIED TO SHOW USER'S STORY FIRST THEN MOST POPULAR
    if ($action === 'fetch') {
        // Get all active story groups with user info
        $query = "SELECT s.group_id, u.id as user_id, u.username, u.profile_pic, u.verified,
                 MAX(s.created_at) as last_updated,
                 (SELECT COUNT(*) FROM story_interactions WHERE group_id = s.group_id AND viewed = 1) as views,
                 (SELECT COUNT(*) FROM story_interactions WHERE group_id = s.group_id AND liked = 1) as likes,
                 (SELECT COUNT(*) FROM story_interactions WHERE group_id = s.group_id AND user_id = ? AND liked = 1) as has_liked,
                 CASE 
                     WHEN s.user_id = ? THEN 0  -- Your own stories get highest priority
                     ELSE (SELECT COUNT(*) FROM story_interactions WHERE group_id = s.group_id AND liked = 1) + 
                          (SELECT COUNT(*) FROM story_interactions WHERE group_id = s.group_id AND viewed = 1) / 10
                 END as popularity_score
                 FROM stories s
                 JOIN users u ON s.user_id = u.id
                 WHERE s.expires_at > NOW()
                 GROUP BY s.group_id, u.id, u.username, u.profile_pic, u.verified
                 ORDER BY 
                     CASE WHEN s.user_id = ? THEN 0 ELSE 1 END, -- Your stories first
                     popularity_score DESC, -- Then by popularity (likes + views/10)
                     last_updated DESC";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iii", $user_id, $user_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $stories = [];
        while ($row = $result->fetch_assoc()) {
            // Get all images for this story group
            $img_query = "SELECT id, image_url, caption, sequence FROM stories WHERE group_id = ? ORDER BY sequence";
            $img_stmt = $conn->prepare($img_query);
            $img_stmt->bind_param("i", $row['group_id']);
            $img_stmt->execute();
            $img_result = $img_stmt->get_result();
            
            $images = [];
            while ($img = $img_result->fetch_assoc()) {
                $images[] = $img;
            }
            
            $row['images'] = $images;
            $stories[] = $row;
        }
        
        echo json_encode($stories);
        exit;
    }

    // 3. Story Interaction
    if ($action === 'interact') {
        $group_id = (int)$_POST['group_id'];
        $type = $_POST['type']; // 'view' or 'like'
        
        if ($type === 'view') {
            $query = "INSERT INTO story_interactions (group_id, user_id, viewed) 
                     VALUES (?, ?, 1)
                     ON DUPLICATE KEY UPDATE viewed = 1";
        } else {
            $query = "INSERT INTO story_interactions (group_id, user_id, liked) 
                     VALUES (?, ?, 1)
                     ON DUPLICATE KEY UPDATE liked = NOT liked"; // Toggle like
        }
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $group_id, $user_id);
        $stmt->execute();
        
        // Get updated counts
        $counts = $conn->query("SELECT 
            (SELECT COUNT(*) FROM story_interactions WHERE group_id = $group_id AND viewed = 1) as views,
            (SELECT COUNT(*) FROM story_interactions WHERE group_id = $group_id AND liked = 1) as likes,
            (SELECT COUNT(*) FROM story_interactions WHERE group_id = $group_id AND user_id = $user_id AND liked = 1) as has_liked
        ")->fetch_assoc();
        
        echo json_encode([
            'status' => 'success',
            'views' => $counts['views'] ?? 0,
            'likes' => $counts['likes'] ?? 0,
            'has_liked' => $counts['has_liked'] ?? 0
        ]);
        exit;
    }

    // 4. Delete Story
    if ($action === 'delete') {
        $group_id = (int)$_POST['group_id'];
        
        // Verify user owns the story
        $stmt = $conn->prepare("SELECT user_id, image_url FROM stories WHERE group_id = ?");
        $stmt->bind_param("i", $group_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $images_to_delete = [];
        $is_owner = false;
        
        while ($row = $result->fetch_assoc()) {
            if ($row['user_id'] == $user_id) {
                $is_owner = true;
            }
            $images_to_delete[] = $row['image_url'];
        }
        
        if (!$is_owner) {
            echo json_encode(['status' => 'error', 'message' => 'You can only delete your own stories']);
            exit;
        }
        
        // Delete from database
        $stmt = $conn->prepare("DELETE FROM stories WHERE group_id = ?");
        $stmt->bind_param("i", $group_id);
        $stmt->execute();
        
        // Delete from interactions
        $conn->query("DELETE FROM story_interactions WHERE group_id = $group_id");
        
        // Delete image files
        foreach ($images_to_delete as $image_path) {
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }
        
        echo json_encode(['status' => 'success']);
        exit;
    }

    echo json_encode(['error' => 'Invalid action']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free/css/all.min.css">
    <title>Stories</title>
    <style>
    :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --success-color: #28a745;
            --warning-color: #ffc107;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 85px 0;
        }
        .stories-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }
        .story-item {
            aspect-ratio: 1/1;
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            background: #fff;
            border: 1px solid #dbdbdb;
            cursor: pointer;
        }
        .story-item:first-child {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
        }
        .add-story {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }
        .add-story-inner {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: #0095f6;
        }
        .story-username {
            font-size: 12px;
            text-align: center;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .story-image {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .user-avatar {
            position: absolute;
            top: 5px;
            left: 5px;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: 2px solid #0095f6;
        }
        
        /* Story Viewer */
        .story-viewer {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            display: none;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .story-header {
            width: 100%;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
            position: absolute;
            top: 0;
            left: 0;
            z-index: 2;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .story-avatar {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            object-fit: cover;
        }
        .username-wrapper {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .verified-badge {
            width: 16px;
            height: 16px;
        }
        .story-image-viewer {
            max-width: 100%;
            max-height: 80vh;
            object-fit: contain;
        }
        .progress-bars {
            display: flex;
            gap: 5px;
            width: 100%;
            position: absolute;
            top: 10px;
            left: 0;
            padding: 0 15px;
            z-index: 2;
        }
        .progress-bar {
            height: 2px;
            background-color: rgba(255, 255, 255, 0.4);
            flex-grow: 1;
            border-radius: 2px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            width: 0%;
            background-color: white;
        }
        .story-footer {
            width: 100%;
            padding: 15px;
            position: absolute;
            bottom: 0;
            left: 0;
            color: white;
            display: flex;
            flex-direction: column;
            gap: 10px;
            z-index: 2;
        }
        .caption {
            margin-bottom: 10px;
            color: white;
            text-shadow: 0 1px 2px rgba(0,0,0,0.5);
            padding: 10px;
            background-color: rgba(0,0,0,0.3);
            border-radius: 5px;
            max-width: 80%;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
        .interaction-buttons {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .like-button {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
        }
        .like-button.liked {
            color: #ff3040;
        }
        .close-button {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 3;
        }
        .delete-button {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            position: absolute;
            top: 15px;
            right: 50px;
            z-index: 3;
            display: none;
        }
        
        /* Story Creator */
        .story-creator {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: white;
            display: none;
            flex-direction: column;
            z-index: 1001;
        }
        .creator-header {
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
        }
        .creator-title {
            font-weight: 600;
        }
        .cancel-btn, .share-btn {
            background: none;
            border: none;
            color: #0095f6;
            font-weight: 600;
            cursor: pointer;
        }
        .share-btn:disabled {
            opacity: 0.5;
        }
        .creator-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .upload-btn-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
            text-align: center;
        }
        .upload-btn {
            border: 2px dashed #dbdbdb;
            color: #8e8e8e;
            background-color: #fafafa;
            padding: 40px 0;
            border-radius: 5px;
            font-size: 16px;
            text-align: center;
            cursor: pointer;
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }
        .upload-btn-wrapper input[type=file] {
            font-size: 100px;
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .image-preview {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
            justify-content: center;
        }
        .preview-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 5px;
        }
        .caption-input {
            width: 100%;
            max-width: 400px;
            margin: 20px auto 0;
            padding: 10px;
            border: 1px solid #dbdbdb;
            border-radius: 5px;
            resize: none;
        }
    </style>
</head>
<body>
<?php include('menu.php'); ?>
    <div class="container">
        
        <div class="stories-grid" id="storiesGrid">
            <!-- First item is always the "Add Story" button -->
            <div class="story-item" onclick="openStoryCreator()">
                <div class="add-story">
                    <div class="add-story-inner">+</div>
                </div>
                <div class="story-username">Your Story</div>
            </div>
            
            <!-- Other stories will be loaded here -->
        </div>
    </div>
    
    <!-- Story Viewer -->
    <div class="story-viewer" id="storyViewer">
        <div class="progress-bars" id="progressBars"></div>
        
        <div class="story-header">
            <div class="user-info">
                <img class="story-avatar" id="viewerAvatar" src="assets/default_dp.png">
                <div class="username-wrapper">
                    <span id="viewerUsername"></span>
                    <img class="verified-badge" id="viewerVerified" src="assets/verified.png" style="display: none;">
                </div>
            </div>
        </div>
        
        <img class="story-image-viewer" id="storyImageViewer" src="">
        
        <div class="story-footer">
            <div class="caption" id="storyCaption"></div>
            <div class="interaction-buttons">
                <div id="countsContainer">
                    <!-- Views and likes will be shown here only for publisher -->
                </div>
                <button class="like-button" id="likeButton" onclick="toggleLike()">❤</button>
            </div>
        </div>
        
        <button class="delete-button" id="deleteButton" onclick="confirmDelete()">🗑️</button>
        <button class="close-button" onclick="closeViewer()">×</button>
    </div>
    
    <!-- Story Creator -->
    <div class="story-creator" id="storyCreator">
        <div class="creator-header">
            <button class="cancel-btn" onclick="closeCreator()">Cancel</button>
            <div class="creator-title">New Story</div>
            <button class="share-btn" id="shareBtn" disabled onclick="uploadStory()">Share</button>
        </div>
        
        <div class="creator-content">
            <div class="upload-btn-wrapper">
                <div class="upload-btn" id="uploadTrigger">
                    <div style="font-size: 24px; margin-bottom: 10px;">+</div>
                    <div>Add Photos</div>
                </div>
                <input type="file" name="images[]" id="images" multiple accept="image/*">
            </div>
            
            <div class="image-preview" id="imagePreview"></div>
            
            <textarea class="caption-input" id="captionInput" placeholder="Add a caption..."></textarea>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    let currentUser = <?php echo $user_id; ?>;
    let storiesData = [];
    let currentStoryIndex = 0;
    let currentImageIndex = 0;
    let progressInterval;
    let progressBars = [];
    
    // Load stories when page loads
    document.addEventListener('DOMContentLoaded', function() {
        loadStories();
        
        // Setup image upload preview
        document.getElementById('images').addEventListener('change', function(e) {
            const preview = document.getElementById('imagePreview');
            preview.innerHTML = '';
            
            if (this.files.length > 0) {
                document.getElementById('shareBtn').disabled = false;
                
                for (let i = 0; i < this.files.length; i++) {
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        const img = document.createElement('img');
                        img.src = event.target.result;
                        img.className = 'preview-image';
                        preview.appendChild(img);
                    }
                    reader.readAsDataURL(this.files[i]);
                }
            } else {
                document.getElementById('shareBtn').disabled = true;
            }
        });
    });
    
    // Fetch stories from server
    function loadStories() {
        const formData = new FormData();
        formData.append('action', 'fetch');
        
        fetch('story.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(stories => {
            storiesData = stories;
            renderStories();
        })
        .catch(error => {
            console.error('Error loading stories:', error);
        });
    }
    
    // Render story circles
    function renderStories() {
        const container = document.getElementById('storiesGrid');
        
        // Clear existing stories (keep the first "Add Story" item)
        while (container.children.length > 1) {
            container.removeChild(container.lastChild);
        }
        
        if (storiesData.length === 0) return;
        
        storiesData.forEach((story, index) => {
            const storyElement = document.createElement('div');
            storyElement.className = 'story-item';
            storyElement.onclick = () => openStoryViewer(index);
            
            // Use the first image of the story group
            const firstImage = story.images[0].image_url;
            
            storyElement.innerHTML = `
                <img class="story-image" src="${firstImage}">
                <img class="user-avatar" src="${story.profile_pic || 'assets/default_dp.png'}" alt="${story.username}">
            `;
            
            container.appendChild(storyElement);
        });
    }
    
    // Open story creator
    function openStoryCreator() {
        document.getElementById('storyCreator').style.display = 'flex';
    }
    
    // Close story creator
    function closeCreator() {
        document.getElementById('storyCreator').style.display = 'none';
        document.getElementById('imagePreview').innerHTML = '';
        document.getElementById('captionInput').value = '';
        document.getElementById('images').value = '';
        document.getElementById('shareBtn').disabled = true;
    }
    
    // Open story viewer
    function openStoryViewer(storyIndex) {
        currentStoryIndex = storyIndex;
        currentImageIndex = 0;
        
        const story = storiesData[storyIndex];
        const viewer = document.getElementById('storyViewer');
        
        // Set user info
        document.getElementById('viewerAvatar').src = story.profile_pic || 'assets/default_dp.png';
        document.getElementById('viewerUsername').textContent = story.username;
        
        // Show verified badge if user is verified
        const verifiedBadge = document.getElementById('viewerVerified');
        if (story.verified) {
            verifiedBadge.style.display = 'block';
        } else {
            verifiedBadge.style.display = 'none';
        }
        
        // Show/hide delete button based on ownership
        const deleteButton = document.getElementById('deleteButton');
        if (story.user_id === currentUser) {
            deleteButton.style.display = 'block';
        } else {
            deleteButton.style.display = 'none';
        }
        
        // Create progress bars
        const progressContainer = document.getElementById('progressBars');
        progressContainer.innerHTML = '';
        progressBars = [];
        
        story.images.forEach((img, i) => {
            const bar = document.createElement('div');
            bar.className = 'progress-bar';
            bar.innerHTML = '<div class="progress-fill"></div>';
            progressContainer.appendChild(bar);
            progressBars.push(bar.firstChild);
        });
        
        // Load first image
        loadStoryImage();
        
        // Mark as viewed
        if (story.user_id !== currentUser) {
            interactWithStory(story.group_id, 'view');
        }
        
        // Show viewer
        viewer.style.display = 'flex';
        
        // Start progress timer
        startProgressTimer();
    }
    
    // Load current story image
    function loadStoryImage() {
        const story = storiesData[currentStoryIndex];
        const currentImage = story.images[currentImageIndex];
        
        document.getElementById('storyImageViewer').src = currentImage.image_url;
        document.getElementById('storyCaption').textContent = currentImage.caption || story.caption || '';
        
        // Update counts container - only show for publisher
        const countsContainer = document.getElementById('countsContainer');
        if (story.user_id === currentUser) {
            countsContainer.innerHTML = `
                <span id="viewCount">${story.views} views</span>
                <span> • </span>
                <span id="likeCount">${story.likes} likes</span>
            `;
        } else {
            countsContainer.innerHTML = '';
        }
        
        // Update like button
        const likeButton = document.getElementById('likeButton');
        if (story.has_liked) {
            likeButton.classList.add('liked');
        } else {
            likeButton.classList.remove('liked');
        }
        
        // Reset progress bars
        progressBars.forEach((bar, i) => {
            bar.style.width = i < currentImageIndex ? '100%' : '0%';
        });
    }
    
    // Start progress timer
    function startProgressTimer() {
        clearInterval(progressInterval);
        
        const story = storiesData[currentStoryIndex];
        let progress = 0;
        const duration = 5000; // 5 seconds per image
        
        progressInterval = setInterval(() => {
            progress += 10;
            const currentProgress = (progress / duration) * 100;
            progressBars[currentImageIndex].style.width = `${currentProgress}%`;
            
            if (progress >= duration) {
                nextImage();
            }
        }, 10);
    }
    
    // Show next image in story
    function nextImage() {
        const story = storiesData[currentStoryIndex];
        
        if (currentImageIndex < story.images.length - 1) {
            currentImageIndex++;
            loadStoryImage();
            startProgressTimer();
        } else {
            closeViewer();
        }
    }
    
    // Show previous image in story
    function prevImage() {
        if (currentImageIndex > 0) {
            currentImageIndex--;
            loadStoryImage();
            startProgressTimer();
        }
    }
    
    // Close story viewer
    function closeViewer() {
        clearInterval(progressInterval);
        document.getElementById('storyViewer').style.display = 'none';
    }
    
    // Toggle like on current story
    function toggleLike() {
        const story = storiesData[currentStoryIndex];
        if (story.user_id === currentUser) return; // Can't like own story
        
        const likeButton = document.getElementById('likeButton');
        const liked = !likeButton.classList.contains('liked');
        
        interactWithStory(story.group_id, 'like');
        
        // Update UI immediately
        if (liked) {
            likeButton.classList.add('liked');
            story.likes++;
        } else {
            likeButton.classList.remove('liked');
            story.likes--;
        }
        
        // Update counts if viewer is publisher
        if (story.user_id === currentUser) {
            document.getElementById('likeCount').textContent = `${story.likes} likes`;
        }
    }
    
    // Send interaction to server
    function interactWithStory(groupId, type) {
        const formData = new FormData();
        formData.append('action', 'interact');
        formData.append('group_id', groupId);
        formData.append('user_id', currentUser);
        formData.append('type', type);
        
        fetch('story.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            // Update counts in the current story data
            const story = storiesData[currentStoryIndex];
            if (story.group_id === groupId) {
                story.views = data.views;
                story.likes = data.likes;
                story.has_liked = data.has_liked;
                
                // Update counts display if viewer is publisher
                if (story.user_id === currentUser) {
                    document.getElementById('viewCount').textContent = `${data.views} views`;
                    document.getElementById('likeCount').textContent = `${data.likes} likes`;
                }
            }
        });
    }
    
    // Show delete confirmation with SweetAlert
    function confirmDelete() {
        Swal.fire({
            title: 'Delete Story?',
            text: "Are you sure you want to delete this story? This cannot be undone.",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            backdrop: true,
            allowOutsideClick: false,
            allowEscapeKey: true
        }).then((result) => {
            if (result.isConfirmed) {
                deleteStory();
            }
        });
    }
    
    // Delete story
    function deleteStory() {
        const story = storiesData[currentStoryIndex];
        
        // Only allow deletion of own stories
        if (story.user_id !== currentUser) return;
        
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('group_id', story.group_id);
        
        fetch('story.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire({
                    title: 'Deleted!',
                    text: 'Your story has been deleted.',
                    icon: 'success',
                    confirmButtonColor: '#3085d6',
                    timer: 2000,
                    showConfirmButton: false
                });
                closeViewer();
                loadStories(); // Refresh the list
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: data.message || 'Failed to delete story',
                    icon: 'error',
                    confirmButtonColor: '#3085d6'
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            Swal.fire({
                title: 'Error!',
                text: 'Error deleting story',
                icon: 'error',
                confirmButtonColor: '#3085d6'
            });
        });
    }
    
    // Upload new story
    function uploadStory() {
        if (document.getElementById('images').files.length === 0) {
            Swal.fire({
                title: 'No Images Selected',
                text: 'Please select at least one image',
                icon: 'warning',
                confirmButtonColor: '#3085d6'
            });
            return;
        }
        
        Swal.fire({
            title: 'Share Story?',
            text: "Are you sure you want to share this story?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, share it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                const formData = new FormData();
                formData.append('action', 'upload');
                formData.append('caption', document.getElementById('captionInput').value);
                
                const files = document.getElementById('images').files;
                for (let i = 0; i < files.length; i++) {
                    formData.append('images[]', files[i]);
                }
                
                // Show loading indicator
                Swal.fire({
                    title: 'Uploading Story',
                    html: 'Please wait while we upload your story...',
                    allowOutsideClick: false,
                    didOpen: () => {
                        Swal.showLoading();
                    }
                });
                
                fetch('story.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        Swal.fire({
                            title: 'Success!',
                            text: 'Your story has been shared!',
                            icon: 'success',
                            confirmButtonColor: '#3085d6',
                            timer: 2000,
                            showConfirmButton: false
                        });
                        closeCreator();
                        loadStories();
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: data.message || 'Failed to upload story',
                            icon: 'error',
                            confirmButtonColor: '#3085d6'
                        });
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    Swal.fire({
                        title: 'Error!',
                        text: 'Error uploading story',
                        icon: 'error',
                        confirmButtonColor: '#3085d6'
                    });
                });
            }
        });
    }
    
    // Handle keyboard navigation
    document.addEventListener('keydown', function(e) {
        const viewer = document.getElementById('storyViewer');
        if (viewer.style.display !== 'flex') return;
        
        if (e.key === 'ArrowRight') {
            nextImage();
        } else if (e.key === 'ArrowLeft') {
            prevImage();
        } else if (e.key === 'Escape') {
            closeViewer();
        }
    });
    
    // Handle swipe gestures
    let touchStartX = 0;
    let touchEndX = 0;
    
    document.getElementById('storyViewer').addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
    }, false);
    
    document.getElementById('storyViewer').addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    }, false);
    
    function handleSwipe() {
        if (touchEndX < touchStartX - 50) {
            nextImage(); // Swipe left
        } else if (touchEndX > touchStartX + 50) {
            prevImage(); // Swipe right
        }
    }
</script>
</body>
</html>