<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'];

// Step 1: Disconnect current connection and delete messages
$sql_find_connection = "SELECT user1_id, user2_id FROM chat_connections WHERE user1_id = ? OR user2_id = ?";
$stmt_find_connection = $conn->prepare($sql_find_connection);
$stmt_find_connection->bind_param("ii", $user_id, $user_id);
$stmt_find_connection->execute();
$result_find_connection = $stmt_find_connection->get_result();

if ($result_find_connection->num_rows > 0) {
    $row = $result_find_connection->fetch_assoc();
    $connected_user_id = ($row['user1_id'] == $user_id) ? $row['user2_id'] : $row['user1_id'];

    $sql_delete_connection = "DELETE FROM chat_connections WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)";
    $stmt_delete_connection = $conn->prepare($sql_delete_connection);
    $stmt_delete_connection->bind_param("iiii", $user_id, $connected_user_id, $connected_user_id, $user_id);
    $stmt_delete_connection->execute();
}

// Step 2: Fetch current user's gender preference and tags
$sql_user_interests = "SELECT gender, GROUP_CONCAT(tag_name) AS tags FROM user_interests WHERE user_id = ?";
$stmt = $conn->prepare($sql_user_interests);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_user_interests = $stmt->get_result();
$user_interest = $result_user_interests->fetch_assoc();

$user_gender_preference = $user_interest['gender'] ?? 'Both';
$user_tags = !empty($user_interest['tags']) ? explode(',', $user_interest['tags']) : [];

// Step 3: Get all other online users with their interests
$sql_find_users = "
    SELECT u.id, u.username, ui.gender, GROUP_CONCAT(ui.tag_name) AS tags 
    FROM users u
    LEFT JOIN user_interests ui ON u.id = ui.user_id
    WHERE u.status = 'online' AND u.id != ?
    GROUP BY u.id";
    
$stmt = $conn->prepare($sql_find_users);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_users = $stmt->get_result();

$connected_user = null;
$phase2_users = [];

// Step 4: Try Phase 1 (strict gender match + tag match)
while ($row = $result_users->fetch_assoc()) {
    $new_user_id = $row['id'];
    $new_user_gender = $row['gender'] ?? 'Both';
    $new_user_tags = !empty($row['tags']) ? explode(',', $row['tags']) : [];

    $gender_match = false;

    if ($user_gender_preference === 'Both' && $new_user_gender === 'Both') {
        $gender_match = true;
    } elseif ($user_gender_preference === 'Male' && $new_user_gender === 'Female') {
        $gender_match = true;
    } elseif ($user_gender_preference === 'Female' && $new_user_gender === 'Male') {
        $gender_match = true;
    }

    $has_common_tags = !empty(array_intersect($user_tags, $new_user_tags));
    $both_have_no_tags = empty($user_tags) && empty($new_user_tags);

    if ($gender_match && ($has_common_tags || $both_have_no_tags)) {
        $connected_user = $row;
        break;
    }

    // Save for Phase 2
    if (($has_common_tags || $both_have_no_tags)) {
        $phase2_users[] = $row;
    }
}

// Step 5: Try Phase 2 (ignore gender, just tag match)
if (!$connected_user && !empty($phase2_users)) {
    $connected_user = $phase2_users[0]; // Connect to first matching user with tag match
}

// Step 6: Connect and log
if ($connected_user) {
    $new_connected_user_id = $connected_user['id'];
    $new_connected_username = $connected_user['username'];

    $sql_insert_connection = "INSERT INTO chat_connections (user1_id, user2_id, connected_at) 
                              VALUES (?, ?, NOW())";
    $stmt_insert_connection = $conn->prepare($sql_insert_connection);
    $stmt_insert_connection->bind_param("ii", $user_id, $new_connected_user_id);
    $stmt_insert_connection->execute();

    $sql_insert_history = "INSERT INTO connection_history (user1_id, user2_id, connection_time) 
                           VALUES (?, ?, NOW())";
    $stmt_insert_history = $conn->prepare($sql_insert_history);
    $stmt_insert_history->bind_param("ii", $user_id, $new_connected_user_id);
    $stmt_insert_history->execute();

    echo json_encode([
        'status' => 'success',
        'message' => 'Connected to a new user.',
        'connected_username' => $new_connected_username
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'No matching users available.'
    ]);
}
?>
