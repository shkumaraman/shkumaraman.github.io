<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "User not authenticated"]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Step 1: End the current call if active
$sql_find_call = "SELECT id FROM video_calls 
                  WHERE (caller_id = $user_id OR receiver_id = $user_id) 
                  AND end_time IS NULL 
                  LIMIT 1";
$result = $conn->query($sql_find_call);
if ($result && $result->num_rows > 0) {
    $call = $result->fetch_assoc();
    $sql_disconnect = "UPDATE video_calls SET end_time = NOW() WHERE id = {$call['id']}"; 
    $conn->query($sql_disconnect);
}

// Step 2: Fetch user preferences
$sql_user_prefs = "SELECT gender, tag_name FROM user_interests WHERE user_id = $user_id";
$result_user_prefs = $conn->query($sql_user_prefs);

$user_gender = 'Both';
$user_tags = [];
$has_tags = false;

while ($row = $result_user_prefs->fetch_assoc()) {
    if (!empty($row['gender'])) $user_gender = $row['gender'];
    if (!empty($row['tag_name'])) {
        $user_tags[] = $row['tag_name'];
        $has_tags = true;
    }
}

// Step 3: Fetch online users excluding self
$sql_online_users = "SELECT s.user_id, u.username, u.profile_pic, u.verified, s.peer_id 
                     FROM status s
                     JOIN users u ON s.user_id = u.id
                     WHERE s.vcstatus = 'online' AND s.user_id != $user_id";

$result_online_users = $conn->query($sql_online_users);
$matched_user = null;
$phase2_users = [];

while ($row = $result_online_users->fetch_assoc()) {
    $online_user_id = $row['user_id'];

    // Fetch gender and tags
    $sql_online_prefs = "SELECT gender, tag_name FROM user_interests WHERE user_id = $online_user_id";
    $result_online_prefs = $conn->query($sql_online_prefs);

    $online_gender = 'Both';
    $online_tags = [];
    $online_has_tags = false;

    while ($tag_row = $result_online_prefs->fetch_assoc()) {
        if (!empty($tag_row['gender'])) $online_gender = $tag_row['gender'];
        if (!empty($tag_row['tag_name'])) {
            $online_tags[] = $tag_row['tag_name'];
            $online_has_tags = true;
        }
    }

    // Gender Matching (Strict)
    $gender_match = false;
    if ($user_gender === 'Both' && $online_gender === 'Both') {
        $gender_match = true;
    } elseif ($user_gender === 'Male' && $online_gender === 'Female') {
        $gender_match = true;
    } elseif ($user_gender === 'Female' && $online_gender === 'Male') {
        $gender_match = true;
    }

    $common_tags = array_intersect($user_tags, $online_tags);
    $both_no_tags = !$has_tags && !$online_has_tags;

    // Phase 1 Match
    if ($gender_match && (!empty($common_tags) || $both_no_tags)) {
        $matched_user = $row;
        break;
    }

    // Save for Phase 2
    if (!empty($common_tags) || $both_no_tags) {
        $phase2_users[] = $row;
    }
}

// Phase 2: Ignore gender, use tag match only
if (!$matched_user && !empty($phase2_users)) {
    $matched_user = $phase2_users[0];
}

// Step 4: Start new video call
if ($matched_user) {
    $receiver_id = $matched_user['user_id'];
    $peer_id = $matched_user['peer_id'];

    $insert_sql = "INSERT INTO video_calls (caller_id, receiver_id, start_time)
                   VALUES ($user_id, $receiver_id, NOW())";

    if ($conn->query($insert_sql)) {
        $sql_insert_history = "INSERT INTO connection_history (user1_id, user2_id, connection_time) 
                               VALUES ($user_id, $receiver_id, NOW())";

        if ($conn->query($sql_insert_history)) {
            echo json_encode([
                "peer_id" => $peer_id,
                "username" => $matched_user['username'],
                "profile_pic" => $matched_user['profile_pic'],
                "verified" => $matched_user['verified']
            ]);
        } else {
            echo json_encode(["error" => "Failed to insert connection history: " . $conn->error]);
        }
    } else {
        echo json_encode(["error" => "Failed to insert video call: " . $conn->error]);
    }
} else {
    echo json_encode(["error" => "No suitable match found"]);
}
?>
