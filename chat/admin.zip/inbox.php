<?php
session_start();
include 'db.php';

// Redirect if user is not logged in or friend ID is not provided
if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: friends.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$friend_id = $_GET['id'];

// Fetch friend's details including active_status
$sql_friend = "SELECT username, profile_pic, verified, active_status FROM users WHERE id = ?";
$stmt_friend = $conn->prepare($sql_friend);
$stmt_friend->bind_param("i", $friend_id);
$stmt_friend->execute();
$result_friend = $stmt_friend->get_result();
$friend = $result_friend->fetch_assoc();

$friend_name = $friend['username'];
$friend_profile_pic = $friend['profile_pic'];
$friend_verified = $friend['verified'];
$friend_active_status = $friend['active_status'];

// Determine status dot class (only online/offline)
$status_class = in_array($friend_active_status, [1, 2]) ? 'online-dot' : 'offline-dot';

// Get peer ID for current user
$sql_peer = "SELECT peer_id FROM status WHERE user_id = ?";
$stmt_peer = $conn->prepare($sql_peer);
$stmt_peer->bind_param("i", $user_id);
$stmt_peer->execute();
$result_peer = $stmt_peer->get_result();
$current_user_peer_id = $result_peer->num_rows > 0 ? $result_peer->fetch_assoc()['peer_id'] : null;

// Get friend's peer ID
$sql_friend_peer = "SELECT peer_id FROM status WHERE user_id = ?";
$stmt_friend_peer = $conn->prepare($sql_friend_peer);
$stmt_friend_peer->bind_param("i", $friend_id);
$stmt_friend_peer->execute();
$result_friend_peer = $stmt_friend_peer->get_result();
$friend_peer_id = $result_friend_peer->num_rows > 0 ? $result_friend_peer->fetch_assoc()['peer_id'] : null;

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Chat with <?= htmlspecialchars($friend_name) ?></title>

    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
:root {
    --primary-color: #0095f6;
    --secondary-color: #8e8e8e;
    --bg-color: #fafafa;
    --card-bg: #ffffff;
    --border-color: #dbdbdb;
    --text-dark: #262626;
    --text-light: #8e8e8e;
    --online-color: #4CAF50;
    --offline-color: #e0e0e0;
}

body {
    background-color: var(--bg-color);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.header {
    position: fixed;
    top: 0;
    left: 0;
    z-index: 1000;
    width: 100%;
    background-color: var(--card-bg);
    color: var(--text-dark);
    padding: 12px 16px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid var(--border-color);
    box-shadow: 0 1px 5px rgba(0,0,0,0.05);
}

.back-btn {
    background: transparent;
    border: none;
    color: var(--text-dark);
    font-size: 20px;
    cursor: pointer;
    padding: 8px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    display: flex;
    justify-content: space-between;
    border-radius: 50%;
    transition: all 0.3s;
}

.back-btn:hover {
    background-color: #f0f0f0;
}
.d-flex {
   margin-right: 30px;
}
.chat-container {
    width: 100%;
    max-width: 600px;
    margin: auto;
    background: white;
    height: 100vh;
    display: flex;
    flex-direction: column;
}

.chat-box {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    background: #fff;
    display: flex;
    margin: 50px 0 50px 0;
    flex-direction: column;
}
.chat-message {
    margin: 5px 0;
    padding: 8px 16px;
    border-radius: 18px;
    max-width: 70%;
    min-width: 40px;
    width: fit-content;
    word-wrap: break-word;
    font-size: 14px;
    line-height: 1.4;
    position: relative;
    box-sizing: border-box;
}
.received {
    background-color: #fff;
    border: 1px solid #dbdbdb;
    align-self: flex-start;
    margin-right: auto;
    border-bottom-left-radius: 4px;
}
.sent {
    background-color: #0095f6;
    color: white;
    align-self: flex-end;
    margin-left: auto;
    border-bottom-right-radius: 4px;
}
.uploaded-img {
    max-width: 200px;
    border-radius: 10px;
    margin-top: 5px;
}

#input-area {
    width: 100%;
    max-width: 600px;
    display: flex; 
    align-items: center; 
    padding: 10px 15px;
    background-color: #fff;
    border-top: 1px solid #dbdbdb;
    position: fixed;
    bottom: 0;
    box-sizing: border-box;
}
.file-upload-label {
    margin-right: 10px;
    color: #262626;
    background: none;
    border: none;
    cursor: pointer;
}
.file-upload-input {
    display: none;
}
.input-with-btn {
    position: relative;
    flex: 1;
    margin-right: 10px;
}
#message-input {
    width: 100%;
    padding: 10px 70px 10px 15px; /* Right padding for button */
    border-radius: 20px;
    border: 1px solid #dbdbdb;
    background-color: #fafafa;
    font-size: 14px;
    outline: none;
    box-sizing: border-box;
}
#send-btn {
    position: absolute;
    right: 20px;
    top: 50%;
    transform: translateY(-50%);
    background: #0095f6;
    color: white;
    border: none;
    border-radius: 15px;
    padding: 5px 12px;
    font-size: 14px;
    font-weight: bold;
    cursor: pointer;
}
#send-btn:hover {
    background: #0077cc;
}

.action-btn {
    background: none;
    border: none;
    color: #0095f6;
    cursor: pointer;
    font-size: 14px;
    font-weight: 600;
    padding: 5px 10px;
    border-radius: 4px;
}
.action-btn:hover {
    background-color: #fafafa;
}
.profile-pic {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    margin-right: 10px;
    position: relative;
}
.verified-badge {
    width: 16px;
    height: 16px;
    margin-left: 1px;
}
.three-dots {
    cursor: pointer;
    font-size: 18px;
    position: absolute;
    top: -10px;
    right: 5px;
}
.dropdown-menu {
    position: absolute;
    top: 25px;
    right: 0;
    background: white;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    display: none;
    z-index: 1000;
    min-width: 100px;
    text-align: left;
    max-width: 80vw;
    overflow: hidden;
    white-space: nowrap;
}
.dropdown-menu button {
    display: block;
    max-width: 100%;
    padding: 8px 10px;
    text-align: left;
    border: none;
    background: none;
    cursor: pointer;
}
.dropdown-menu button:hover {
    background: #f1f1f1;
}
.chat-message {
    position: relative;
    padding-right: 30px;
}
@media (max-width: 576px) {
    .dropdown-menu {
        min-width: 70%;
    }
}
#new-message-indicator {
    position: fixed;
    bottom: 70px;
    left: 50%;
    transform: translateX(-50%);
    background: #075e54;
    color: white;
    padding: 10px 20px;
    border-radius: 20px;
    cursor: pointer;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    display: none;
    z-index: 1000;
}
.status-dot {
    position: absolute;
    bottom: 2px;
    right: 10px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid white;
}
.online-dot {
    background-color: var(--online-color);
}
.offline-dot {
    background-color: var(--offline-color);
}
</style>
</head>
<body>
        <!-- Chat Header -->
        <div class="header">
            <!-- Back Button -->
            <button class="back-btn" onclick="history.back()">
                <i class="fas fa-arrow-left"></i>
            </button>

<!-- Display Friend's Profile Picture and Username -->
<div class="d-flex align-items-center">
    <div style="position: relative;">
        <img 
            src="<?= $friend_profile_pic ? $friend_profile_pic : 'assets/default_dp.png' ?>" 
            class="profile-pic" 
            alt="Profile Picture"
        >
        <div class="status-dot <?= $status_class ?>"></div>
    </div>

    <div class="username">
        <?= htmlspecialchars($friend_name) ?>
        <?php if ($friend_verified == 1): ?>
            <img src="assets/verified.png" class="verified-badge" alt="Verified">
        <?php endif; ?>
    </div>
</div>

        </div>
        
        <div class="chat-container">
        <!-- Chat Box -->
        <div class="chat-box" id="chat-box">
            <!-- Messages will be loaded here via AJAX -->
        </div>

     <!-- New Messages Button -->
        <div id="new-message-indicator" onclick="scrollToBottom()">
            New Messages ↓
        </div>

        <!-- Chat Footer -->
        <div id="input-area">
            <!-- File Upload Button -->
            <label for="file-upload" class="file-upload-label">
                <i class="fas fa-paperclip fa-lg"></i>
            </label>
            <input type="file" id="file-upload" name="file" class="file-upload-input">

            <!-- Message Input -->
            <input type="text" id="message-input" placeholder="Type a message...">
            <button id="send-btn" class="action-btn">
                Send</button>
        </div>
    </div>
    <!-- PeerJS library -->
<script src="https://cdn.jsdelivr.net/npm/peerjs@latest/dist/peerjs.min.js"></script>
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.18.0/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
<script>
$(document).ready(function () {
    const chatBox = $("#chat-box");
    const messageInput = $("#message-input");
    const fileUpload = $("#file-upload");
    const newMessageIndicator = $("#new-message-indicator");
    const statusDot = $("#status-dot");
    let isUserAtBottom = true;
    
    // PeerJS variables
    let peer;
    let conn;
    const currentUserPeerId = '<?= $current_user_peer_id ?>';
    const friendPeerId = '<?= $friend_peer_id ?>';
    
    // ===== STATUS TRACKING VARIABLES =====
    let isTabActive = true;
    let inactivityTimer;
    let statusCheckInterval;
    let friendStatus = 0; // 0 = offline, 1 = online
    
    // ===== CHAT FUNCTIONS =====
    
    // Initialize PeerJS connection
    function initializePeerJS() {
        // Only proceed if we have both peer IDs
        if (!currentUserPeerId || !friendPeerId) {
            console.log("Peer IDs not available for both users");
            updateConnectionStatus(false);
            return;
        }
        
        // Create a new Peer instance
        peer = new Peer(currentUserPeerId, {
            debug: 2,
            config: {
                'iceServers': [
                    { url: 'stun:stun.l.google.com:19302' },
                    { url: 'stun:stun1.l.google.com:19302' },
                    { url: 'stun:stun2.l.google.com:19302' }
                ]
            }
        });
        
        // PeerJS event handlers
        peer.on('open', function(id) {
            console.log('My peer ID is: ' + id);
            updateConnectionStatus(true);
            sendHeartbeat(1); // Update status to online
            
            // Connect to friend
            connectToFriend();
        });
        
        peer.on('connection', function(connection) {
            console.log('Incoming connection from: ' + connection.peer);
            conn = connection;
            setupConnectionHandlers();
        });
        
        peer.on('error', function(err) {
            console.error('PeerJS error:', err);
            updateConnectionStatus(false);
        });
        
        peer.on('disconnected', function() {
            console.log('Connection lost. Reconnecting...');
            updateConnectionStatus(false);
            peer.reconnect();
        });
        
        peer.on('close', function() {
            console.log('Connection closed');
            updateConnectionStatus(false);
            sendHeartbeat(0); // Update status to offline
        });
    }
    
    // Connect to friend's peer
    function connectToFriend() {
        if (!friendPeerId) {
            console.log("Friend's peer ID not available");
            updateConnectionStatus(false);
            return;
        }
        
        console.log('Attempting to connect to friend:', friendPeerId);
        conn = peer.connect(friendPeerId, {
            reliable: true,
            serialization: 'json'
        });
        
        setupConnectionHandlers();
    }
    
    // Setup connection event handlers
    function setupConnectionHandlers() {
        if (!conn) return;
        
        conn.on('open', function() {
            console.log('Connected to: ' + conn.peer);
            updateConnectionStatus(true);
        });
        
        conn.on('data', function(data) {
            console.log('Received data:', data);
            
            if (data.type === 'message') {
                // Add the received message to the chat
                addMessageToChat(data.sender_id, data.message, data.timestamp, false);
            }
        });
        
        conn.on('close', function() {
            console.log('Connection closed');
            updateConnectionStatus(false);
        });
        
        conn.on('error', function(err) {
            console.error('Connection error:', err);
            updateConnectionStatus(false);
        });
    }
    
    // Update connection status UI (now using the dot)
    function updateConnectionStatus(isConnected) {
        if (isConnected) {
            statusDot.removeClass('offline-dot').addClass('online-dot');
        } else {
            statusDot.removeClass('online-dot').addClass('offline-dot');
        }
    }
    
    // Send message via PeerJS
    function sendMessageViaPeerJS(message) {
        if (conn && conn.open) {
            const messageData = {
                type: 'message',
                sender_id: <?= $user_id ?>,
                receiver_id: <?= $friend_id ?>,
                message: message,
                timestamp: new Date().toISOString()
            };
            
            conn.send(messageData);
            return true;
        }
        return false;
    }
    
    // Add message to chat UI
    function addMessageToChat(senderId, message, timestamp, isSent) {
        const messageClass = isSent ? 'sent' : 'received';
        const messageTime = new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        const messageElement = `
            <div class="chat-message ${messageClass}">
                <div>${message}</div>
                <div style="font-size: 10px; text-align: ${isSent ? 'right' : 'left'}; margin-top: 3px;">${messageTime}</div>
            </div>
        `;
        
        chatBox.append(messageElement);
        
        if (isUserAtBottom) {
            scrollToBottom();
        } else {
            newMessageIndicator.show();
        }
    }

    // Fetch messages from server
    function fetchMessages() {
        $.ajax({
            url: "fetch_inbox.php",
            type: "GET",
            data: {
                user_id: <?= $user_id ?>,
                friend_id: <?= $friend_id ?>
            },
            success: function (response) {
                const wasAtBottom = isUserAtBottom;

                // Update chat box content
                chatBox.html(response);

                // Scroll to bottom if the user was already at the bottom
                if (wasAtBottom) {
                    chatBox.scrollTop(chatBox[0].scrollHeight);
                    newMessageIndicator.hide();
                } else {
                    newMessageIndicator.show();
                }

                // Add event listeners for delete, copy, and three-dots menu
                $(".delete-btn").off("click").on("click", function () {
                    const messageId = $(this).data("id");
                    deleteMessage(messageId);
                });

                $(".copy-btn").off("click").on("click", function () {
                    const messageText = $(this).data("message");
                    copyToClipboard(messageText);
                });

                $(".three-dots").off("click").on("click", function (e) {
                    e.stopPropagation();
                    $(this).next(".dropdown-menu").toggle();
                });

                // Close dropdown when clicking outside
                $(document).click(function () {
                    $(".dropdown-menu").hide();
                });
            },
            error: function (xhr, status, error) {
                console.error("Error fetching messages: " + error);
            }
        });
    }

    // Delete a message
    function deleteMessage(messageId) {
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to recover this message!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#d33",
            cancelButtonColor: "#3085d6",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "fetch_inbox.php",
                    type: "POST",
                    data: { delete_message_id: messageId },
                    success: function (response) {
                        if (response.trim() === "Message deleted successfully!") {
                            Swal.fire("Deleted!", "Your message has been deleted.", "success");
                            fetchMessages();
                        } else {
                            Swal.fire("Error!", response, "error");
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire("Error!", "An error occurred: " + error, "error");
                    }
                });
            }
        });
    }

    // Copy message to clipboard
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            Swal.fire("Copied!", "Message copied to clipboard.", "success");
        }).catch((err) => {
            Swal.fire("Error!", "Failed to copy message.", "error");
        });
    }

    // Send a message
    function sendMessage() {
        const message = messageInput.val().trim();
        const file = fileUpload[0].files[0];

        if (message || file) {
            // Try to send via PeerJS first
            const peerJSSuccess = message && !file ? sendMessageViaPeerJS(message) : false;
            
            if (!peerJSSuccess) {
                // Fall back to AJAX if PeerJS not available or for file uploads
                const formData = new FormData();
                formData.append("message", message);
                formData.append("receiver_id", <?= $friend_id ?>);
                if (file) formData.append("file", file);

                $.ajax({
                    url: "send_inbox.php",
                    type: "POST",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function (response) {
                        if (response.trim() === "Message sent successfully!") {
                            messageInput.val("");
                            fileUpload.val("");
                            fetchMessages();
                        } else {
                            Swal.fire("Error!", response, "error");
                        }
                    },
                    error: function (xhr, status, error) {
                        Swal.fire("Error!", "An error occurred: " + error, "error");
                    }
                });
            } else {
                // Message sent via PeerJS - add to UI immediately
                addMessageToChat(<?= $user_id ?>, message, new Date().toISOString(), true);
                messageInput.val("");
                
                // Still save to server for persistence
                $.ajax({
                    url: "send_inbox.php",
                    type: "POST",
                    data: {
                        message: message,
                        receiver_id: <?= $friend_id ?>,
                        via_peerjs: true
                    },
                    success: function(response) {
                        if (response.trim() !== "Message sent successfully!") {
                            console.error("Failed to save message to server:", response);
                        }
                    }
                });
            }
        } else {
            Swal.fire("Warning!", "Please enter a message or upload a file.", "warning");
        }
    }

    // Scroll to the bottom of the chat box
    function scrollToBottom() {
        chatBox.scrollTop(chatBox[0].scrollHeight);
        newMessageIndicator.hide();
    }

    // ===== STATUS TRACKING FUNCTIONS =====
    
    function sendHeartbeat(status) {
        console.log("Updating status to:", status);
        $.ajax({
            url: "update_status.php",
            method: "POST",
            data: { status: status },
            success: function(response) {
                console.log("Status update response:", response);
            },
            error: function(xhr, status, error) {
                console.error("Status update error:", error);
            }
        });
    }

    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        if (isTabActive) {
            sendHeartbeat(1);
            inactivityTimer = setTimeout(() => {
                sendHeartbeat(0);
            }, 60000); // 1 minute inactivity timeout
        }
    }

    // ===== EVENT LISTENERS =====
    
    // Chat event listeners
    $("#send-btn").click(function (e) {
        e.preventDefault();
        sendMessage();
    });

    messageInput.keypress(function (e) {
        if (e.which === 13) {
            e.preventDefault();
            sendMessage();
        }
    });

    fileUpload.change(function () {
        sendMessage();
    });

    // Track scroll position to determine if the user is at the bottom
    chatBox.on("scroll", function () {
        const scrollTop = chatBox.scrollTop();
        const scrollHeight = chatBox[0].scrollHeight;
        const clientHeight = chatBox[0].clientHeight;
        isUserAtBottom = scrollTop + clientHeight >= scrollHeight - 10; // 10px tolerance
    });

    // Status event listeners
    document.addEventListener('visibilitychange', function() {
        isTabActive = document.visibilityState === 'visible';
        sendHeartbeat(isTabActive ? 1 : 0);
        if (isTabActive) resetInactivityTimer();
    });

    window.addEventListener('beforeunload', function() {
        navigator.sendBeacon("update_status.php", new URLSearchParams({status: 0}));
    });

    ['mousemove', 'keypress', 'click', 'scroll'].forEach(event => {
        document.addEventListener(event, resetInactivityTimer);
    });

    // ===== INITIALIZATION =====
    
    // Initialize PeerJS and fetch initial messages
    initializePeerJS();
    fetchMessages();
    
    // Start checking friend's status
    checkFriendStatus();
    statusCheckInterval = setInterval(checkFriendStatus, 15000); // Check every 15 seconds
    
    // Set up initial inactivity timer
    resetInactivityTimer();
    
    // Periodically check connection status and fetch messages as fallback
    setInterval(function() {
        if (!conn || !conn.open) {
            fetchMessages();
            if (friendPeerId) {
                connectToFriend();
            }
        }
    }, 10000);
});
</script>
</body>
</html>