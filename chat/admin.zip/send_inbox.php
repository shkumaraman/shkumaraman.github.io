<?php
session_start();
include 'db.php';

// Check if user is logged in and receiver_id is provided
if (!isset($_SESSION['user_id']) || !isset($_POST['receiver_id'])) {
    die("Invalid request.");
}

$user_id = $_SESSION['user_id'];
$receiver_id = $_POST['receiver_id'];
$message = trim($_POST['message']);
$file = null;

// Fetch sender and receiver premium status from the database
$sql = "SELECT id, premium FROM users WHERE id IN (?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $receiver_id);
$stmt->execute();
$result = $stmt->get_result();

$premium_users = [];
while ($row = $result->fetch_assoc()) {
    $premium_users[$row['id']] = $row['premium'];
}

// Check if sender or receiver is premium (1 means premium, 0 means non-premium)
$sender_premium = isset($premium_users[$user_id]) ? $premium_users[$user_id] : 0;
$receiver_premium = isset($premium_users[$receiver_id]) ? $premium_users[$receiver_id] : 0;

// If both sender and receiver are non-premium, don't allow file upload
if (!$sender_premium && !$receiver_premium && isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
    die("Purchase a Premium Plan To Send Media Files.");
}

// Handle file upload if allowed
if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowed_types = ["jpg", "png", "jpeg", "gif", "pdf"];

    // Check file type
    if (in_array($imageFileType, $allowed_types)) {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
            $file = $target_file;
        } else {
            die("There was an error uploading the file.");
        }
    } else {
        die("Invalid file type. Only JPG, PNG, JPEG, GIF, or PDF are allowed.");
    }
}

// Insert message into the database
if (!empty($message) || !empty($file)) {
    $sql = "INSERT INTO inbox (sender_id, receiver_id, message, file) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiss", $user_id, $receiver_id, $message, $file);
    $stmt->execute();

    echo "Message sent successfully!";
} else {
    echo "Please enter a message or upload a file.";
}
?>
