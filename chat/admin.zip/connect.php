<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch current user's gender preference and tags
$sql_user_interests = "SELECT gender, tag_name FROM user_interests WHERE user_id = $user_id";
$result_user_interests = $conn->query($sql_user_interests);

$user_gender_preference = 'Both';
$user_tags = [];
$has_tags = false;

while ($row = $result_user_interests->fetch_assoc()) {
    if (!empty($row['gender'])) $user_gender_preference = $row['gender'];
    if (!empty($row['tag_name'])) {
        $user_tags[] = $row['tag_name'];
        $has_tags = true;
    }
}

// Get online users (excluding self)
$sql_online_users = "SELECT id, username FROM users WHERE status = 'online' AND id != $user_id";
$result_online_users = $conn->query($sql_online_users);

$connected_user = null;
$phase2_users = [];

while ($row = $result_online_users->fetch_assoc()) {
    $online_user_id = $row['id'];

    // Get online user's gender preference and tags
    $sql_online_user_interests = "SELECT gender, tag_name FROM user_interests WHERE user_id = $online_user_id";
    $result_online_user_interests = $conn->query($sql_online_user_interests);

    $online_gender_preference = 'Both';
    $online_tags = [];
    $online_has_tags = false;

    while ($tag_row = $result_online_user_interests->fetch_assoc()) {
        if (!empty($tag_row['gender'])) $online_gender_preference = $tag_row['gender'];
        if (!empty($tag_row['tag_name'])) {
            $online_tags[] = $tag_row['tag_name'];
            $online_has_tags = true;
        }
    }

    // Gender matching (strict)
    $gender_match = false;
    if ($user_gender_preference === 'Both' && $online_gender_preference === 'Both') {
        $gender_match = true;
    } elseif ($user_gender_preference === 'Male' && $online_gender_preference === 'Female') {
        $gender_match = true;
    } elseif ($user_gender_preference === 'Female' && $online_gender_preference === 'Male') {
        $gender_match = true;
    }

    $common_tags = array_intersect($user_tags, $online_tags);
    $both_no_tags = !$has_tags && !$online_has_tags;

    // Phase 1: Gender match + tag match / both no tags
    if ($gender_match && (!empty($common_tags) || $both_no_tags)) {
        $connected_user = $row;
        break;
    }

    // Save for Phase 2 (tag match or both no tags)
    if (!empty($common_tags) || $both_no_tags) {
        $phase2_users[] = $row;
    }
}

// Phase 2: Ignore gender, use tag match only
if (!$connected_user && !empty($phase2_users)) {
    $connected_user = $phase2_users[0];
}

if ($connected_user) {
    $connected_user_id = $connected_user['id'];
    $sql_insert_connection = "INSERT INTO chat_connections (user1_id, user2_id, connected_at) 
                              VALUES ($user_id, $connected_user_id, NOW())";
    if ($conn->query($sql_insert_connection)) {
        $sql_insert_history = "INSERT INTO connection_history (user1_id, user2_id, connection_time) 
                               VALUES ($user_id, $connected_user_id, NOW())";
        if ($conn->query($sql_insert_history)) {
            echo json_encode([
                'status' => 'success',
                'connected_username' => $connected_user['username'],
                'connected_user_id' => $connected_user_id
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to log connection history']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to create connection']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No matching user found']);
}
?>
