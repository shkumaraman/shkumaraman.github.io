<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized access.");
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_message_id'])) {
    $message_id = intval($_POST['delete_message_id']);

    $sql_check = "SELECT sender_id FROM inbox WHERE id = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("i", $message_id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        $message = $result_check->fetch_assoc();
        if ($message['sender_id'] == $user_id) {
            $sql_delete = "DELETE FROM inbox WHERE id = ?";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bind_param("i", $message_id);

            if ($stmt_delete->execute()) {
                echo "Message deleted successfully!";
            } else {
                echo "Error deleting message: " . $conn->error;
            }
        } else {
            echo "You can only delete your own messages.";
        }
    } else {
        echo "Message not found.";
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['user_id']) && isset($_GET['friend_id'])) {
    $friend_id = intval($_GET['friend_id']);

    $sql = "SELECT * FROM inbox 
            WHERE (sender_id = ? AND receiver_id = ?) 
            OR (sender_id = ? AND receiver_id = ?) 
            ORDER BY created_at ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $is_sent = ($row['sender_id'] == $user_id);
        $message_id = $row['id'];
        $message_content = htmlspecialchars($row['message']);
        $file_path = $row['file'];
        $is_text_only = empty($file_path); // Agar file nahi hai to text-only message hai

        $message_class = $is_sent ? 'sent' : 'received';
        ?>
        <div class="chat-message <?= $message_class ?>" data-message-id="<?= $message_id ?>">
            <div class="message-content">
                <p><?= $message_content ?></p>
                <?php if ($file_path): ?>
                    <br>
                    <img src="<?= $file_path ?>" class="uploaded-img" alt="Attached File">
                <?php endif; ?>
            </div>

            <!-- Three-dots menu -->
            <div class="three-dots" onclick="toggleDropdown(this)">...</div>
            <div class="dropdown-menu">
                <?php if ($is_text_only): ?>
                    <button class="copy-btn" data-message="<?= htmlspecialchars($row['message']) ?>">Copy</button>
                <?php endif; ?>
                <?php if ($is_sent): ?>
                    <button class="delete-btn" data-id="<?= $message_id ?>">Delete</button>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}
?>
