<?php
session_start();
include 'db.php';

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit();
}

// Fetch last 50 group messages with sender info
$sql = "SELECT * FROM (
    SELECT gc.*, u.username, u.profile_pic, u.verified 
    FROM group_chat gc
    JOIN users u ON gc.sender_id = u.id
    ORDER BY gc.timestamp DESC
    LIMIT 50
) AS recent_messages
ORDER BY timestamp ASC";
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $is_sent = $row['sender_id'] == $_SESSION['user_id'];
    $username = substr($row['username'], 0, 10);
    $profile_pic = $row['profile_pic'] ?: 'assets/default_dp.png';
    $verified_badge = $row['verified'] == 1 ? 
        '<img src="assets/verified.png" class="verified-badge" alt="Verified">' : '';
    $time = date("h:i A", strtotime($row['timestamp']));
    
    $media_html = '';
    if (!empty($row['media'])) {
        $media_html = '<img src="uploads/'.$row['media'].'" class="chat-image" alt="Sent image">';
    }
    
    echo '
    <div class="chat-message '.($is_sent ? 'sent' : 'received').'">
        '.($is_sent ? '' : '
        <div class="user-info">
            <img src="'.$profile_pic.'" class="user-avatar">
            <span class="username">'.$username.'</span>
            '.$verified_badge.'
        </div>
        ').'
        <div>'.htmlspecialchars($row['message']).'</div>
        '.$media_html.'
        <div class="message-time" style="text-align: '.($is_sent ? 'right' : 'left').'">
            '.$time.'
        </div>
    </div>';
}
?>