<?php
session_start();
include 'db.php';

// Fetch maintenance status from the settings table
$sql = "SELECT maintenance FROM settings LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $maintenance = $row['maintenance'];

    // Redirect to maintenance.html if maintenance mode is enabled
    if ($maintenance == 1) {
        header('Location: maintenance.html');
        exit();
    }
}

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');  // Redirect to dashboard if logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TalkRush - Chat with Strangers</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --primary-hover: #0077cc;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: rgba(255, 255, 255, 0.9);
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --error-color: #ed4956;
            --success-color: #4BB543;
        }

        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* Navbar Styles */
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: var(--card-bg);
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
            z-index: 1000;
            padding: 10px 0;
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            display: flex;
            align-items: center;
            color: var(--text-dark) !important;
            font-weight: 600;
            font-size: 20px;
        }

        .navbar-brand img {
            height: 32px;
            margin-right: 10px;
        }

        /* Main Container */
        .auth-container {
            max-width: 400px;
            width: 100%;
            margin: 80px auto 30px;
            padding: 0 15px;
            transition: all 0.3s ease;
        }

        /* Card Styles */
        .auth-card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            margin-bottom: 20px;
            backdrop-filter: blur(5px);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .auth-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.12);
        }

        /* Form Styles */
        .form-label {
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 8px;
            display: block;
        }

        .form-control {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 12px;
            font-size: 14px;
            background-color: var(--bg-color);
            transition: all 0.3s;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0, 149, 246, 0.1);
        }

        /* Button Styles */
        .btn {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            transition: all 0.3s;
            border: none;
        }

        .btn-primary {
            background-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 149, 246, 0.2);
        }

        .btn-danger {
            background-color: var(--error-color);
        }

        .btn-danger:hover {
            background-color: #d33446;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(237, 73, 86, 0.2);
        }

        /* Link Styles */
        .auth-link {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: color 0.3s;
        }

        .auth-link:hover {
            color: var(--primary-hover);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .auth-container {
                width: 100%;
                height: 100%;
                margin-top: 70px;
                padding: 0 10px;
            }

            .auth-card {
                padding: 20px;
            }

            .form-control {
                padding: 10px;
            }
        }
        
        /* Password match indicator */
        .password-match {
            font-size: 12px;
            margin-top: 5px;
            display: none;
        }

        .match {
            color: var(--success-color);
        }

        .no-match {
            color: var(--error-color);
        }

        /* Terms checkbox */
        .terms-checkbox {
            margin: 15px 0;
            font-size: 13px;
            display: flex;
            align-items: flex-start;
        }

        .terms-checkbox input {
            margin-right: 8px;
            margin-top: 3px;
        }

        .divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
        }

        .divider::before, .divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid var(--border-color);
        }

        .divider-text {
            padding: 0 10px;
            color: var(--secondary-color);
            font-size: 13px;
        }

        .hidden {
            display: none;
        }
        
        /* Enhanced Wave Animation */
        .wave-container {
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 200px;
            overflow: hidden;
            z-index: -1;
        }

        .wave {
            position: absolute;
            width: 200%;
            height: 100%;
            background-repeat: repeat-x;
            background-position: bottom;
            animation: animateWave 15s linear infinite;
        }

        .wave1 {
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1440 363" xmlns="http://www.w3.org/2000/svg"><path d="M0,160L48,165.3C96,171,192,181,288,186.7C384,192,480,192,576,186.7C672,181,768,171,864,160C960,149,1056,139,1152,138.7C1248,139,1344,149,1392,154.7L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z" fill="%2300c6ff"/></svg>');
            bottom: 0;
            opacity: 0.7;
            animation-delay: -5s;
        }

        .wave2 {
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1440 363" xmlns="http://www.w3.org/2000/svg"><path d="M0,200C80,190,160,170,240,165.3C320,160,400,160,480,165.3C560,170,640,180,720,192C800,204,880,216,960,213.3C1040,211,1120,197,1200,192C1280,187,1360,197,1400,202.7L1440,208L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z" fill="%230072ff"/></svg>');
            bottom: 0;
            opacity: 0.4;
            animation-duration: 20s;
            animation-delay: -2s;
        }

        .wave3 {
            background-image: url('data:image/svg+xml;utf8,<svg viewBox="0 0 1440 363" xmlns="http://www.w3.org/2000/svg"><path d="M0,120L48,128C96,136,192,152,288,154.7C384,157,480,147,576,138.7C672,131,768,125,864,128C960,131,1056,141,1152,149.3C1248,157,1344,163,1392,165.3L1440,168L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z" fill="%230095f6"/></svg>');
            bottom: 0;
            opacity: 0.2;
            animation-duration: 25s;
            animation-delay: 0s;
        }

        @keyframes animateWave {
            0% {
                transform: translateX(0) translateZ(0) scaleY(1);
            }
            50% {
                transform: translateX(-25%) translateZ(0) scaleY(0.8);
            }
            100% {
                transform: translateX(-50%) translateZ(0) scaleY(1);
            }
        }

        /* Floating animation for auth container */
        @keyframes float {
            0% {
                transform: translateY(0px);
            }
            50% {
                transform: translateY(-10px);
            }
            100% {
                transform: translateY(0px);
            }
        }

        .auth-container {
            animation: float 6s ease-in-out infinite;
        }

        /* Input focus effects */
        .form-control:focus {
            transform: scale(1.02);
        }

        /* Button active state */
        .btn:active {
            transform: translateY(0) !important;
        }
    </style>
</head>
<body>
    <!-- Header with Logo and Name -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="assets/logo.png" alt="TalkRush Logo">
                <span>TalkRush</span>
            </a>
        </div>
    </nav>

    <div class="auth-container">
        <!-- Login Form (shown by default) -->
        <div id="login-section">
            <div class="auth-card">
                <form action="login.php" method="POST">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" name="login" class="btn btn-primary mb-3">Login</button>
                    <div class="text-center">
                        <a href="forgot_password.php" class="auth-link">
                            <i class="fas fa-lock"></i> Forgot Password?
                        </a>
                    </div>
                </form>
                
                <div class="divider">
                    <span class="divider-text">OR</span>
                </div>
                
                <button class="btn btn-danger" onclick="showSignup()">Create a new Account</button>
            </div>
        </div>

        <!-- Signup Form (hidden by default) -->
        <div id="signup-section" class="hidden">
            <div class="auth-card">
                <form action="signup.php" method="POST" id="signupForm">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                        <small class="text-muted">Example: suruchi143</small>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="signup-email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="signup-password" name="password" required>
                        <small class="text-muted">Password must be at least 8 characters long</small>
                    </div>
                    <div class="mb-3">
                        <label for="confirm-password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm-password" name="confirm_password" required>
                        <div id="password-match" class="password-match"></div>
                    </div>
                    
                    <div class="terms-checkbox">
                        <input type="checkbox" id="terms" name="terms" required checked>
                        <label for="terms">I confirm that I am 18+ years old and agree to the Terms and Conditions and Community Guidelines</label>
                    </div>
                    
                    <button type="submit" name="signup" class="btn btn-danger" id="signup-button">Get Started</button>
                </form>
                
                <div class="divider">
                    <span class="divider-text">OR</span>
                </div>
                
                <button class="btn btn-primary" onclick="showLogin()">Already have an account? Login</button>
            </div>
        </div>
    </div>
    
    <div class="wave-container">
        <div class="wave wave1"></div>
        <div class="wave wave2"></div>
        <div class="wave wave3"></div>
    </div>

    <!-- Bootstrap Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function showSignup() {
            document.getElementById('login-section').classList.add('hidden');
            document.getElementById('signup-section').classList.remove('hidden');
            document.querySelector('.auth-container').style.animation = 'float 4s ease-in-out infinite';
        }
        
        function showLogin() {
            document.getElementById('signup-section').classList.add('hidden');
            document.getElementById('login-section').classList.remove('hidden');
            document.querySelector('.auth-container').style.animation = 'float 6s ease-in-out infinite';
        }

        document.addEventListener('DOMContentLoaded', function() {
            // Get elements
            const passwordField = document.getElementById('signup-password');
            const confirmPasswordField = document.getElementById('confirm-password');
            const passwordMatch = document.getElementById('password-match');
            const signupButton = document.getElementById('signup-button');
            
            // Check password requirements
            function checkPasswordRequirements() {
                const password = passwordField.value;
                const confirmPassword = confirmPasswordField.value;
                
                // Check minimum length
                if (password.length > 0 && password.length < 8) {
                    passwordMatch.textContent = 'Password must be at least 8 characters!';
                    passwordMatch.className = 'password-match no-match';
                    passwordMatch.style.display = 'block';
                    signupButton.disabled = true;
                    return false;
                }
                
                // Check if passwords match (only if both fields have values)
                if (password && confirmPassword) {
                    if (password === confirmPassword) {
                        passwordMatch.textContent = 'Passwords match!';
                        passwordMatch.className = 'password-match match';
                        passwordMatch.style.display = 'block';
                        signupButton.disabled = false;
                        return true;
                    } else {
                        passwordMatch.textContent = 'Passwords do not match!';
                        passwordMatch.className = 'password-match no-match';
                        passwordMatch.style.display = 'block';
                        signupButton.disabled = true;
                        return false;
                    }
                }
                
                passwordMatch.style.display = 'none';
                signupButton.disabled = false;
                return true;
            }
            
            // Run checks on keyup
            passwordField.addEventListener('keyup', checkPasswordRequirements);
            confirmPasswordField.addEventListener('keyup', checkPasswordRequirements);
            
            // Final validation before form submission
            document.getElementById('signupForm').addEventListener('submit', function(e) {
                const password = passwordField.value;
                
                // Check password length
                if (password.length < 8) {
                    e.preventDefault();
                    alert('Password must be at least 8 characters long!');
                    return;
                }
                
                // Check password match
                if (password !== confirmPasswordField.value) {
                    e.preventDefault();
                    alert('Passwords do not match!');
                    return;
                }
                
                // Check terms checkbox
                if (!document.getElementById('terms').checked) {
                    e.preventDefault();
                    alert('You must confirm that you are 18+ and agree to our Terms and Conditions');
                    return;
                }
            });
            
            // Add subtle hover effect to form inputs
            const inputs = document.querySelectorAll('.form-control');
            inputs.forEach(input => {
                input.addEventListener('mouseenter', () => {
                    input.style.transform = 'scale(1.02)';
                });
                input.addEventListener('mouseleave', () => {
                    input.style.transform = 'scale(1)';
                });
            });
        });
    </script>
</body>
</html>