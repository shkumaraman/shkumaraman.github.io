<?php
include('../db.php');

// Get bot token & admin ID from telegram table
$sql = "SELECT bot_token, admin_id FROM telegram LIMIT 1";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$bot_token = $row['bot_token'];
$admin_id = $row['admin_id'];

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data["message"])) {
    $message = $data["message"];
    $from = $message["from"];
    $chat_id = $message["chat"]["id"];
    $name = $from["first_name"] ?? "";
    $username = $from["username"] ?? "No username";
    $user_id = $from["id"];

    $text = $message["text"] ?? null;
    $photo = $message["photo"] ?? null;

    // ========== Build Admin Notification ==========
    $admin_msg = "New message from $name (@$username | $user_id):\n";
    if ($text) {
        $admin_msg .= "Text: $text\n";
    }

    // ========== If photo received, get image URL ==========
    $image_url = null;
    if ($photo) {
        $file_id = end($photo)["file_id"]; // highest resolution photo
        $get_file = "https://api.telegram.org/bot$bot_token/getFile?file_id=$file_id";
        $file_info = json_decode(file_get_contents($get_file), true);
        
        if (isset($file_info["result"]["file_path"])) {
            $file_path = $file_info["result"]["file_path"];
            $image_url = "https://api.telegram.org/file/bot$bot_token/$file_path";
            $admin_msg .= "Image: $image_url\n";
        } else {
            $admin_msg .= "Photo received, but unable to retrieve file path.\n";
        }
    }

    // Send admin the info
    file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$admin_id&text=" . urlencode($admin_msg));

    // ========== Handle /start ==========
    if (trim($text) == "/start") {
        $welcome = "Hi $name! Welcome to Anjaliya.\n\nPlease send a screenshot of your payment and your registered email.";
        file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$chat_id&text=" . urlencode($welcome));
        exit;
    }

    // ========== Check if both screenshot + email given ==========
    $email_found = false;
    if ($text && preg_match("/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/i", $text)) {
        $email_found = true;
    }

    if ($photo && $email_found) {
        $thanks = "Thank you! We have received your payment screenshot and email. We'll process your request shortly.";
        file_get_contents("https://api.telegram.org/bot$bot_token/sendMessage?chat_id=$chat_id&text=" . urlencode($thanks));
    }
}
?>
