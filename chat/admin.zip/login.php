<?php
include('init.php');
include('db.php');

// If the user is already logged in, redirect to the dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');  // Redirect to dashboard or another protected page
    exit();
}

$error = ''; // Variable to store error messages

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_email'] = $row['email'];
            header('Location: dashboard.php');
            exit();
        } else {
            $error = "The password you entered is incorrect";
        }
    } else {
        $error = "No account found with this email address";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Error</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
        :root {
            --error-color: #e74c3c;
            --error-light: #fdecea;
            --primary-color: #007bff;
            --dark-color: #2c3e50;
            --gray-color: #95a5a6;
        }
        
        body {
            background-color: #f4f4f4;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        
        .error-card {
            width: 100%;
            max-width: 450px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            animation: fadeInUp 0.5s ease-out;
        }
        
        .error-header {
            background-color: var(--error-color);
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .error-icon {
            font-size: 48px;
            margin-bottom: 15px;
        }
        
        .error-title {
            font-size: 22px;
            font-weight: 600;
            margin: 0;
        }
        
        .error-body {
            padding: 30px;
            text-align: center;
        }
        
        .error-message {
            color: var(--error-color);
            background-color: var(--error-light);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid var(--error-color);
            font-size: 16px;
        }
        
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #0069d9;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .btn-outline {
            background-color: transparent;
            border: 1px solid var(--gray-color);
            color: var(--dark-color);
        }
        
        .btn-outline:hover {
            background-color: #f0f0f0;
            transform: translateY(-2px);
        }
        
        .forgot-password {
            margin-top: 20px;
            font-size: 14px;
        }
        
        .forgot-password a {
            color: var(--gray-color);
            text-decoration: none;
            transition: color 0.2s;
        }
        
        .forgot-password a:hover {
            color: var(--primary-color);
            text-decoration: underline;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 576px) {
            .error-card {
                max-width: 100%;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 10px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php if (!empty($error)): ?>
    <div class="error-card">
        <div class="error-header">
            <div class="error-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h2 class="error-title">Login Failed</h2>
        </div>
        <div class="error-body">
            <div class="error-message">
                <i class="fas fa-info-circle"></i> <?php echo htmlspecialchars($error); ?>
            </div>
            
            <div class="action-buttons">
                <button class="btn btn-primary" onclick="window.history.back();">
                    <i class="fas fa-arrow-left"></i> Try Again
                </button>
                <button class="btn btn-outline" onclick="window.location.href='index.php'">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </div>
            
            <div class="forgot-password">
                <a href="forgot_password.php">
                    <i class="fas fa-key"></i> Forgot your password?
                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add animation when clicking buttons
        document.querySelectorAll('.btn').forEach(button => {
            button.addEventListener('mousedown', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>