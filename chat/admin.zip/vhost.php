<?php
require 'db.php';
session_start();

if (empty($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (!isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();
    $_SESSION['username'] = $username;
}

$username = $_SESSION['username'];
$msg = "";

// Check user premium status
$premiumCheck = $conn->prepare("SELECT premium FROM users WHERE id = ?");
$premiumCheck->bind_param("i", $user_id);
$premiumCheck->execute();
$premiumCheck->bind_result($is_premium);
$premiumCheck->fetch();
$premiumCheck->close();

// Get daily limit from settings table
$limitCheck = $conn->prepare("SELECT vroom_limit FROM settings LIMIT 1");
$limitCheck->execute();
$limitCheck->bind_result($daily_limit);
$limitCheck->fetch();
$limitCheck->close();

// Get user's activity count for today (both joins and creations)
$activityCountCheck = $conn->prepare("
    SELECT COUNT(*) FROM voice_joins 
    WHERE user_id = ? AND DATE(join_time) = CURDATE()
");
$activityCountCheck->bind_param("i", $user_id);
$activityCountCheck->execute();
$activityCountCheck->bind_result($activity_count);
$activityCountCheck->fetch();
$activityCountCheck->close();

$limit_exceeded = ($is_premium != 1 && $activity_count >= $daily_limit);

// Room deletion (host only)
if (isset($_GET['delete_room'])) {
    $del_id = (int)$_GET['delete_room'];

    // Step 1: Remove room_id link in voice_joins without deleting row
    $stmt = $conn->prepare("UPDATE voice_joins SET room_id = NULL WHERE room_id = ?");
    $stmt->bind_param("i", $del_id);
    $stmt->execute();
    $stmt->close();

    // Step 2: Now safely delete from voice
    $stmt = $conn->prepare("DELETE FROM voice WHERE id = ? AND host_user_id = ?");
    $stmt->bind_param("ii", $del_id, $user_id);
    $stmt->execute();
    $stmt->close();

    $msg = "Room deleted successfully.";
}

// Join by room code
if (isset($_GET['join_code'])) {
    if ($limit_exceeded) {
        $msg = "You've reached your daily limit of $daily_limit room activities. Upgrade to premium for unlimited access.";
    } else {
        $join_code = trim($_GET['join_code']);
        $stmt = $conn->prepare("SELECT id FROM voice WHERE room_code = ?");
        $stmt->bind_param("s", $join_code);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($room_id);
        if ($stmt->fetch()) {
            $stmt->close();
            
            // Record the join
            $recordJoin = $conn->prepare("INSERT INTO voice_joins (user_id, room_id) VALUES (?, ?)");
            $recordJoin->bind_param("ii", $user_id, $room_id);
            $recordJoin->execute();
            $recordJoin->close();
            
            header("Location: vroom.php?room_id=$room_id");
            exit;
        } else {
            $msg = "No active room found with that code.";
        }
        $stmt->close();
    }
}

// Host room
$showPremiumPopup = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($limit_exceeded) {
        $showPremiumPopup = true;
        $msg = "You've reached your daily limit of $daily_limit room activities. Upgrade to premium for unlimited access.";
    } else {
        // Check if user already has an active room (only for non-premium users)
        if ($is_premium != 1) {
            $checkActiveRoom = $conn->prepare("SELECT id FROM voice WHERE host_user_id = ?");
            $checkActiveRoom->bind_param("i", $user_id);
            $checkActiveRoom->execute();
            $checkActiveRoom->store_result();
            
            if ($checkActiveRoom->num_rows > 0) {
                $checkActiveRoom->bind_result($existing_room_id);
                $checkActiveRoom->fetch();
                $msg = "You already have an active room. <a href='vroom.php?room_id=$existing_room_id'>Go to Room</a>";
                $checkActiveRoom->close();
            } else {
                $checkActiveRoom->close();
                
                $max_users = (int)$_POST['max_users'];
                $room_code = isset($_POST['room_code']) && trim($_POST['room_code']) !== "" ? trim($_POST['room_code']) : null;

                if ($room_code !== null) {
                    $checkCode = $conn->prepare("SELECT id FROM voice WHERE room_code = ?");
                    $checkCode->bind_param("s", $room_code);
                    $checkCode->execute();
                    $checkCode->store_result();
                    if ($checkCode->num_rows > 0) {
                        $msg = "Room code already exists. Please choose a different one.";
                        $checkCode->close();
                    } else {
                        // Start transaction
                        $conn->begin_transaction();
                        
                        try {
                            $stmt = $conn->prepare("INSERT INTO voice (host_user_id, max_users, room_code) VALUES (?, ?, ?)");
                            $stmt->bind_param("iis", $user_id, $max_users, $room_code);
                            $stmt->execute();
                            $room_id = $stmt->insert_id;
                            $stmt->close();
                            
                            // Record the room creation as an activity with room_id
                            $recordActivity = $conn->prepare("INSERT INTO voice_joins (user_id, room_id, join_time) VALUES (?, ?, NOW())");
                            $recordActivity->bind_param("ii", $user_id, $room_id);
                            $recordActivity->execute();
                            $recordActivity->close();
                            
                            $conn->commit();
                            $msg = "Voice room created successfully.";
                        } catch (Exception $e) {
                            $conn->rollback();
                            $msg = "Error creating room: " . $e->getMessage();
                        }
                    }
                } else {
                    // Start transaction
                    $conn->begin_transaction();
                    
                    try {
                        $stmt = $conn->prepare("INSERT INTO voice (host_user_id, max_users) VALUES (?, ?)");
                        $stmt->bind_param("ii", $user_id, $max_users);
                        $stmt->execute();
                        $room_id = $stmt->insert_id;
                        $stmt->close();
                        
                        // Record the room creation as an activity with room_id
                        $recordActivity = $conn->prepare("INSERT INTO voice_joins (user_id, room_id, join_time) VALUES (?, ?, NOW())");
                        $recordActivity->bind_param("ii", $user_id, $room_id);
                        $recordActivity->execute();
                        $recordActivity->close();
                        
                        $conn->commit();
                        $msg = "Voice room created successfully.";
                    } catch (Exception $e) {
                        $conn->rollback();
                        $msg = "Error creating room: " . $e->getMessage();
                    }
                }
            }
        } else {
            // Premium users can create multiple rooms
            $max_users = (int)$_POST['max_users'];
            $room_code = isset($_POST['room_code']) && trim($_POST['room_code']) !== "" ? trim($_POST['room_code']) : null;

            if ($room_code !== null) {
                $checkCode = $conn->prepare("SELECT id FROM voice WHERE room_code = ?");
                $checkCode->bind_param("s", $room_code);
                $checkCode->execute();
                $checkCode->store_result();
                if ($checkCode->num_rows > 0) {
                    $msg = "Room code already exists. Please choose a different one.";
                    $checkCode->close();
                } else {
                    // Start transaction
                    $conn->begin_transaction();
                    
                    try {
                        $stmt = $conn->prepare("INSERT INTO voice (host_user_id, max_users, room_code) VALUES (?, ?, ?)");
                        $stmt->bind_param("iis", $user_id, $max_users, $room_code);
                        $stmt->execute();
                        $room_id = $stmt->insert_id;
                        $stmt->close();
                        
                        // Record the room creation as an activity with room_id
                        $recordActivity = $conn->prepare("INSERT INTO voice_joins (user_id, room_id, join_time) VALUES (?, ?, NOW())");
                        $recordActivity->bind_param("ii", $user_id, $room_id);
                        $recordActivity->execute();
                        $recordActivity->close();
                        
                        $conn->commit();
                        $msg = "Voice room created successfully.";
                    } catch (Exception $e) {
                        $conn->rollback();
                        $msg = "Error creating room: " . $e->getMessage();
                    }
                }
            } else {
                // Start transaction
                $conn->begin_transaction();
                
                try {
                    $stmt = $conn->prepare("INSERT INTO voice (host_user_id, max_users) VALUES (?, ?)");
                    $stmt->bind_param("ii", $user_id, $max_users);
                    $stmt->execute();
                    $room_id = $stmt->insert_id;
                    $stmt->close();
                    
                    // Record the room creation as an activity with room_id
                    $recordActivity = $conn->prepare("INSERT INTO voice_joins (user_id, room_id, join_time) VALUES (?, ?, NOW())");
                    $recordActivity->bind_param("ii", $user_id, $room_id);
                    $recordActivity->execute();
                    $recordActivity->close();
                    
                    $conn->commit();
                    $msg = "Voice room created successfully.";
                } catch (Exception $e) {
                    $conn->rollback();
                    $msg = "Error creating room: " . $e->getMessage();
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voice Chat Rooms</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
        <style>
    :root {
        --bg-color: #fafafa;
        --card-bg: #ffffff;
        --border-color: #dbdbdb;
        --text-dark: #262626;
        --primary: #4361ee;
        --primary-hover: #3a56d4;
        --primary-light: #eef2ff;
        --secondary: #f8f9fa;
        --text: #212529;
        --text-light: #6c757d;
        --border: #e9ecef;
        --success: #ffe4ec;
        --verified: #1da1f2;
        --private: #ff6b6b;
        --error: #ef4444;
        --card-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        --card-shadow-hover: 0 8px 15px rgba(0, 0, 0, 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        background-color: var(--bg-color);
        color: var(--text);
        padding: 20px;
        line-height: 1.5;
    }
    
    .header {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        width: 100%;
        background-color: var(--card-bg);
        color: var(--text-dark);
        padding: 12px 16px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid var(--border-color);
        box-shadow: var(--card-shadow);
    }

    .back-btn {
        background: transparent;
        border: none;
        color: var(--text-dark);
        font-size: 20px;
        cursor: pointer;
        padding: 8px;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: var(--transition);
    }

    .back-btn:hover {
        background-color: rgba(0, 0, 0, 0.05);
    }
    
    .container {
        max-width: 500px;
        margin: 70px auto 30px;
    }
    
    h1, h2, h3 {
        color: var(--text);
        margin-bottom: 1rem;
    }
    
    h2 {
        font-size: 1.4rem;
        font-weight: 600;
    }
    
    h3 {
        font-size: 1.1rem;
        font-weight: 500;
        color: var(--text-light);
    }
    
    .card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: var(--card-shadow);
        transition: var(--transition);
    }
    
    .form-group {
        margin-bottom: 1.5rem;
        position: relative;
    }
    
    label {
        display: block;
        font-weight: 500;
        margin-bottom: 0.5rem;
        color: var(--text);
        font-size: 0.95rem;
    }
    
    input, select {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid var(--border);
        border-radius: 8px;
        font-family: 'Inter', sans-serif;
        font-size: 0.95rem;
        transition: var(--transition);
        background-color: var(--card-bg);
    }
    
    select {
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%236b7280' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 12px center;
        background-size: 16px;
        padding-right: 36px;
    }
    
    input:focus, select:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
    }
    
    input::placeholder {
        color: var(--text-light);
        opacity: 0.6;
    }
    
    .btn {
        display: inline-block;
        background-color: var(--primary);
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 0.95rem;
        cursor: pointer;
        width: 100%;
        transition: var(--transition);
        text-align: center;
    }
    
    .btn:hover {
        background-color: var(--primary-hover);
    }
    
    .btn-secondary {
        background-color: var(--secondary);
        color: var(--text);
        border: 1px solid var(--border);
    }
    
    .btn-secondary:hover {
        background-color: #e9ecef;
    }
    
    .btn:disabled {
        background-color: #e5e7eb;
        color: #9ca3af;
        cursor: not-allowed;
    }
    
    .message {
        background-color: rgba(46, 204, 113, 0.1);
        border: 1px solid var(--success);
        padding: 12px 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-weight: 500;
        color: var(--text);
    }
    
    .message.error {
        background-color: rgba(239, 68, 68, 0.1);
        border-color: var(--error);
    }
    
    .room-list {
        margin-top: 2rem;
    }
    
    .room-item {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        box-shadow: var(--card-shadow);
        transition: var(--transition);
        position: relative;
    }
    
    .room-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        margin-right: 12px;
        flex-shrink: 0;
    }
    
    .room-info {
        flex-grow: 1;
    }
    
    .room-host {
        display: flex;
        align-items: center;
        font-weight: 600;
        margin-bottom: 4px;
    }
    
    .verified-badge {
        color: var(--verified);
        margin-left: 5px;
        font-size: 0.9rem;
    }
    
    .room-details {
        display: flex;
        align-items: center;
        font-size: 0.85rem;
        color: var(--text-light);
    }
    
    .user-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background-color: var(--secondary);
        color: var(--text);
        width: 24px;
        height: 24px;
        border-radius: 50%;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 8px;
    }
    
    .room-actions {
        display: flex;
        gap: 10px;
    }
    
    .action-btn {
        padding: 8px 12px;
        border-radius: 6px;
        font-weight: 500;
        font-size: 0.85rem;
        text-decoration: none;
        cursor: pointer;
        transition: var(--transition);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    
    .join-btn {
        background-color: var(--primary);
        color: white;
        border: none;
    }
    
    .full-btn {
        background-color: var(--secondary);
        color: var(--text-light);
        border: 1px solid var(--border);
        cursor: not-allowed;
    }
    
    .delete-btn {
        background-color: var(--secondary);
        color: var(--error);
        border: 1px solid #f1aeb5;
    }
    
    .join-btn:hover {
        background-color: var(--primary-hover);
    }
    
    .delete-btn:hover {
        background-color: #f1f3f5;
    }
    
    .private-badge {
        position: absolute;
        top: -8px;
        right: -8px;
        background-color: var(--private);
        color: white;
        padding: 3px 8px;
        border-radius: 12px;
        font-size: 0.7rem;
        font-weight: 600;
    }
    
    .empty-state {
        text-align: center;
        padding: 30px 0;
        color: var(--text-light);
    }
    
    .empty-state p {
        margin-top: 10px;
    }
    
    .tabs {
        display: flex;
        margin-bottom: 15px;
        border-bottom: 1px solid var(--border);
    }
    
    .tab {
        padding: 8px 16px;
        cursor: pointer;
        font-weight: 500;
        color: var(--text-light);
        border-bottom: 2px solid transparent;
        transition: var(--transition);
        flex: 1;
        text-align: center;
    }
    
    .tab.active {
        color: var(--primary);
        border-bottom: 2px solid var(--primary);
    }
    
    .tab-content {
        display: none;
    }
    
    .tab-content.active {
        display: block;
    }
    
    /* Form tabs container */
    .form-tabs-container {
        margin-bottom: 20px;
    }
    
    /* Room list tabs container */
    .room-tabs-container {
        margin-top: 20px;
    }
    
    /* Loading state */
    .btn-loading {
        display: none;
    }
    
    .btn.loading .btn-text {
        display: none;
    }
    
    .btn.loading .btn-loading {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .join-status {
    background-color: var(--success);
    border-left: 3px solid #4f46e5;
    padding: 6px 10px;
    border-radius: 5px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.04);
    max-width: 480px;
    margin: 12px auto;
}

.join-status p {
    margin: 6px 0;
    font-size: 15px;
    line-height: 1.3;
    color: #333;
}

.join-status .success {
    color: #16a34a;
    font-weight: 600;
}

.join-status .error {
    color: #dc2626;
    font-weight: 600;
}

.join-status a {
    color: #4f46e5;
    text-decoration: underline;
    font-weight: 500;
}

.join-status a:hover {
    text-decoration: none;
}

    @media (max-width: 600px) {
        body {
            padding: 15px;
        }
        
        .container {
            width: 100%;
            margin-top: 60px;
        }
        
        .room-actions {
            flex-direction: column;
            gap: 8px;
        }
        
        .action-btn {
            width: 100%;
            justify-content: center;
        }
    }
    
    .verified-badge {
        height: 16px;
        width: 16px;
        margin-left: 5px;
        vertical-align: middle;
    }
</style>
</head>
<body>
<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="window.location.href='voice.php'">
    <i class="fas fa-arrow-left"></i>
</button>
    <h4>Voice Chat Rooms</h4>
    <div style="width: 40px;"></div>
</div>
<div class="container">
    
    <?php if (!empty($msg)): ?>
        <div class="message <?php echo strpos($msg, 'limit') !== false ? 'error' : ''; ?>">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>
    
    <!-- Join Status -->
    <?php if ($is_premium != 1): ?>
    <div class="join-status">
        <p>Activities today: <?= $activity_count ?> / <?= $daily_limit ?></p>
        <?php if ($limit_exceeded): ?>
            <p class="error">Limit reached. <a href="plan.php">Go premium</a></p>
        <?php endif; ?>
    </div>
<?php endif; ?>
    
    <!-- Form Tabs -->
    <div class="form-tabs-container">
        <div class="tabs">
            <div class="tab active" onclick="switchFormTab('create')">Create Room</div>
            <div class="tab" onclick="switchFormTab('join')">Join Room</div>
        </div>
        
        <!-- Create Room Tab -->
        <div id="create-tab" class="tab-content active">
            <div class="card">
                <h2>Create New Room</h2>
                <form method="post" id="create-room-form">
                    <div class="form-group">
                        <label for="max_users">Room Capacity</label>
                        <select name="max_users" id="max_users" required>
                            <option value="2">1-on-1 Chat</option>
                            <option value="3">3 People Total</option>
                            <option value="4" selected>Group (4 People)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="room_code">Private Code (optional)</label>
                        <input type="text" name="room_code" id="room_code" maxlength="10" 
                               pattern="[A-Z0-9]{3,10}" title="3-10 uppercase alphanumeric characters"
                               placeholder="e.g. MUSIC123">
                    </div>
                    
                    <button type="submit" class="btn" id="create-room-btn" <?= $limit_exceeded ? 'onclick="showLimitAlert(\'creation\'); return false;"' : '' ?>>
                        <span class="btn-text"><?= $limit_exceeded ? 'Limit Reached' : 'Start Voice Room' ?></span>
                        <span class="btn-loading" style="display:none;">
                            <i class="fas fa-spinner fa-spin"></i> Creating...
                        </span>
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Join Room Tab -->
        <div id="join-tab" class="tab-content">
            <div class="card">
                <h2>Join Private Room</h2>
                <form method="get" id="join-room-form">
                    <div class="form-group">
                        <label for="join_code">Room Code</label>
                        <input type="text" name="join_code" id="join_code" maxlength="10" 
                               required pattern="[A-Z0-9]{3,10}" 
                               title="3-10 uppercase alphanumeric characters"
                               placeholder="Enter room code">
                    </div>
                    
                    <button type="submit" class="btn btn-secondary" id="join-room-btn" <?= $limit_exceeded ? 'onclick="showLimitAlert(\'join\'); return false;"' : '' ?>>
                        <span class="btn-text"><?= $limit_exceeded ? 'Limit Reached' : 'Join Room' ?></span>
                        <span class="btn-loading" style="display:none;">
                            <i class="fas fa-spinner fa-spin"></i> Joining...
                        </span>
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <!-- My Rooms -->
    <div class="room-tabs-container">
        <h3>My Rooms</h3>
        
        <?php 
        $my_rooms = $conn->query("
            SELECT v.id, v.max_users, v.user1_id, v.user2_id, v.user3_id, 
                   u.username, u.profile_pic, u.verified, v.host_user_id, v.room_code
            FROM voice v
            JOIN users u ON v.host_user_id = u.id
            WHERE v.host_user_id = $user_id
            ORDER BY v.created_at DESC
        ");
        
        if ($my_rooms->num_rows > 0): ?>
            <?php while ($row = $my_rooms->fetch_assoc()): ?>
                <?php
                // Count only guest users (not host)
                $count = 0;
                if ($row['user1_id']) $count++;
                if ($row['user2_id']) $count++;
                if ($row['user3_id']) $count++;
                
                $is_full = ($count >= ($row['max_users'] - 1));
                $profilePic = $row['profile_pic'] ? htmlspecialchars($row['profile_pic']) : 'assets/default_dp.png';
                $verifiedBadge = $row['verified'] == 1 ? 
                    '<img src="assets/verified.png" class="verified-badge" alt="Verified">' : '';
                ?>
                
                <div class="room-item">
                    <?php if ($row['room_code']): ?>
                        <span class="private-badge">Private</span>
                    <?php endif; ?>
                    <img src="<?= $profilePic ?>" alt="Profile" class="room-avatar">
                    <div class="room-info">
                        <div class="room-host">
                            <?= htmlspecialchars($row['username']) ?>
                            <?= $verifiedBadge ?>
                            <?php if ($row['room_code']): ?>
                                <small style="color: var(--text-light); margin-left: 8px;">
                                    Code: <?= htmlspecialchars($row['room_code']) ?>
                                </small>
                            <?php endif; ?>
                        </div>
                        <div class="room-details">
                            <span class="user-count" data-current="<?= $count ?>" data-max="<?= $row['max_users'] ?>">
                                <?= $count + 1 ?>
                            </span>
                            / <?= $row['max_users'] ?> connected
                        </div>
                    </div>
                    <div class="room-actions">
                        <!-- Host can always join -->
                        <a href="vroom.php?room_id=<?= $row['id'] ?>" class="action-btn join-btn">
                            <i class="fas fa-sign-in-alt"></i> Join
                        </a>
                        <a href="?delete_room=<?= $row['id'] ?>" class="action-btn delete-btn">
                            <i class="fas fa-trash"></i> End
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="empty-state">
                <h3>No rooms created yet</h3>
                <p>Create your first room above</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.17.2/dist/sweetalert2.all.min.js"></script>
<script>
// Switch between form tabs
function switchFormTab(tabName) {
    document.querySelectorAll('.form-tabs-container .tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.querySelectorAll('.form-tabs-container .tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.getElementById(tabName + '-tab').classList.add('active');
    event.currentTarget.classList.add('active');
}

// Show limit alert
function showLimitAlert(action) {
    Swal.fire({
        title: 'Daily Limit Reached',
        html: `<div style="text-align:left;">
                <p>You've used all ${<?= $daily_limit ?>} of your daily room ${action}s.</p>
                <p>Upgrade to premium for:</p>
                <ul style="text-align:left;padding-left:20px;margin-top:10px;">
                    <li>Unlimited room ${action}s</li>
                    <li>Priority access</li>
                    <li>Special badges</li>
                </ul>
               </div>`,
        icon: 'info',
        showCancelButton: true,
        confirmButtonColor: '#4361ee',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Upgrade Now',
        cancelButtonText: 'Not Now'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'plan.php';
        }
    });
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Confirm room deletion
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'End Room?',
                text: "Are you sure you want to end this room?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#4361ee',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, end it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = this.getAttribute('href');
                }
            });
        });
    });

    // Form handling
    const handleFormSubmit = (form, btnId) => {
        const formEl = document.getElementById(form);
        const btn = document.getElementById(btnId);
        
        if (formEl) {
            formEl.addEventListener('submit', function() {
                btn.classList.add('loading');
                btn.disabled = true;
            });
        }
    };

    handleFormSubmit('create-room-form', 'create-room-btn');
    handleFormSubmit('join-room-form', 'join-room-btn');
});

<?php if ($showPremiumPopup): ?>
document.addEventListener('DOMContentLoaded', function() {
    Swal.fire({
        title: 'Premium Feature',
        html: `<div style="text-align:left;">
                <p>You've reached your daily activity limit.</p>
                <p>Upgrade to unlock:</p>
                <ul style="text-align:left;padding-left:20px;margin-top:10px;">
                    <li>Unlimited room creations</li>
                    <li>Unlimited room joins</li>
                    <li>Priority access</li>
                    <li>Special badges</li>
                </ul>
               </div>`,
        icon: 'info',
        showCancelButton: true,
        confirmButtonColor: '#4361ee',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Upgrade Now',
        cancelButtonText: 'Not Now'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'plan.php';
        }
    });
});
<?php endif; ?>
</script>
</body>
</html>