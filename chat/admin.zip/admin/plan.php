<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Database connection
include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Handle form submission for adding/editing a plan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $duration = $_POST['duration'];
    $features = $_POST['features'];
    $is_discounted = isset($_POST['is_discounted']) ? 1 : 0;
    $discounted_price = isset($_POST['discounted_price']) ? (float)$_POST['discounted_price'] : 0;
    $discount_expiry = isset($_POST['discount_expiry']) ? $_POST['discount_expiry'] : null;

    if ($id > 0) {
        // Update existing plan
        $sql = "UPDATE plans SET name = ?, description = ?, price = ?, duration = ?, features = ?, 
                is_discounted = ?, discounted_price = ?, discount_expiry = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdssiisi", $name, $description, $price, $duration, $features, 
                         $is_discounted, $discounted_price, $discount_expiry, $id);
    } else {
        // Insert new plan
        $sql = "INSERT INTO plans (name, description, price, duration, features, 
                is_discounted, discounted_price, discount_expiry) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdssiis", $name, $description, $price, $duration, $features, 
                         $is_discounted, $discounted_price, $discount_expiry);
    }

    if ($stmt->execute()) {
        $_SESSION['success'] = $id > 0 ? "Plan updated successfully!" : "Plan added successfully!";
        header('Location: plan.php');
        exit();
    } else {
        $_SESSION['error'] = "Failed to save plan. Please try again.";
    }
}

// Handle plan deletion
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    $sql = "DELETE FROM plans WHERE id = $delete_id";
    $conn->query($sql);
    $_SESSION['success'] = "Plan deleted successfully!";
    header('Location: plan.php');
    exit();
}

// Fetch all plans
$sql = "SELECT * FROM plans ORDER BY id DESC;";
$result = $conn->query($sql);
$plans = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Plans</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --success-color: #4bb543;
            --danger-color: #e63946;
            --warning-color: #ff9f1c;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --card-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;            
            color: #333;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .container {
            margin-top: 90px;
            padding-bottom: 40px;
        }
        
        .card {
            border: none;
            border-radius: 12px;
            box-shadow: var(--card-shadow);
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 25px;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 15px 20px;
            font-weight: 600;
            border-bottom: none;
        }
        
        .form-card {
            border-left: 4px solid var(--primary-color);
        }
        
        .form-label {
            font-weight: 500;
            color: var(--dark-color);
            margin-bottom: 8px;
        }
        
        .form-control, .form-select {
            border-radius: 8px;
            padding: 10px 15px;
            border: 1px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.15);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.2);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(67, 97, 238, 0.3);
        }
        
        .btn-edit {
            background: linear-gradient(135deg, #4cc9f0, #4895ef);
            border: none;
            border-radius: 8px;
            padding: 10px;
            width: 100%;
            color: white;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-edit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(76, 201, 240, 0.3);
        }
        
        .btn-delete {
            background: linear-gradient(135deg, var(--danger-color), #d00000);
            border: none;
            border-radius: 8px;
            padding: 10px;
            width: 100%;
            margin-top: 10px;
            color: white;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(230, 57, 70, 0.3);
        }
        
        .plan-features {
            list-style-type: none;
            padding-left: 0;
            margin-top: 15px;
        }
        
        .plan-features li {
            padding: 6px 0;
            display: flex;
            align-items: center;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .plan-features li:last-child {
            border-bottom: none;
        }
        
        .plan-features li i {
            color: var(--success-color);
            margin-right: 10px;
            font-size: 14px;
        }
        
        .price-badge {
            background-color: rgba(75, 181, 67, 0.15);
            color: var(--success-color);
            padding: 5px 12px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
            margin: 5px 0;
        }
        
        .original-price {
            text-decoration: line-through;
            color: var(--gray-color);
            font-size: 0.9em;
            margin-right: 5px;
        }
        
        .discount-badge {
            background-color: rgba(255, 159, 28, 0.15);
            color: var(--warning-color);
            padding: 5px 12px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
            margin: 5px 0;
        }
        
        .duration-badge {
            background-color: rgba(76, 201, 240, 0.15);
            color: var(--primary-color);
            padding: 5px 12px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
            margin: 5px 0;
        }
        
        .expiry-badge {
            background-color: rgba(230, 57, 70, 0.15);
            color: var(--danger-color);
            padding: 5px 12px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
            margin: 5px 0;
            font-size: 0.8em;
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .discount-section {
            background-color: rgba(255, 159, 28, 0.05);
            border-radius: 8px;
            padding: 15px;
            margin-top: 15px;
            border-left: 3px solid var(--warning-color);
        }
        
        .modal-content {
            border: none;
            border-radius: 12px;
            overflow: hidden;
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-bottom: none;
        }
        
        .modal-title {
            font-weight: 600;
        }
        
        .btn-close {
            filter: invert(1);
        }
        
        .swal2-confirm {
            background-color: var(--primary-color) !important;
        }
        
        @media (max-width: 768px) {
            .container {
                margin-top: 80px;
            }
        }
    </style>
</head>
<body>

<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4 style="margin: 0; font-weight: 600;">Manage Plans</h4>
    <div></div> <!-- Empty div for spacing -->
</div>

<!-- Main Content -->
<div class="container">
    <!-- Success/Error Messages -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['success'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $_SESSION['error'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <!-- Add New Plan Form -->
    <div class="card form-card mb-4">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Create New Plan</h5>
        </div>
        <div class="card-body">
            <form method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="name" class="form-label">Plan Name</label>
                        <input type="text" class="form-control" id="name" name="name" placeholder="e.g., Premium Plan" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="price" class="form-label">Price (₹)</label>
                        <input type="number" class="form-control" id="price" name="price" step="0.01" placeholder="e.g., 499.00" required>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="2" placeholder="Short description of the plan" required></textarea>
                </div>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="duration" class="form-label">Duration (Days)</label>
                        <input type="number" class="form-control" id="duration" name="duration" placeholder="e.g., 30" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="features" class="form-label">Features (Comma separated)</label>
                        <textarea class="form-control" id="features" name="features" rows="2" placeholder="e.g., Unlimited chats, Priority support, Advanced analytics" required></textarea>
                    </div>
                </div>
                
                <!-- Discount Section -->
                <div class="discount-section">
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" role="switch" id="is_discounted" name="is_discounted" onclick="toggleDiscountFields()">
                        <label class="form-check-label fw-bold" for="is_discounted">Enable Discount</label>
                    </div>
                    
                    <div id="discountFields" style="display: none;">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="discounted_price" class="form-label">Discount Percentage</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" id="discounted_price" name="discounted_price" min="1" max="100" step="1" placeholder="e.g., 20">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="discount_expiry" class="form-label">Discount Expiry Date</label>
                                <input type="date" class="form-control" id="discount_expiry" name="discount_expiry" min="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary w-100 mt-2">
                    <i class="fas fa-save me-2"></i>Save Plan
                </button>
            </form>
        </div>
    </div>

    <!-- Plans List -->
    <h4 class="mb-4"><i class="fas fa-list-ul me-2"></i>Current Plans</h4>
    
    <?php if (empty($plans)): ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-box-open fa-3x mb-3 text-muted"></i>
                <h5 class="text-muted">No plans available</h5>
                <p class="text-muted">Create your first plan using the form above</p>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <?php foreach ($plans as $plan): 
                $is_discounted = $plan['is_discounted'];
                $discounted_price = $plan['discounted_price'];
                $discount_expiry = $plan['discount_expiry'];
                $has_active_discount = $is_discounted && (!$discount_expiry || strtotime($discount_expiry) >= time());
                $final_price = $has_active_discount ? $plan['price'] * (1 - ($discounted_price / 100)) : $plan['price'];
            ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title mb-0"><?= htmlspecialchars($plan['name']) ?></h5>
                                <div class="text-end">
                                    <?php if ($has_active_discount): ?>
                                        <span class="original-price">₹<?= number_format($plan['price'], 2) ?></span>
                                        <span class="price-badge">₹<?= number_format($final_price, 2) ?></span>
                                    <?php else: ?>
                                        <span class="price-badge">₹<?= number_format($plan['price'], 2) ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <p class="card-text text-muted small"><?= htmlspecialchars($plan['description']) ?></p>
                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="duration-badge">
                                    <i class="fas fa-calendar-alt me-1"></i> <?= $plan['duration'] ?> days
                                </span>
                                
                                <?php if ($has_active_discount): ?>
                                    <span class="discount-badge">
                                        <i class="fas fa-tag me-1"></i> <?= $discounted_price ?>% OFF
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($is_discounted && $discount_expiry): ?>
                                <div class="mb-3">
                                    <span class="expiry-badge">
                                        <i class="fas fa-clock me-1"></i> 
                                        <?= date('M d, Y', strtotime($discount_expiry)) ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <h6 class="mt-3 mb-2 fw-bold">Features:</h6>
                            <ul class="plan-features">
                                <?php
                                $features = explode(",", $plan['features']);
                                foreach ($features as $feature): ?>
                                    <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars(trim($feature)) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <div class="card-footer bg-transparent border-top-0 pt-0">
                            <button class="btn btn-edit" data-bs-toggle="modal" data-bs-target="#editPlanModal" 
                                data-id="<?= $plan['id'] ?>" 
                                data-name="<?= htmlspecialchars($plan['name']) ?>" 
                                data-description="<?= htmlspecialchars($plan['description']) ?>" 
                                data-price="<?= $plan['price'] ?>" 
                                data-duration="<?= $plan['duration'] ?>" 
                                data-features="<?= htmlspecialchars($plan['features']) ?>"
                                data-is_discounted="<?= $plan['is_discounted'] ?>"
                                data-discounted_price="<?= $plan['discounted_price'] ?>"
                                data-discount_expiry="<?= $plan['discount_expiry'] ?>">
                                <i class="fas fa-edit me-1"></i> Edit
                            </button>
                            <button class="btn btn-delete delete-btn" data-id="<?= $plan['id'] ?>">
                                <i class="fas fa-trash-alt me-1"></i> Delete
                            </button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Edit Plan Modal -->
<div class="modal fade" id="editPlanModal" tabindex="-1" aria-labelledby="editPlanModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit Plan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="editPlanForm" method="POST">
                    <input type="hidden" name="id" id="editPlanId">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editName" class="form-label">Plan Name</label>
                            <input type="text" class="form-control" id="editName" name="name" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editPrice" class="form-label">Price (₹)</label>
                            <input type="number" class="form-control" id="editPrice" name="price" step="0.01" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="editDescription" class="form-label">Description</label>
                        <textarea class="form-control" id="editDescription" name="description" rows="2" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editDuration" class="form-label">Duration (Days)</label>
                            <input type="number" class="form-control" id="editDuration" name="duration" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editFeatures" class="form-label">Features (Comma separated)</label>
                            <textarea class="form-control" id="editFeatures" name="features" rows="2" required></textarea>
                        </div>
                    </div>
                    
                    <!-- Discount Section in Modal -->
                    <div class="discount-section">
                        <div class="form-check form-switch mb-3">
                            <input class="form-check-input" type="checkbox" role="switch" id="editIsDiscounted" name="is_discounted" onclick="toggleEditDiscountFields()">
                            <label class="form-check-label fw-bold" for="editIsDiscounted">Enable Discount</label>
                        </div>
                        
                        <div id="editDiscountFields" style="display: none;">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="editDiscountedPrice" class="form-label">Discount Percentage</label>
                                    <div class="input-group">
                                        <input type="number" class="form-control" id="editDiscountedPrice" name="discounted_price" min="1" max="100" step="1">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="editDiscountExpiry" class="form-label">Discount Expiry Date</label>
                                    <input type="date" class="form-control" id="editDiscountExpiry" name="discount_expiry" min="<?= date('Y-m-d') ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i> Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Function to toggle discount fields in add form
    function toggleDiscountFields() {
        const discountFields = document.getElementById('discountFields');
        const isDiscounted = document.getElementById('is_discounted').checked;
        discountFields.style.display = isDiscounted ? 'block' : 'none';
        
        if (isDiscounted) {
            document.getElementById('discounted_price').required = true;
            document.getElementById('discount_expiry').required = true;
        } else {
            document.getElementById('discounted_price').required = false;
            document.getElementById('discount_expiry').required = false;
        }
    }
    
    // Function to toggle discount fields in edit form
    function toggleEditDiscountFields() {
        const discountFields = document.getElementById('editDiscountFields');
        const isDiscounted = document.getElementById('editIsDiscounted').checked;
        discountFields.style.display = isDiscounted ? 'block' : 'none';
        
        if (isDiscounted) {
            document.getElementById('editDiscountedPrice').required = true;
            document.getElementById('editDiscountExpiry').required = true;
        } else {
            document.getElementById('editDiscountedPrice').required = false;
            document.getElementById('editDiscountExpiry').required = false;
        }
    }
    
    // Populate the edit modal with plan data
    document.querySelectorAll('.btn-edit').forEach(button => {
        button.addEventListener('click', function () {
            const planId = this.getAttribute('data-id');
            const planName = this.getAttribute('data-name');
            const planDescription = this.getAttribute('data-description');
            const planPrice = this.getAttribute('data-price');
            const planDuration = this.getAttribute('data-duration');
            const planFeatures = this.getAttribute('data-features');
            const isDiscounted = this.getAttribute('data-is_discounted') === '1';
            const discountedPrice = this.getAttribute('data-discounted_price');
            const discountExpiry = this.getAttribute('data-discount_expiry');

            document.getElementById('editPlanId').value = planId;
            document.getElementById('editName').value = planName;
            document.getElementById('editDescription').value = planDescription;
            document.getElementById('editPrice').value = planPrice;
            document.getElementById('editDuration').value = planDuration;
            document.getElementById('editFeatures').value = planFeatures;
            
            // Set discount fields
            document.getElementById('editIsDiscounted').checked = isDiscounted;
            if (isDiscounted) {
                document.getElementById('editDiscountFields').style.display = 'block';
                document.getElementById('editDiscountedPrice').value = discountedPrice;
                document.getElementById('editDiscountExpiry').value = discountExpiry;
            } else {
                document.getElementById('editDiscountFields').style.display = 'none';
            }
            
            // Trigger change to set required fields
            toggleEditDiscountFields();
        });
    });

    // SweetAlert confirmation for delete
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const planId = this.getAttribute('data-id');

            Swal.fire({
                title: 'Delete Plan?',
                text: "This action cannot be undone!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e63946',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel',
                reverseButtons: true
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `plan.php?delete_id=${planId}`;
                }
            });
        });
    });
</script>
</body>
</html>