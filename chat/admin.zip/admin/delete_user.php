<?php
session_start();

// Check login
if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

include('../db.php');

// Verify current user is an admin
$admin_id = $_SESSION['user_id'];
$checkAdmin = $conn->prepare("SELECT admin FROM users WHERE id = ?");
$checkAdmin->bind_param("i", $admin_id);
$checkAdmin->execute();
$adminResult = $checkAdmin->get_result();

if (!$adminResult || $adminResult->num_rows === 0) {
    die("Admin check failed.");
}

$adminData = $adminResult->fetch_assoc();
if ($adminData['admin'] != 1) {
    die("You are not an admin.");
}

// Get target user ID
if (!isset($_GET['id'])) {
    die("User ID not provided.");
}
$user_id = (int)$_GET['id'];

// Prevent self-deletion
if ($user_id === $_SESSION['user_id']) {
    $_SESSION['error'] = "You cannot delete your own account.";
    header('Location: users.php');
    exit();
}

// Check if the target user is also an admin
$targetCheck = $conn->prepare("SELECT admin, profile_pic FROM users WHERE id = ?");
$targetCheck->bind_param("i", $user_id);
$targetCheck->execute();
$targetResult = $targetCheck->get_result();

if (!$targetResult || $targetResult->num_rows === 0) {
    $_SESSION['error'] = "User not found.";
    header('Location: users.php');
    exit();
}

$targetData = $targetResult->fetch_assoc();

// Prevent deletion of another admin
if ($targetData['admin'] == 1) {
    $_SESSION['error'] = "You cannot delete another admin.";
    header('Location: users.php');
    exit();
}

// Begin transaction
$conn->begin_transaction();

try {
    $conn->query("SET FOREIGN_KEY_CHECKS = 0");

    // First, handle story images and interactions
    $getStories = $conn->prepare("SELECT id, image_url FROM stories WHERE user_id = ?");
    $getStories->bind_param("i", $user_id);
    $getStories->execute();
    $storiesResult = $getStories->get_result();
    
    // Delete story images and interactions
    while ($story = $storiesResult->fetch_assoc()) {
        if (!empty($story['image_url']) && file_exists('../uploads/' . $story['image_url'])) {
            unlink('../uploads/' . $story['image_url']);
        }
        
        $deleteInteractions = $conn->prepare("DELETE FROM story_interactions WHERE group_id = ?");
        $deleteInteractions->bind_param("i", $story['id']);
        $deleteInteractions->execute();
    }
    
    // Delete the stories themselves
    $deleteStories = $conn->prepare("DELETE FROM stories WHERE user_id = ?");
    $deleteStories->bind_param("i", $user_id);
    $deleteStories->execute();
    
    // Delete user's story interactions
    $deleteUserInteractions = $conn->prepare("DELETE FROM story_interactions WHERE user_id = ?");
    $deleteUserInteractions->bind_param("i", $user_id);
    $deleteUserInteractions->execute();

    // NEW: Delete user's group chat messages
    $deleteGroupMessages = $conn->prepare("DELETE FROM group_chat WHERE sender_id = ?");
    $deleteGroupMessages->bind_param("i", $user_id);
    $deleteGroupMessages->execute();

    // Delete from all other related tables
    $tables = [
        'friend_requests' => ['sender_id', 'receiver_id'],
        'inbox' => ['sender_id', 'receiver_id'],
        'status' => ['user_id'],
        'user_interests' => ['user_id'],
        'connection_history' => ['user1_id', 'user2_id'],
        'voice' => ['host_user_id', 'user1_id', 'user2_id', 'user3_id']
    ];

    foreach ($tables as $table => $columns) {
        foreach ($columns as $column) {
            $stmt = $conn->prepare("DELETE FROM $table WHERE $column = ?");
            $stmt->bind_param("i", $user_id);
            if (!$stmt->execute()) {
                throw new Exception("Error deleting from $table.$column: " . $stmt->error);
            }
        }
    }

    // Delete profile picture if exists
    if (!empty($targetData['profile_pic']) && file_exists('../uploads/' . $targetData['profile_pic'])) {
        unlink('../uploads/' . $targetData['profile_pic']);
    }

    // Delete user record
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if (!$stmt->execute()) {
        throw new Exception("Error deleting user: " . $stmt->error);
    }

    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
    $conn->commit();

    $_SESSION['success'] = "User and all their data (including group messages) deleted successfully.";
} catch (Exception $e) {
    $conn->rollback();
    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
    $_SESSION['error'] = "Delete failed: " . $e->getMessage();
}

header('Location: users.php');
exit();
?>