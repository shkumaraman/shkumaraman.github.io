<?php
session_start();
include('../db.php');

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php');
    exit();
}

// Initialize variables
$message = '';
$show_message = false;
$connection_status = false;
$last_checked = 'Never';
$bot_username = '';
$bot_name = '';
$webhook_status = 'Not configured';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $bot_token = $conn->real_escape_string($_POST['bot_token']);
    $admin_id = intval($_POST['admin_id']);

    // Check if entry exists
    $check = $conn->query("SELECT id FROM telegram LIMIT 1");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE telegram SET bot_token='$bot_token', admin_id=$admin_id WHERE id=1");
    } else {
        $conn->query("INSERT INTO telegram (bot_token, admin_id) VALUES ('$bot_token', $admin_id)");
    }

    // Verify bot and set webhook if token exists
    if (!empty($bot_token)) {
        try {
            // 1. Verify bot token
            $api_url = "https://api.telegram.org/bot{$bot_token}/getMe";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $data = json_decode($response, true);
            
            if ($data && $data['ok'] === true) {
                $connection_status = true;
                $bot_username = $data['result']['username'] ?? '';
                $bot_name = $data['result']['first_name'] ?? '';
                
                // 2. Set up webhook
                $webhook_url = "https://".$_SERVER['HTTP_HOST']."/telegram/webhook.php";
                $api_url = "https://api.telegram.org/bot{$bot_token}/setWebhook?url={$webhook_url}";
                
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $api_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 5);
                $response = curl_exec($ch);
                curl_close($ch);
                
                $webhook_data = json_decode($response, true);
                
                if ($webhook_data && $webhook_data['ok'] === true) {
                    $webhook_status = "Active (URL: $webhook_url)";
                    $message = "Configuration saved successfully. Webhook configured!";
                } else {
                    $webhook_status = "Failed: " . ($webhook_data['description'] ?? 'Unknown error');
                    $message = "Configuration saved but webhook setup failed: " . $webhook_status;
                }
            } else {
                $message = "Configuration saved but bot verification failed: " . ($data['description'] ?? 'Unknown error');
            }
        } catch (Exception $e) {
            $message = "Configuration saved but bot setup failed: " . $e->getMessage();
        }
    } else {
        $message = "Configuration saved successfully. No bot token provided.";
    }
    
    $show_message = true;
    $last_checked = date('Y-m-d H:i:s');
}

// Fetch existing values
$row = ['bot_token' => '', 'admin_id' => ''];
$result = $conn->query("SELECT * FROM telegram LIMIT 1");
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Check current webhook info if token exists
    if (!empty($row['bot_token'])) {
        try {
            $bot_token = $row['bot_token'];
            
            // Get current webhook info
            $api_url = "https://api.telegram.org/bot{$bot_token}/getWebhookInfo";
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $api_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $webhook_info = json_decode($response, true);
            
            if ($webhook_info && $webhook_info['ok'] === true) {
                if (!empty($webhook_info['result']['url'])) {
                    $webhook_status = "Active (URL: ".$webhook_info['result']['url'].")";
                    if ($webhook_info['result']['has_custom_certificate']) {
                        $webhook_status .= " with custom certificate";
                    }
                    if ($webhook_info['result']['pending_update_count'] > 0) {
                        $webhook_status .= " - ".$webhook_info['result']['pending_update_count']." pending updates";
                    }
                } else {
                    $webhook_status = "Not active";
                }
            }
        } catch (Exception $e) {
            $webhook_status = "Error checking webhook: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Telegram</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
     <style>
        :root {
            --primary-color: #0088cc;
            --secondary-color: #f8f9fa;
            --text-dark: #212529;
            --text-light: #6c757d;
            --border-color: #dee2e6;
            --bg-color: #f5f7fb;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --card-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.05);
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            padding-top: 70px;
            color: var(--text-dark);
        }
        
        .admin-header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .config-card {
            background: white;
            border-radius: 10px;
            box-shadow: var(--card-shadow);
            padding: 2rem;
            margin-bottom: 2rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .form-label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
        }
        
        .form-control {
            padding: 0.75rem 1rem;
            border-radius: 8px;
            border: 1px solid var(--border-color);
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(0, 136, 204, 0.25);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            letter-spacing: 0.5px;
            transition: all 0.3s;
        }
        
        .btn-primary:hover {
            background-color: #006699;
            transform: translateY(-2px);
        }
        
        .telegram-icon {
            color: var(--primary-color);
            font-size: 2.5rem;
            margin-bottom: 1.5rem;
        }
        
        .section-title {
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--text-dark);
            text-align: center;
        }
        
        .alert-message {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            text-align: center;
        }
        
        .alert-success {
            background-color: rgba(40, 167, 69, 0.15);
            color: var(--success-color);
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .alert-danger {
            background-color: rgba(220, 53, 69, 0.15);
            color: var(--danger-color);
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .input-group-text {
            background-color: #e9ecef;
            border: 1px solid var(--border-color);
        }
        
        .bot-info {
            background-color: var(--secondary-color);
            border-radius: 8px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        
        @media (max-width: 768px) {
            .config-card {
                padding: 1.5rem;
            }
        }
    .webhook-status {
    background-color: #f8f9fa;
    border-radius: 8px;
    padding: 1rem;
    margin-top: 1rem;
    word-break: break-word;
}
    </style>
</head>
<body>
    <!-- Admin Header -->
    <div class="admin-header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4 class="mb-0">Manage Telegram</h4>
        <div style="width: 24px;"></div>
    </div>

    <div class="container py-4">
        <div class="config-card">
            <div class="text-center">
                <i class="fab fa-telegram telegram-icon"></i>
                <h2 class="section-title">Telegram Bot Configuration</h2>
            </div>

            <?php if ($show_message && !empty($message)): ?>
                <div class="alert-message <?php echo strpos($message, 'failed') !== false ? 'alert-danger' : 'alert-success'; ?>">
                    <i class="fas <?php echo strpos($message, 'failed') !== false ? 'fa-exclamation-circle' : 'fa-check-circle'; ?> me-2"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-4">
                    <label for="botToken" class="form-label">Bot Token</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                        <input type="text" class="form-control" id="botToken" name="bot_token" required 
                               value="<?php echo htmlspecialchars($row['bot_token']); ?>"
                               placeholder="Enter your Telegram bot token">
                    </div>
                    <small class="text-muted">Get this from @BotFather on Telegram</small>
                </div>

                <div class="mb-4">
                    <label for="adminId" class="form-label">Admin Telegram ID</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user-shield"></i></span>
                        <input type="number" class="form-control" id="adminId" name="admin_id" required 
                               value="<?php echo htmlspecialchars($row['admin_id']); ?>"
                               placeholder="Your Telegram user ID">
                    </div>
                    <small class="text-muted">Get your ID by messaging @userinfobot on Telegram</small>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="fas fa-save me-2"></i> Save Configuration
                    </button>
                </div>
            </form>
        </div>
        
        <div class="config-card">
            <h3 class="section-title">Bot Connection Status</h3>
            
            <?php if (empty($row['bot_token'])): ?>
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    No bot token configured. Please add your bot token above.
                </div>
            <?php else: ?>
                <div class="d-flex align-items-center mb-3">
                    <div class="me-3">
                        <div class="rounded-circle" style="width: 20px; height: 20px; background-color: <?php echo $connection_status ? 'var(--success-color)' : 'var(--danger-color)'; ?>"></div>
                    </div>
                    <div>
                        <h5 class="mb-0">Bot is <?php echo $connection_status ? 'connected' : 'not connected'; ?></h5>
                        <small class="text-muted">Last checked: <?php echo $last_checked; ?></small>
                    </div>
                </div>
                
                <?php if ($connection_status && !empty($bot_username)): ?>
                    <div class="bot-info mb-3">
                        <div class="row">
                            <div class="col-md-6">
                                <strong>Bot Name:</strong> <?php echo htmlspecialchars($bot_name); ?>
                            </div>
                            <div class="col-md-6">
                                <strong>Username:</strong> @<?php echo htmlspecialchars($bot_username); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="webhook-status">
                        <h5>Webhook Status</h5>
                        <p><?php echo htmlspecialchars($webhook_status); ?></p>
                    </div>
                <?php endif; ?>
                
                <?php if (!$connection_status): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        Could not connect to the bot. Please check your token and internet connection.
                    </div>
                <?php endif; ?>
                
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    Webhook will be automatically configured when you save the bot token.
                </div>
                
                <div class="d-flex">
                    <a href="https://t.me/<?php echo $bot_username; ?>" class="btn btn-outline-primary me-2" target="_blank" <?php echo empty($bot_username) ? 'disabled' : ''; ?>>
                        <i class="fas fa-paper-plane me-2"></i>Open Chat
                    </a>
                    <a href="https://core.telegram.org/bots/api" class="btn btn-outline-info" target="_blank">
                        <i class="fas fa-book me-2"></i>API Docs
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>