<?php
session_start();

// Check if the user is logged in and is an admin (admin = 1)
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Database connection
include('../db.php');

// Fetch admin details
$admin_id = $_SESSION['user_id'];
$sql = "SELECT admin FROM users WHERE id = $admin_id";
$result = $conn->query($sql);
$admin = $result->fetch_assoc();

// Check if the user is an admin
if ($admin['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Fetch user details to edit
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $sql = "SELECT id, username, email, admin, premium, verified, premium_expiry FROM users WHERE id = $user_id";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    // Calculate remaining premium days
    if ($user['premium_expiry']) {
        $current_date = new DateTime();
        $expiry_date = new DateTime($user['premium_expiry']);
        $interval = $current_date->diff($expiry_date);
        $premium_days = $interval->days;
    } else {
        $premium_days = 0;
    }
} else {
    header('Location: users.php'); // Redirect if no user ID is provided
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $admin = isset($_POST['admin']) ? 1 : 0;
    $premium = isset($_POST['premium']) ? 1 : 0;
    $premium_days = isset($_POST['premium_days']) ? (int)$_POST['premium_days'] : 0;

    // Set verified based on premium status
    $verified = $premium ? 1 : 0;

    // Calculate premium expiry date (format: YYYY-MM-DD)
    $premium_expiry = null;
    if ($premium && $premium_days > 0) {
        $premium_expiry = date('Y-m-d', strtotime("+$premium_days days"));
    }

    // Update user details in the database
    $sql = "UPDATE users 
            SET username = '$username', 
                email = '$email', 
                admin = $admin, 
                premium = $premium, 
                verified = $verified, 
                premium_expiry = '$premium_expiry' 
            WHERE id = $user_id";
    $conn->query($sql);

    // Redirect back to users.php
    header('Location: users.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --bg-color: #ffffff;
            --text-color: #121212;
            --card-bg: #f8f9fa;
            --border-color: #e0e0e0;
            --primary-color: #4361ee;
            --hover-color: #f0f0f0;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --bg-color: #121212;
                --text-color: #f8f9fa;
                --card-bg: #1e1e1e;
                --border-color: #2e2e2e;
                --primary-color: #5a72f5;
                --hover-color: #2a2a2a;
            }
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background-color: var(--bg-color);
            color: var(--text-color);
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        .form-container {
            margin-top: 80px;
            padding: 20px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .form-control, .form-select {
            background-color: var(--bg-color);
            color: var(--text-color);
            border: 1px solid var(--border-color);
            padding: 10px 15px;
            border-radius: 8px;
        }

        .form-control:focus, .form-select:focus {
            background-color: var(--bg-color);
            color: var(--text-color);
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
        }

        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary {
            background-color: var(--primary-color);
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 500;
            width: 100%;
            margin-top: 10px;
        }

        .btn-primary:hover {
            background-color: #3a56d4;
        }

        .form-label {
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-check-label {
            margin-left: 8px;
        }

        .toggle-container {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
            margin-right: 10px;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 24px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: var(--primary-color);
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4 style="margin: 0; font-weight: 600;">Edit User</h4>
        <div style="width: 40px;"></div> <!-- Empty div for spacing -->
    </div>

    <!-- Main Content -->
    <div class="form-container">
        <div class="card">
            <form method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                </div>
                
                <div class="mb-3 toggle-container">
                    <label class="toggle-switch">
                        <input type="checkbox" class="form-check-input" id="admin" name="admin" <?= $user['admin'] ? 'checked' : '' ?>>
                        <span class="slider"></span>
                    </label>
                    <label class="form-check-label" for="admin">Admin Privileges</label>
                </div>
                
                <div class="mb-3 toggle-container">
                    <label class="toggle-switch">
                        <input type="checkbox" class="form-check-input" id="premium" name="premium" <?= $user['premium'] ? 'checked' : '' ?>>
                        <span class="slider"></span>
                    </label>
                    <label class="form-check-label" for="premium">Premium Membership</label>
                </div>
                
                <div class="mb-3">
                    <label for="premium_days" class="form-label">Premium Days Remaining</label>
                    <input type="number" class="form-control" id="premium_days" name="premium_days" value="<?= $premium_days ?>" min="0" required>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i>Save Changes
                </button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const premiumCheckbox = document.getElementById('premium');
        const premiumDaysInput = document.getElementById('premium_days');

        function togglePremiumDays() {
            premiumDaysInput.disabled = !premiumCheckbox.checked;
            if (!premiumCheckbox.checked) premiumDaysInput.value = '0';
        }

        premiumCheckbox.addEventListener('change', togglePremiumDays);
        togglePremiumDays(); // Initial state set karega
    });
</script>

</body>
</html>