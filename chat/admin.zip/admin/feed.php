<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Database connection
include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Handle post deletion
if (isset($_POST['action']) && $_POST['action'] === 'delete_post') {
    $feed_id = (int)$_POST['feed_id'];
    
    // Delete associated image file if exists
    $feed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM feeds WHERE id = $feed_id"));
    if (!empty($feed['image']) && file_exists($feed['image'])) {
        unlink($feed['image']);
    }
    
    // Delete from database
    mysqli_query($conn, "DELETE FROM feeds WHERE id = $feed_id");
    mysqli_query($conn, "DELETE FROM feed_reactions WHERE feed_id = $feed_id");
    mysqli_query($conn, "DELETE FROM reports WHERE feed_id = $feed_id");
    
    echo "Post deleted successfully";
    exit();
}

// Handle report clearance - MODIFIED THIS SECTION
if (isset($_POST['action']) && $_POST['action'] === 'clear_report') {
    $feed_id = (int)$_POST['feed_id'];
    
    // Delete ALL reports for this feed
    mysqli_query($conn, "DELETE FROM reports WHERE feed_id = $feed_id");
    
    echo "All reports for this post cleared successfully";
    exit();
}

// Fetch all reported posts
$reported_posts = mysqli_query($conn, "
    SELECT f.*, u.username, u.profile_pic, 
    COUNT(r.id) AS report_count,
    GROUP_CONCAT(r.reason SEPARATOR '|||') AS reasons,
    GROUP_CONCAT(u2.username SEPARATOR '|||') AS reporters,
    GROUP_CONCAT(r.created_at SEPARATOR '|||') AS report_times
    FROM feeds f
    JOIN reports r ON f.id = r.feed_id
    JOIN users u ON f.user_id = u.id
    JOIN users u2 ON r.user_id = u2.id
    GROUP BY f.id
    ORDER BY MAX(r.created_at) DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Feed Reports</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
        <style>
        :root {
            --primary: #1877f2;
            --danger: #dc3545;
            --background: #f8f9fa;
            --card-bg: #ffffff;
            --text: #212529;
            --text-secondary: #6c757d;
            --border: #e0e0e0;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
          }
        
        body {
            background-color: var(--background);
            color: var(--text);
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .header h4 {
            margin: 0;
            font-weight: 600;
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .reported-post {
            background: var(--card-bg);
            border-radius: 8px;
            margin: 70px 0 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            border-left: 4px solid var(--danger);
        }
        
        .post-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px;
            background: rgba(220, 53, 69, 0.05);
            border-bottom: 1px solid var(--border);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        
        .user-info div small {
            color: var(--text-secondary);
            font-size: 13px;
            display: block;
        }
        
        .report-count {
            background: var(--danger);
            color: white;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: bold;
        }
        
        .post-content {
            padding: 15px;
        }
        
        .post-content p {
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .post-image {
            width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 4px;
            margin-top: 10px;
        }
        
        .reports-list {
            border-top: 1px solid var(--border);
            padding: 15px;
        }
        
        .report-item {
            padding: 12px 0;
            border-bottom: 1px solid rgba(0,0,0,0.05);
        }
        
        .report-item:last-child {
            border-bottom: none;
        }
        
        .report-reason {
            margin-bottom: 5px;
            font-size: 15px;
        }
        
        .report-meta {
            display: flex;
            justify-content: space-between;
            color: var(--text-secondary);
            font-size: 13px;
        }
        
        .post-actions {
            display: flex;
            justify-content: flex-end;
            padding: 15px;
            border-top: 1px solid var(--border);
            gap: 10px;
        }
        
        .action-btn {
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            border: none;
        }
        
        .delete-btn {
            background: var(--danger);
            color: white;
        }
        
        .clear-btn {
            background: var(--primary);
            color: white;
        }
        
        .no-reports {
            text-align: center;
            padding: 50px;
            color: var(--text-secondary);
            font-size: 18px;
        }
        
        @media (max-width: 768px) {
            .post-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
            
            .post-actions {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Manage Feed Reports</h4>
        <div></div> <!-- Empty div for spacing -->
    </div>

    <?php if (mysqli_num_rows($reported_posts) > 0): ?>
        <?php while ($post = mysqli_fetch_assoc($reported_posts)): ?>
            <div class="reported-post" id="post-<?php echo $post['id']; ?>">
                <div class="post-header">
                    <div class="user-info">
                        <img src="<?php echo !empty($post['profile_pic']) ? $post['profile_pic'] : 'assets/default_dp.png'; ?>" onerror="this.src='assets/default_dp.png'">
                        <div>
                            <strong><?php echo htmlspecialchars($post['username']); ?></strong>
                            <small><?php echo date('M j, Y g:i A', strtotime($post['created_at'])); ?></small>
                        </div>
                    </div>
                    <span class="report-count"><?php echo $post['report_count']; ?> Reports</span>
                </div>
                
                <div class="post-content">
                    <p><?php echo htmlspecialchars($post['text']); ?></p>
                    <?php if (!empty($post['image'])): ?>
                        <img src="<?php echo $post['image']; ?>" class="post-image" onerror="this.style.display='none'">
                    <?php endif; ?>
                </div>
                
                <div class="reports-list">
                    <h3>Reports:</h3>
                    <?php 
                    // Split the concatenated report data
                    $reasons = explode('|||', $post['reasons']);
                    $reporters = explode('|||', $post['reporters']);
                    $report_times = explode('|||', $post['report_times']);
                    
                    for ($i = 0; $i < count($reasons); $i++): ?>
                        <div class="report-item">
                            <p class="report-reason"><?php echo htmlspecialchars($reasons[$i]); ?></p>
                            <div class="report-meta">
                                <span>Reported by: <?php echo htmlspecialchars($reporters[$i]); ?></span>
                                <span><?php echo date('M j, Y g:i A', strtotime($report_times[$i])); ?></span>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
                
                <div class="post-actions">
                    <button class="action-btn clear-btn" onclick="clearReports(<?php echo $post['id']; ?>)">
                        Clear Reports
                    </button>
                    <button class="action-btn delete-btn" onclick="deletePost(<?php echo $post['id']; ?>)">
                        Delete Post
                    </button>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="no-reports">
            No reported posts found. Everything looks clean!
        </div>
    <?php endif; ?>

    <!-- SweetAlert JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
    function deletePost(feedId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('feed.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: `action=delete_post&feed_id=${feedId}`
                }).then(response => response.text())
                .then(message => {
                    Swal.fire(
                        'Deleted!',
                        'The post has been deleted.',
                        'success'
                    );
                    document.getElementById(`post-${feedId}`).remove();
                }).catch(error => {
                    Swal.fire(
                        'Error!',
                        'There was an error deleting the post.',
                        'error'
                    );
                });
            }
        });
    }
    
    // Modified this function to clear ALL reports for the post
    function clearReports(feedId) {
        Swal.fire({
            title: 'Clear All Reports?',
            text: "This will remove all reports for this post but keep the post itself.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, clear them!'
        }).then((result) => {
            if (result.isConfirmed) {
                fetch('feed.php', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: `action=clear_report&feed_id=${feedId}`
                }).then(response => response.text())
                .then(message => {
                    Swal.fire(
                        'Cleared!',
                        'All reports for this post have been cleared.',
                        'success'
                    );
                    document.getElementById(`post-${feedId}`).remove();
                }).catch(error => {
                    Swal.fire(
                        'Error!',
                        'There was an error clearing the reports.',
                        'error'
                    );
                });
            }
        });
    }
    </script>
</body>
</html>