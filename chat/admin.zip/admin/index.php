<?php
session_start();

// Check if the user is logged in and is an admin (admin = 1)
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Database connection
include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

date_default_timezone_set('Asia/Kolkata');

// Fetch total number of users
$sql_total_users = "SELECT COUNT(*) as total_users FROM users";
$result_total_users = $conn->query($sql_total_users);
$total_users = $result_total_users->fetch_assoc()['total_users'];

// Fetch number of active users (from users table status='online', vcstatus='online', and active_status=1)
$sql_active_users = "
    SELECT COUNT(DISTINCT u.id) as active_users 
    FROM users u
    LEFT JOIN status s ON u.id = s.user_id
    WHERE (u.status = 'online' OR s.vcstatus = 'online' OR u.active_status = 1)";
$result_active_users = $conn->query($sql_active_users);
$active_users = $result_active_users->fetch_assoc()['active_users'];

// Fetch number of daily active users (last_activity within last 24 hours)
$sql_daily_active = "
    SELECT COUNT(*) as daily_active_users 
    FROM users 
    WHERE last_activity >= CONVERT_TZ(NOW(), '+00:00', '+05:30') - INTERVAL 24 HOUR";
$result_daily_active = $conn->query($sql_daily_active);
$daily_active_users = $result_daily_active->fetch_assoc()['daily_active_users'];

// Fetch users not active in last 24 hours
$sql_inactive_24h = "
    SELECT COUNT(*) as inactive_24h 
    FROM users 
    WHERE last_activity < DATE_SUB(NOW(), INTERVAL 24 HOUR) 
    OR last_activity IS NULL";
$result_inactive_24h = $conn->query($sql_inactive_24h);
$inactive_24h = $result_inactive_24h->fetch_assoc()['inactive_24h'];

// Fetch today's active users (from midnight to midnight)
$sql_today_active = "
    SELECT COUNT(*) as today_active_users 
    FROM users 
    WHERE last_activity >= CURDATE() 
    AND last_activity < DATE_ADD(CURDATE(), INTERVAL 1 DAY)";
$result_today_active = $conn->query($sql_today_active);
$today_active_users = $result_today_active->fetch_assoc()['today_active_users'];

// Fetch gender distribution
$sql_gender = "SELECT 
    SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) as male_count,
    SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) as female_count,
    COUNT(*) as total_gender
    FROM users 
    WHERE gender IN ('Male', 'Female')";
$result_gender = $conn->query($sql_gender);
$gender_data = $result_gender->fetch_assoc();

$male_count = $gender_data['male_count'];
$female_count = $gender_data['female_count'];
$total_gender = $gender_data['total_gender'];

// Calculate percentages
$male_percent = $total_gender > 0 ? round(($male_count / $total_gender) * 100, 2) : 0;
$female_percent = $total_gender > 0 ? round(($female_count / $total_gender) * 100, 2) : 0;

// Fetch hourly activity for today
$sql_hourly_activity = "
    SELECT 
        HOUR(CONVERT_TZ(last_activity, '+00:00', '+05:30')) as hour,
        COUNT(*) as user_count
    FROM users
    WHERE CONVERT_TZ(last_activity, '+00:00', '+05:30') >= CONVERT_TZ(CURDATE(), '+00:00', '+05:30')
    GROUP BY hour
    ORDER BY hour";
$result_hourly = $conn->query($sql_hourly_activity);
$hourly_data = [];
while ($row = $result_hourly->fetch_assoc()) {
    $hourly_data[$row['hour']] = $row['user_count'];
}

// Prepare data for chart
$hours = range(0, 23);
$hourly_counts = [];
foreach ($hours as $hour) {
    $hourly_counts[] = isset($hourly_data[$hour]) ? $hourly_data[$hour] : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
<!-- Latest Bootstrap CSS from jsDelivr -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Latest Font Awesome CSS from jsDelivr -->
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --success-color: #28a745;
            --warning-color: #ffc107;
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            padding-top: 70px;
        }

        .welcome-container {
            border: 1px solid #e0e0e0;
            text-align: center;
            margin: 20px 0 30px;
            padding: 15px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }

        .slide-menu {
            height: 100%;
            width: 280px;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: -280px;
            background-color: white;
            overflow-x: hidden;
            transition: 0.4s;
            padding-top: 70px;
            box-shadow: 2px 0 15px rgba(0,0,0,0.1);
        }

        .slide-menu.open {
            left: 0;
        }

        .slide-menu a {
            padding: 12px 20px;
            text-decoration: none;
            font-size: 16px;
            color: #333;
            display: block;
            transition: all 0.3s;
            border-left: 4px solid transparent;
            margin: 5px 0;
            font-weight: 500;
        }

        .slide-menu a:hover {
            background-color: #f5f5f5;
            color: #0095f6;
            border-left: 4px solid #0095f6;
        }

        .slide-menu a i {
            margin-right: 12px;
            width: 20px;
            text-align: center;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: black;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
       
        .header button:hover {
            background-color: #f5f5f5;
            border-radius: 50%;
        }

        .header button {
            background: none;
            border: none;
            color: #333;
            font-size: 22px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }

        .user-stats .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            background: white;
            margin-bottom: 20px;
            height: 100%;
        }

        .user-stats .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }

        .user-stats .card-body {
            padding: 25px;
        }

        .user-stats .card-title {
            font-size: 16px;
            font-weight: 600;
            color: #666;
            margin-bottom: 10px;
        }

        .user-stats .card-text {
            font-size: 28px;
            font-weight: 700;
            color: #0095f6;
        }

        .user-stats .card-subtext {
            font-size: 14px;
            color: #8e8e8e;
        }

        .chart-container {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        @media (max-width: 768px) {
            .slide-menu {
                width: 240px;
                left: -240px;
            }
            
            .slide-menu.open {
                left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- The Slide Menu -->
    <div id="slideMenu" class="slide-menu">
        <a href="#"><i class="fas fa-home"></i> Home</a>
        <a href="users.php"><i class="fas fa-users"></i> Users</a>
        <a href="plan.php"><i class="fas fa-clipboard-list"></i> Plan</a>
        <a href="notification.php"><i class="fas fa-bell"></i> Notification</a>
        <a href="manage.php"><i class="fas fa-folder"></i> Manage Files</a>
        <a href="feed.php"><i class="fas fa-newspaper"></i> Feed Reports</a>
        <a href="broadcast.php"><i class="fas fa-bullhorn"></i> Broadcast</a>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        <a href="telegram.php"><i class="fab fa-telegram"></i> Manage Telegram</a>
        <a href="connect.php"><i class="fas fa-shuffle"></i> Connection</a>
        <a href="voice.php"><i class="fas fa-headset"></i> Voice</a>
        <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
    </div>

    <!-- Menu Button (Hamburger Icon) -->
    <div class="header">
        <button class="menu-btn" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </button>
        <h5 class="mb-0">Admin Dashboard</h5>
        <div style="width: 40px;"></div> <!-- Spacer for alignment -->
    </div>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Welcome Message -->
        <div class="welcome-container">
            <h2>Welcome <?php echo htmlspecialchars($user['username']); ?></h2>
            <p class="mb-0"><?php echo date('l, F j, Y'); ?></p>
        </div>
        
        <div class="alert alert-dark" role="alert">
            <strong>Cron Command:</strong>
            <small>*/5 * * * *</small>  
            <code>/usr/local/bin/php /home/example_username/public_html/cron.php</code>
        </div>

        <!-- User Statistics -->
        <div class="user-stats mt-4">
            <div class="row g-4">
                <!-- Total Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Total Users</h5>
                            <p class="card-text"><?php echo number_format($total_users); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Active Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Active Users</h5>
                            <p class="card-text"><?php echo number_format($active_users); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- 24h Active Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">24h Active Users</h5>
                            <p class="card-text"><?php echo number_format($daily_active_users); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Today's Active Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Today's Active Users</h5>
                            <p class="card-text"><?php echo number_format($today_active_users); ?></p>
                            <p class="card-subtext"><?php echo date('d M Y'); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Inactive for 24h -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Inactive (24h)</h5>
                            <p class="card-text"><?php echo number_format($inactive_24h); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Male Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Male Users</h5>
                            <p class="card-text"><?php echo number_format($male_count); ?></p>
                            <p class="card-subtext"><?php echo $male_percent; ?>% of total</p>
                        </div>
                    </div>
                </div>
                
                <!-- Female Users -->
                <div class="col-md-6 col-lg-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Female Users</h5>
                            <p class="card-text"><?php echo number_format($female_count); ?></p>
                            <p class="card-subtext"><?php echo $female_percent; ?>% of total</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hourly Activity Chart -->
        <div class="chart-container mt-4">
            <h4>Today's Hourly Activity</h4>
            <canvas id="hourlyChart"></canvas>
        </div>
    </div>

<!-- Latest Bootstrap JS Bundle from jsDelivr -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to toggle the slide menu
    function toggleMenu() {
        const slideMenu = document.getElementById("slideMenu");
        slideMenu.classList.toggle("open");
    }

    // Close slideMenu when clicking outside
    document.addEventListener("click", function(e) {
        const slideMenu = document.getElementById("slideMenu");
        const menuBtn = document.querySelector(".menu-btn");

        if (!e.target.closest("#slideMenu") && !e.target.closest(".menu-btn") && slideMenu.classList.contains("open")) {
            slideMenu.classList.remove("open");
        }
    });

        // Hourly Activity Chart
        const ctx = document.getElementById('hourlyChart').getContext('2d');
        const hourlyChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_map(function($h) { return $h . ':00'; }, $hours)); ?>,
                datasets: [{
                    label: 'Active Users',
                    data: <?php echo json_encode($hourly_counts); ?>,
                    backgroundColor: 'rgba(0, 149, 246, 0.7)',
                    borderColor: 'rgba(0, 149, 246, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>