<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Function to make URLs clickable
function makeLinksClickable($text) {
    $pattern = '/(https?:\/\/[^\s]+)/';
    $replacement = '<a href="$1" target="_blank" rel="noopener noreferrer" class="message-link">$1</a>';
    return preg_replace($pattern, $replacement, $text);
}

// Handle Broadcast Message Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['message'])) {
    $message = $conn->real_escape_string($_POST['message']);
    
    // Handle file upload
    $file_url = NULL;
    $file_type = NULL;

    if (!empty($_FILES['file']['name'])) {
        $file_name = basename($_FILES['file']['name']);
        $target_path = "../uploads/" . $file_name;
        
        if (move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
            $file_url = "uploads/" . $file_name;
            $file_type = $_FILES['file']['type'];
        }
    }

    $sql = "INSERT INTO broadcast (message, file_url, file_type) VALUES ('$message', '$file_url', '$file_type')";
    $conn->query($sql);
    $_SESSION['success'] = "Broadcast message sent!";
}

// Handle Delete Request
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);

    // Fetch the file URL to delete
    $sql = "SELECT file_url FROM broadcast WHERE id = $delete_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (!empty($row['file_url']) && file_exists("../" . $row['file_url'])) {
            unlink("../" . $row['file_url']);
        }
    }

    $sql = "DELETE FROM broadcast WHERE id = $delete_id";
    $conn->query($sql);
    $_SESSION['success'] = "Broadcast message deleted!";
    header("Location: broadcast.php");
    exit();
}

// Fetch Broadcast Messages
$sql = "SELECT * FROM broadcast ORDER BY created_at DESC";
$messages = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broadcast</title>
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.20/dist/sweetalert2.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --text-dark: #262626;
            --text-gray: #8e8e8e;
            --bg-color: #fafafa;
            --border-color: #dbdbdb;
        }
        
        body {
            background-color: var(--bg-color);
            color: var(--text-dark);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--text-dark);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        .container {
            max-width: 600px;
            margin: 80px auto 30px;
            padding: 0 16px;
        }
        
        .card {
            border: 1px solid var(--border-color);
            border-radius: 8px;
            background: white;
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            padding: 14px 16px;
            border-bottom: 1px solid var(--border-color);
            font-weight: 600;
        }
        
        .message-input {
            border: none;
            resize: none;
            padding: 16px;
            width: 100%;
            min-height: 120px;
            outline: none;
            font-size: 15px;
        }
        
        .file-upload {
            padding: 16px;
            border-top: 1px solid var(--border-color);
        }
        
        .file-upload-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-color);
            font-weight: 600;
            cursor: pointer;
        }
        
        .file-name {
            display: inline-block;
            max-width: 100%;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-top: 6px;
            font-size: 14px;
            color: var(--text-gray);
        }
        
        .submit-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            width: 100%;
            padding: 8px;
            border-radius: 4px;
            font-weight: 600;
            margin-top: 8px;
        }
        
        .message-card {
            padding: 16px;
            border-bottom: 1px solid var(--border-color);
        }
        
        .message-text {
            white-space: pre-wrap;
            margin-bottom: 12px;
            line-height: 1.5;
        }
        
        .attachment-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--primary-color);
            font-weight: 500;
            font-size: 14px;
            margin-bottom: 12px;
        }
        
        .message-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            color: var(--text-gray);
        }
        
        .delete-btn {
            color: #ed4956;
            background: none;
            border: none;
            font-weight: 500;
            cursor: pointer;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-gray);
        }
        
        .empty-state i {
            font-size: 2rem;
            margin-bottom: 12px;
            color: #ccc;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4 style="margin: 0; font-weight: 600;">Broadcast</h4>
    <div></div> <!-- Empty div for spacing -->
</div>
    
    <div class="container">
        <!-- Success Message -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show mb-3">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Broadcast Form -->
        <div class="card mb-4">
            <div class="card-header">
                Create Broadcast
            </div>
            <form method="post" enctype="multipart/form-data">
                <textarea class="message-input" name="message" placeholder="Write your message..." required></textarea>
                <div class="file-upload">
                    <label class="file-upload-btn">
                        <i class="fas fa-paperclip"></i>
                        <span>Add Attachment</span>
                        <input type="file" name="file" id="fileInput" style="display:none;" onchange="updateFileName()">
                    </label>
                    <div id="fileNameDisplay" class="file-name"></div>
                    <div class="form-text">Images, videos or documents (10MB max)</div>
                </div>
                <div class="p-3 pt-0">
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-paper-plane"></i> Send
                    </button>
                </div>
            </form>
        </div>

        <!-- Previous Broadcasts -->
        <h6 style="font-weight:600; margin-bottom:16px;">Previous Broadcasts</h6>
        
        <?php if ($messages->num_rows > 0): ?>
            <div class="card">
                <?php while ($row = $messages->fetch_assoc()): ?>
                    <div class="message-card">
                        <div class="message-text"><?php echo nl2br(makeLinksClickable(htmlspecialchars($row['message']))); ?></div>
                        
                        <?php if (!empty($row['file_url'])): ?>
                            <div class="attachment-badge">
                                <i class="fas fa-paperclip"></i>
                                <a href="../<?php echo $row['file_url']; ?>" target="_blank" style="color:inherit;">
                                    View Attachment
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="message-footer">
                            <span><?php echo date('M j, Y \a\t g:i A', strtotime($row['created_at'])); ?></span>
                            <button class="delete-btn" onclick="confirmDelete(<?php echo $row['id']; ?>)">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="card empty-state">
                <i class="fas fa-bullhorn"></i>
                <p>No broadcasts yet</p>
                <small>Your broadcast messages will appear here</small>
            </div>
        <?php endif; ?>
    </div>
<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.20/dist/sweetalert2.min.js"></script>
    <script>
        // Delete confirmation function
        function confirmDelete(id) {
            Swal.fire({
                title: 'Delete Broadcast?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ed4956',
                cancelButtonColor: '#8e8e8e',
                confirmButtonText: 'Delete',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'broadcast.php?delete_id=' + id;
                }
            });
        }
        
        // Update file name display with ellipsis for long names
        function updateFileName() {
            const fileInput = document.getElementById('fileInput');
            const fileNameDisplay = document.getElementById('fileNameDisplay');
            
            if (fileInput.files.length > 0) {
                fileNameDisplay.textContent = fileInput.files[0].name;
                fileNameDisplay.style.display = 'block';
            } else {
                fileNameDisplay.style.display = 'none';
            }
        }
        
        // Auto-focus textarea
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.message-input').focus();
        });
    </script>
</body>
</html>