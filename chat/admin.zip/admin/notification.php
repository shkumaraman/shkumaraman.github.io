<?php
session_start();
include('../db.php'); // Adjust path as needed

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Fetch all users for selection
$sql_users = "SELECT id, username, email FROM users";
$result_users = $conn->query($sql_users);
$users = $result_users->fetch_all(MYSQLI_ASSOC);

// Handle sending notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notification'])) {
    $message = trim($_POST['message']);
    $selected_users = $_POST['users']; // Array of user IDs

    if (!empty($message)) {
        if (in_array("all", $selected_users)) {
            // Send to all users
            $insert_sql = "INSERT INTO notifications (user_id, message, status) VALUES (NULL, ?, 'unread')";
            $stmt_insert = $conn->prepare($insert_sql);
            $stmt_insert->bind_param("s", $message);
            $stmt_insert->execute();
        } else {
            // Send to selected users
            $insert_sql = "INSERT INTO notifications (user_id, message, status) VALUES (?, ?, 'unread')";
            $stmt_insert = $conn->prepare($insert_sql);
            foreach ($selected_users as $user_id) {
                $stmt_insert->bind_param("is", $user_id, $message);
                $stmt_insert->execute();
            }
        }
    }

    header("Location: notification.php");
    exit();
}

// Fetch all notifications sent by admin
$sql_notifs = "SELECT id, user_id, message, created_at FROM notifications ORDER BY created_at DESC";
$result = $conn->query($sql_notifs);
$notifications = $result->fetch_all(MYSQLI_ASSOC);

// Handle notification deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_notification'])) {
    $notif_id = $_POST['notification_id'];
    $delete_sql = "DELETE FROM notifications WHERE id = ?";
    $stmt_delete = $conn->prepare($delete_sql);
    $stmt_delete->bind_param("i", $notif_id);
    $stmt_delete->execute();
    
    header("Location: notification.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <style>
    :root {
        --primary-color: #4361ee;
        --secondary-color: #3f37c9;
        --accent-color: #4895ef;
        --light-color: #f8f9fa;
        --dark-color: #212529;
        --success-color: #4cc9f0;
        --danger-color: #f72585;
        --warning-color: #f8961e;
        --info-color: #4895ef;
    }
    
    body {
        background-color: #f5f7fb;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    .header {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 9999;
        width: 100%;
        background: white;
        color: var(--dark-color);
        padding: 15px 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #e0e0e0;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    }
    
    .back-btn {
        background: transparent;
        border: none;
        color: var(--dark-color);
        font-size: 20px;
        cursor: pointer;
        transition: all 0.3s;
    }
    
    .back-btn:hover {
        color: var(--primary-color);
        transform: translateX(-2px);
    }
    
    .container {
        max-width: 800px;
        margin: 90px auto 30px;
        padding: 0 15px;
    }
    
    .card {
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        margin-bottom: 25px;
        overflow: hidden;
    }
    
    .card-header {
        background-color: var(--primary-color);
        color: white;
        font-weight: 600;
        padding: 15px 20px;
        border-bottom: none;
    }
    
    .form-control, .form-select {
        border-radius: 8px;
        padding: 12px 15px;
        border: 1px solid #e0e0e0;
        transition: all 0.3s;
    }
    
    .form-control:focus, .form-select:focus {
        border-color: var(--accent-color);
        box-shadow: 0 0 0 0.25rem rgba(67, 97, 238, 0.25);
    }
    
    textarea.form-control {
        min-height: 120px;
        resize: vertical;
    }
    
    .btn-primary {
        background-color: var(--primary-color);
        border: none;
        padding: 12px;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s;
    }
    
    .btn-primary:hover {
        background-color: var(--secondary-color);
        transform: translateY(-2px);
    }
    
    .notification {
        background: white;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 15px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        position: relative;
        word-wrap: break-word;
        overflow-wrap: break-word;
        white-space: normal;
        border-left: 4px solid var(--primary-color);
        transition: all 0.3s;
    }
    
    .notification:hover {
        transform: translateY(-3px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .notification p {
        margin-bottom: 10px;
        font-size: 16px;
        line-height: 1.5;
        color: var(--dark-color);
    }
    
    .notification small {
        color: #6c757d;
        font-size: 13px;
    }
    
    .delete-btn {
        color: var(--danger-color);
        border: none;
        background: none;
        cursor: pointer;
        position: absolute;
        top: 15px;
        right: 15px;
        font-size: 16px;
        transition: all 0.3s;
    }
    
    .delete-btn:hover {
        color: #d0006f;
        transform: scale(1.1);
    }
    
    .badge {
        padding: 5px 8px;
        font-size: 12px;
        font-weight: 500;
        border-radius: 20px;
    }
    
    .badge-all {
        background-color: var(--success-color);
    }
    
    .badge-user {
        background-color: var(--info-color);
    }
    
    hr {
        margin: 30px 0;
        border-top: 1px solid #e0e0e0;
    }
    
    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #6c757d;
    }
    
    .empty-state i {
        font-size: 50px;
        color: #dee2e6;
        margin-bottom: 15px;
    }
    
    .select2-container--default .select2-selection--multiple {
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        min-height: 45px;
        padding: 5px;
    }
    
    .select2-container--default .select2-selection--multiple .select2-selection__choice {
        background-color: var(--primary-color);
        border: none;
        border-radius: 4px;
        color: white;
        padding: 2px 8px;
    }
    
    .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
        color: white;
        margin-right: 5px;
    }
    
    /* SweetAlert custom styles */
    .swal2-popup {
        border-radius: 10px !important;
    }
    
    .swal2-title {
        font-size: 1.5rem !important;
    }
    
    .swal2-confirm {
        background-color: var(--primary-color) !important;
        border: none !important;
        padding: 10px 24px !important;
        border-radius: 8px !important;
    }
    
    .swal2-cancel {
        background-color: #6c757d !important;
        border: none !important;
        padding: 10px 24px !important;
        border-radius: 8px !important;
    }
    
    @media (max-width: 768px) {
        .container {
            margin-top: 80px;
        }
        
        .card-header {
            padding: 12px 15px;
            font-size: 16px;
        }
        
        .notification {
            padding: 15px;
        }
        
        .swal2-popup {
            width: 90% !important;
        }
    }
</style>
</head>
<body>

    <!-- Header -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4 class="mb-0">Notifications</h4>
        <div style="width: 24px;"></div> <!-- Spacer for balance -->
    </div>

    <div class="container">
        <!-- Send Notification Card -->
        <div class="card">
            <div class="card-header d-flex align-items-center">
                <i class="fas fa-bell me-2"></i>
                <span>Create New Notification</span>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="message" class="form-label">Notification Message</label>
                        <textarea name="message" class="form-control" id="message" rows="4" required 
                                  placeholder="Type your notification message here..."></textarea>
                    </div>

                    <!-- User Selection -->
                    <div class="mb-4">
                        <label for="user-select" class="form-label">Select Recipients</label>
                        <select name="users[]" id="user-select" class="form-select" multiple="multiple" required>
                            <option value="all">All Users</option>
                            <?php foreach ($users as $user): ?>
                                <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['username']) ?> (<?= htmlspecialchars($user['email']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Hold Ctrl/Cmd to select multiple users or select "All Users"</div>
                    </div>

                    <button type="submit" name="send_notification" class="btn btn-primary w-100">
                        <i class="fas fa-paper-plane me-2"></i> Send Notification
                    </button>
                </form>
            </div>
        </div>

        <!-- Sent Notifications Section -->
        <h5 class="mt-4 mb-3 d-flex align-items-center">
            <i class="fas fa-history me-2"></i>
            <span>Notification History</span>
        </h5>
        
        <?php if (empty($notifications)): ?>
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <h5>No notifications sent yet</h5>
                <p class="text-muted">When you send notifications, they will appear here</p>
            </div>
        <?php else: ?>
            <?php foreach ($notifications as $notif): ?>
                <div class="notification">
                    <form method="POST" style="display:inline;" class="delete-notification-form" id="delete-form-<?= $notif['id'] ?>">
                        <input type="hidden" name="notification_id" value="<?= $notif['id'] ?>">
                        <input type="hidden" name="delete_notification" value="1">
                        <button type="button" class="delete-btn" title="Delete notification" onclick="confirmDelete(<?= $notif['id'] ?>)">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                    
                    <p><?= htmlspecialchars($notif['message'], ENT_QUOTES, 'UTF-8') ?></p>
                    
                    <div class="d-flex justify-content-between align-items-center mt-2">
                        <small class="text-muted">
                            <i class="far fa-clock me-1"></i>
                            <?= date('M j, Y g:i A', strtotime($notif['created_at'])) ?>
                        </small>
                        
                        <?php if ($notif['user_id'] === null): ?>
                            <span class="badge badge-all">All Users</span>
                        <?php else: ?>
                            <span class="badge badge-user">User ID: <?= $notif['user_id'] ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- jQuery and Select2 JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <!-- SweetAlert JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2 for user selection
            $('#user-select').select2({
                placeholder: "Select recipients",
                allowClear: true,
                width: '100%'
            });
            
            // Prevent selecting "All Users" with other options
            $('#user-select').on('change', function() {
                if ($(this).val() && $(this).val().includes('all') && $(this).val().length > 1) {
                    $(this).val(['all']);
                    $(this).trigger('change');
                }
            });
        });
        
        function confirmDelete(notificationId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#4361ee',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Submit the specific form when confirmed
                    document.getElementById('delete-form-' + notificationId).submit();
                }
            });
        }
    </script>
</body>
</html>