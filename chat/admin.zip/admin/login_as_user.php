<?php
session_start();
include('../db.php');

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Ensure the request method is POST and `user_id` is provided
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);

    // Fetch user details
    $sql = "SELECT id FROM users WHERE id = $user_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Switch session to selected user
        $_SESSION['user_id'] = $user_id;

        // Redirect to the user's dashboard or home page
        header('Location: ../dashboard.php'); // Change to appropriate page
        exit();
    }
}

// Redirect back if something went wrong
header('Location: users.php');
exit();
?>
