<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Database connection
include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Handle premium status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
    $premium = isset($_POST['premium']) ? 1 : 0; // Set premium to 1 if checked, otherwise 0

    // Set verified based on premium status
    $verified = $premium ? 1 : 0;

    // Update premium and verified status in the database
    $sql = "UPDATE users SET premium = $premium, verified = $verified WHERE id = $user_id";
    $conn->query($sql);
}

// Handle search query and filters
$search = '';
$filters = [
    'premium' => null,
    'verified' => null,
    'admin' => null,
    'last_activity' => null,
    'gender' => null
];

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

// Process filters
if (isset($_GET['premium']) && in_array($_GET['premium'], ['0', '1'])) {
    $filters['premium'] = (int)$_GET['premium'];
}

if (isset($_GET['verified']) && in_array($_GET['verified'], ['0', '1'])) {
    $filters['verified'] = (int)$_GET['verified'];
}

if (isset($_GET['admin']) && in_array($_GET['admin'], ['0', '1'])) {
    $filters['admin'] = (int)$_GET['admin'];
}

if (isset($_GET['last_activity']) && in_array($_GET['last_activity'], ['0-7', '7-30', '30+'])) {
    $filters['last_activity'] = $_GET['last_activity'];
}

if (isset($_GET['gender']) && in_array($_GET['gender'], ['Male', 'Female'])) {
    $filters['gender'] = $_GET['gender'];
}

// Build the SQL query
$sql = "SELECT id, username, email, admin, premium, verified, profile_pic, last_activity, gender FROM users";
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(username LIKE '%$search%' OR email LIKE '%$search%')";
}

foreach ($filters as $key => $value) {
    if ($value !== null) {
        if ($key === 'last_activity') {
            switch ($value) {
                case '0-7':
                    $where[] = "last_activity >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
                    break;
                case '7-30':
                    $where[] = "last_activity BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND DATE_SUB(NOW(), INTERVAL 7 DAY)";
                    break;
                case '30+':
                    $where[] = "last_activity < DATE_SUB(NOW(), INTERVAL 30 DAY)";
                    break;
            }
        } else {
            $where[] = "$key = '$value'";
        }
    }
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #4e73df;
            --dark-color: #2e384d;
            --light-color: #f5f7fb;
            --border-color: #e0e0e0;
            --text-color: #5a5c69;
            --shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;          
           }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .header h4 {
            margin: 0;
            font-weight: 600;
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        /* Main Content */
        .container-fluid {
            margin-top: 80px;
            max-width: 1600px;
        }
        
.last-activity {
    font-size: 0.85rem;
    color: var(--text-color);
    white-space: nowrap;
}

        .content-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: var(--shadow);
            padding: 10px;
            margin-bottom: 30px;
        }

        /* Search bar styling */
        .search-bar {
            margin-bottom: 25px;
        }
        
        .search-bar .input-group {
            box-shadow: 0 0.15rem 0.5rem rgba(0, 0, 0, 0.1);
            border-radius: 5px;
        }
        
        .search-bar .form-control {
            border-right: none;
            padding: 12px 15px;
        }
        
        .search-bar .form-control:focus {
            box-shadow: none;
            border-color: #ced4da;
        }
        
        .search-bar .btn {
            padding: 12px 20px;
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .search-bar .btn:hover {
            background-color: #3a5bd9;
            border-color: #3a5bd9;
        }

        /* Filters styling */
        .filter-section {
            background-color: #f8f9fc;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 0.15rem 0.5rem rgba(0, 0, 0, 0.05);
        }
        
        .filter-title {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 10px;
            display: block;
        }
        
        .filter-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .filter-btn {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            border: 1px solid #d1d3e2;
            background-color: white;
            color: var(--text-color);
            transition: all 0.2s;
        }
        
        .filter-btn:hover {
            background-color: #f0f2f5;
        }
        
        .filter-btn.active {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            color: white;
        }
        
        .filter-btn i {
            margin-right: 5px;
        }

        /* Table styling */
        .table {
            margin-top: 20px;
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }
        
        .table thead th {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            border: none;
            padding: 12px 15px;
        }
        
        .table tbody tr {
            transition: all 0.2s;
            background-color: white;
        }
        
        .table tbody tr:hover {
            background-color: rgba(78, 115, 223, 0.05);
            transform: translateY(-1px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .table td {
            padding: 12px 15px;
            vertical-align: middle;
            border-top: 1px solid #e3e6f0;
        }
        
        .table tbody tr:last-child td {
            border-bottom: 1px solid #e3e6f0;
        }

        /* Profile picture styling */
        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e3e6f0;
        }

        /* Status badges */
        .badge {
            padding: 6px 10px;
            font-weight: 600;
            font-size: 0.75rem;
            border-radius: 4px;
        }
        
        .badge-admin {
            background-color: #f6c23e;
            color: #1f2d3d;
        }
        
        .badge-premium {
            background-color: #1cc88a;
            color: white;
        }
        
        .badge-verified {
            background-color: #36b9cc;
            color: white;
        }
        
        .badge-not-verified {
            background-color: #e74a3b;
            color: white;
        }

        /* Switch styling */
        .form-switch .form-check-input {
            width: 3em;
            height: 1.5em;
            cursor: pointer;
            background-color: #d1d3e2;
            border-color: #d1d3e2;
        }
        
        .form-switch .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        /* Button styling */
        .btn-sm {
            padding: 5px 10px;
            font-size: 0.8rem;
            border-radius: 4px;
            margin-right: 5px;
        }
        
        .btn-edit {
            background-color: #f6c23e;
            border-color: #f6c23e;
            color: #1f2d3d;
        }
        
        .btn-edit:hover {
            background-color: #dda20a;
            border-color: #dda20a;
            color: #1f2d3d;
        }
        
        .btn-login {
            background-color: #36b9cc;
            border-color: #36b9cc;
            color: white;
        }
        
        .btn-login:hover {
            background-color: #2a96a5;
            border-color: #2a96a5;
            color: white;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 0;
            color: #6c757d;
        }
        
        .empty-state i {
            font-size: 50px;
            margin-bottom: 15px;
            color: #d1d3e2;
        }
        
        /* Full width on desktop */
        @media (min-width: 992px) {
            .container-fluid {
                padding: 0 50px;
            }
            
            .content-card {
                padding: 30px;
            }
        }
        .gender-male {
            color: #4e73df;
        }
        
        .gender-female {
            color: #e74a3b;
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Manage Users</h4>
        <div></div> <!-- Empty div for spacing -->
    </div>

    <!-- Main Content -->
    <div class="container-fluid">
        <div class="content-card">
            <!-- Search Bar -->
            <div class="search-bar">
                <form method="GET" action="users.php">
                    <div class="input-group">
                        <input type="text" class="form-control" name="search" placeholder="Search by username or email" value="<?= htmlspecialchars($search) ?>">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search"></i> Search
                        </button>
                    </div>
                </form>
            </div>

            <!-- Filters Section -->
            <div class="filter-section">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <span class="filter-title"><i class="fas fa-crown"></i> Premium Status</span>
                        <div class="filter-group">
                            <a href="?<?= http_build_query(array_merge($_GET, ['premium' => null])) ?>" 
                               class="filter-btn <?= $filters['premium'] === null ? 'active' : '' ?>">
                                All
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['premium' => 1])) ?>" 
                               class="filter-btn <?= $filters['premium'] === 1 ? 'active' : '' ?>">
                                <i class="fas fa-crown"></i> Premium
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['premium' => 0])) ?>" 
                               class="filter-btn <?= $filters['premium'] === 0 ? 'active' : '' ?>">
                                Regular
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <span class="filter-title"><i class="fas fa-check-circle"></i> Verified Status</span>
                        <div class="filter-group">
                            <a href="?<?= http_build_query(array_merge($_GET, ['verified' => null])) ?>" 
                               class="filter-btn <?= $filters['verified'] === null ? 'active' : '' ?>">
                                All
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['verified' => 1])) ?>" 
                               class="filter-btn <?= $filters['verified'] === 1 ? 'active' : '' ?>">
                                <i class="fas fa-check-circle"></i> Verified
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['verified' => 0])) ?>" 
                               class="filter-btn <?= $filters['verified'] === 0 ? 'active' : '' ?>">
                                Not Verified
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <span class="filter-title"><i class="fas fa-user-shield"></i> Admin Status</span>
                        <div class="filter-group">
                            <a href="?<?= http_build_query(array_merge($_GET, ['admin' => null])) ?>" 
                               class="filter-btn <?= $filters['admin'] === null ? 'active' : '' ?>">
                                All
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['admin' => 1])) ?>" 
                               class="filter-btn <?= $filters['admin'] === 1 ? 'active' : '' ?>">
                                <i class="fas fa-user-shield"></i> Admins
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['admin' => 0])) ?>" 
                               class="filter-btn <?= $filters['admin'] === 0 ? 'active' : '' ?>">
                                Users
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <span class="filter-title"><i class="fas fa-venus-mars"></i> Gender</span>
                        <div class="filter-group">
                            <a href="?<?= http_build_query(array_merge($_GET, ['gender' => null])) ?>" 
                               class="filter-btn <?= $filters['gender'] === null ? 'active' : '' ?>">
                                All
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['gender' => 'Male'])) ?>" 
                               class="filter-btn <?= $filters['gender'] === 'Male' ? 'active' : '' ?>">
                                <i class="fas fa-mars"></i> Male
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['gender' => 'Female'])) ?>" 
                               class="filter-btn <?= $filters['gender'] === 'Female' ? 'active' : '' ?>">
                                <i class="fas fa-venus"></i> Female
                            </a>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3">
                        <span class="filter-title"><i class="fas fa-clock"></i> Last Activity</span>
                        <div class="filter-group">
                            <a href="?<?= http_build_query(array_merge($_GET, ['last_activity' => null])) ?>" 
                               class="filter-btn <?= $filters['last_activity'] === null ? 'active' : '' ?>">
                                All
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['last_activity' => '0-7'])) ?>" 
                               class="filter-btn <?= $filters['last_activity'] === '0-7' ? 'active' : '' ?>">
                                0-7 Days
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['last_activity' => '7-30'])) ?>" 
                               class="filter-btn <?= $filters['last_activity'] === '7-30' ? 'active' : '' ?>">
                                7-30 Days
                            </a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['last_activity' => '30+'])) ?>" 
                               class="filter-btn <?= $filters['last_activity'] === '30+' ? 'active' : '' ?>">
                                30+ Days
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <?php if (count($users) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th></th>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Gender</th>
                                <th>Last Activity</th>
                                <th>Admin</th>
                                <th>Premium</th>
                                <th>Verified</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td>
                                        <?php if (!empty($user['profile_pic'])): ?>
                                            <img src="../<?= htmlspecialchars($user['profile_pic']) ?>" alt="Profile Pic" class="profile-pic">
                                        <?php else: ?>
                                            <div class="profile-pic bg-light d-flex align-items-center justify-content-center">
                                                <i class="fas fa-user text-muted"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $user['id'] ?></td>
                                    <td><?= htmlspecialchars($user['username']) ?></td>
                                    <td><?= htmlspecialchars($user['email']) ?></td>
                                    <td>
                                        <?php if ($user['gender'] == 'Male'): ?>
                                            <i class="fas fa-mars gender-male"></i> Male
                                        <?php elseif ($user['gender'] == 'Female'): ?>
                                            <i class="fas fa-venus gender-female"></i> Female
                                        <?php else: ?>
                                            <span class="text-muted">Not specified</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($user['last_activity']) && $user['last_activity'] != '0000-00-00 00:00:00'): ?>
                                            <?= date('M j, Y g:i A', strtotime($user['last_activity'])) ?>
                                        <?php else: ?>
                                            Never
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-admin">
                                            <?= $user['admin'] ? 'ADMIN' : 'USER' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input" type="checkbox" name="premium" id="premium<?= $user['id'] ?>" 
                                                       <?= $user['premium'] ? 'checked' : '' ?> onchange="this.form.submit()">
                                            </div>
                                        </form>
                                    </td>
                                    <td>
                                        <?php if ($user['verified'] == 1): ?>
                                            <span class="badge badge-verified">VERIFIED</span>
                                        <?php else: ?>
                                            <span class="badge badge-not-verified">NOT VERIFIED</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="edit_user.php?id=<?= $user['id'] ?>" class="btn btn-warning btn-sm btn-edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="#" class="btn btn-danger btn-sm delete-btn" data-id="<?= $user['id'] ?>">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <form method="POST" action="login_as_user.php" style="display: inline;">
                                            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
                                            <button type="submit" class="btn btn-info btn-sm btn-login">
                                                <i class="fas fa-sign-in-alt"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-users-slash"></i>
                    <h4>No users found</h4>
                    <p>Try adjusting your search or filters</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Bootstrap Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Add event listeners to all delete buttons
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function(event) {
                event.preventDefault();
                const userId = this.getAttribute('data-id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!',
                    backdrop: 'rgba(0,0,0,0.4)'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `delete_user.php?id=${userId}`;
                    }
                });
            });
        });
    </script>
</body>
</html>