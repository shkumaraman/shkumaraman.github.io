<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php');
    exit();
}

// Base upload directory
$upload_dir = realpath('../uploads');
$current_dir = isset($_GET['dir']) ? realpath($upload_dir . '/' . $_GET['dir']) : $upload_dir;

// Prevent directory traversal
if (strpos($current_dir, $upload_dir) !== 0) {
    $current_dir = $upload_dir;
}

// Get relative path
$relative_path = ltrim(str_replace($upload_dir, '', $current_dir), DIRECTORY_SEPARATOR);

// Delete File
if (isset($_GET['delete'])) {
    $file_name = basename($_GET['delete']);
    $file_path = $current_dir . DIRECTORY_SEPARATOR . $file_name;

    if (file_exists($file_path) && is_file($file_path)) {
        unlink($file_path);
        header("Location: manage.php?dir=" . urlencode($relative_path) . "&msg=File deleted successfully");
        exit();
    } else {
        echo "<script>alert('Error: File not found!');</script>";
    }
}

// Export Users CSV
if (isset($_GET['export_users'])) {
    $query = "SELECT username, email, gender FROM users";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="users_export_' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Username', 'Email', 'Gender']);

        while ($row = mysqli_fetch_assoc($result)) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit();
    } else {
        echo "<script>alert('No user data found to export.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Files</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f8f9fa;
            --text-color: #121212;
            --card-bg: #ffffff;
            --border-color: #e0e0e0;
            --primary-color: #4361ee;
            --hover-color: #f5f5f5;
            --header-height: 60px;
            --sidebar-width: 280px;
        }
        
        body {
            background-color: var(--bg-color);
            color: var(--text-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            height: var(--header-height);
            background-color: var(--card-bg);
            color: var(--text-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 16px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border-bottom: 1px solid var(--border-color);
        }

        .header-title {
            font-size: 18px;
            font-weight: 600;
            margin: 0;
            flex-grow: 1;
            text-align: center;
            padding: 0 16px;
        }

        .header-actions {
            display: flex;
            gap: 12px;
        }

        .icon-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
            color: var(--text-color);
            cursor: pointer;
            transition: all 0.2s;
        }

        .icon-btn:hover {
            background-color: var(--hover-color);
        }

        .icon-btn i {
            font-size: 20px;
        }
        
        .main-container {
            margin-top: var(--header-height);
            padding: 16px;
            max-width: 100%;
            box-sizing: border-box;
        }

        .file-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--card-bg);
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .file-header {
            padding: 16px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .file-title {
            font-size: 18px;
            font-weight: 600;
            margin: 0;
            color: var(--primary-color);
        }

        .breadcrumb {
            background-color: transparent;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 8px;
        }
        
        .breadcrumb-item {
            display: flex;
            align-items: center;
            font-size: 14px;
        }
        
        .breadcrumb-item a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.2s;
            display: flex;
            align-items: center;
        }
        
        .breadcrumb-item a:hover {
            text-decoration: underline;
        }
        
        .breadcrumb-divider {
            color: #999;
            margin: 0 4px;
        }

        .file-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .file-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-color);
            transition: all 0.2s;
            cursor: pointer;
            position: relative;
        }
        
        .file-item:last-child {
            border-bottom: none;
        }
        
        .file-item:hover {
            background-color: var(--hover-color);
        }
        
        .file-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background-color: #f0f4ff;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 12px;
            flex-shrink: 0;
            color: var(--primary-color);
        }
        
        .file-icon.folder {
            background-color: #fff8e6;
            color: #ffb800;
        }
        
        .file-info {
            flex-grow: 1;
            min-width: 0;
        }
        
        .file-name {
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 2px;
        }
        
        .file-meta {
            font-size: 12px;
            color: #666;
            display: flex;
            gap: 8px;
        }
        
        .file-actions {
            display: flex;
            gap: 8px;
            margin-left: 12px;
        }
        
        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: transparent;
            border: none;
            color: #666;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .action-btn:hover {
            background-color: #f0f0f0;
            color: var(--primary-color);
        }
        
        .action-btn.danger:hover {
            color: #ff3b30;
        }
        
        .image-preview {
            width: 40px;
            height: 40px;
            border-radius: 6px;
            object-fit: cover;
            margin-left: auto;
            border: 1px solid var(--border-color);
            flex-shrink: 0;
        }
        
        .empty-state {
            padding: 40px 16px;
            text-align: center;
            color: #666;
        }
        
        .empty-icon {
            font-size: 48px;
            color: #ccc;
            margin-bottom: 16px;
        }
        
        .empty-text {
            font-size: 16px;
            margin-bottom: 16px;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            color: white;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s;
        }
        
        .btn-primary:hover {
            background-color: #3a56d4;
            color: white;
        }
        
        @media (max-width: 768px) {
            .main-container {
                padding: 0;
            }
            
            .file-container {
                border-radius: 0;
                box-shadow: none;
            }
            
            .file-item {
                padding: 12px;
            }
        }

        /* Floating action button */
        .fab {
            position: fixed;
            bottom: 24px;
            right: 24px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            cursor: pointer;
            transition: all 0.2s;
            z-index: 100;
            border: none;
        }
        
        .fab:hover {
            background-color: #3a56d4;
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.2);
        }
        
        .fab i {
            font-size: 24px;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <button class="icon-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h1 class="header-title">Manage Files</h1>
        <div class="header-actions">
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-container">
        <div class="file-container">
            <div class="file-header">
                <div>
                    <a href="manage.php?export_users=1" class="btn btn-primary">
                        <i class="fas fa-download"></i> Export Users
                    </a>
                </div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="manage.php"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-divider">/</li>
                        <?php
                        $parts = explode(DIRECTORY_SEPARATOR, $relative_path);
                        $accum = '';
                        foreach ($parts as $index => $part) {
                            if ($part !== '') {
                                $accum .= $part . DIRECTORY_SEPARATOR;
                                if ($index === count($parts) - 1) {
                                    echo "<li class='breadcrumb-item'>" . htmlspecialchars($part) . "</li>";
                                } else {
                                    echo "<li class='breadcrumb-item'><a href='manage.php?dir=" . urlencode(rtrim($accum, DIRECTORY_SEPARATOR)) . "'>" . htmlspecialchars($part) . "</a></li>";
                                    echo "<li class='breadcrumb-divider'>/</li>";
                                }
                            }
                        }
                        ?>
                    </ol>
                </nav>
            </div>

            <ul class="file-list">
                <?php
                $items = scandir($current_dir);
                $folders = $files = [];
                foreach ($items as $item) {
                    if ($item === '.' || $item === '..') continue;
                    $full_path = $current_dir . DIRECTORY_SEPARATOR . $item;
                    if (is_dir($full_path)) $folders[] = $item;
                    else $files[] = $item;
                }

                foreach ($folders as $folder) {
                    echo '<li class="file-item" onclick="window.location=\'manage.php?dir=' . urlencode($relative_path . DIRECTORY_SEPARATOR . $folder) . '\'">
                            <div class="file-icon folder">
                                <i class="fas fa-folder"></i>
                            </div>
                            <div class="file-info">
                                <div class="file-name">' . htmlspecialchars($folder) . '</div>
                                <div class="file-meta">Folder</div>
                            </div>
                            <div class="file-actions">
                                <button class="action-btn" onclick="event.stopPropagation(); window.location=\'manage.php?dir=' . urlencode($relative_path . DIRECTORY_SEPARATOR . $folder) . '\'">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                          </li>';
                }

                foreach ($files as $file) {
                    $file_url = 'uploads/' . ($relative_path ? $relative_path . '/' : '') . $file;
                    $file_url = str_replace('\\', '/', $file_url);
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    $is_image = in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']);

                    echo '<li class="file-item">
                            <div class="file-icon">
                                <i class="fas fa-file"></i>
                            </div>
                            <div class="file-info">
                                <div class="file-name">' . htmlspecialchars($file) . '</div>
                                <div class="file-meta">' . strtoupper($ext) . ' file</div>
                            </div>';
                    
                    if ($is_image) {
                        echo '<img src="../' . htmlspecialchars($file_url) . '" class="image-preview">';
                    }
                    
                    echo '    <div class="file-actions">
                                <a href="../' . htmlspecialchars($file_url) . '" download class="action-btn" onclick="event.stopPropagation()">
                                    <i class="fas fa-download"></i>
                                </a>
                                <form method="GET" class="d-inline delete-form" onclick="event.stopPropagation()">
                                    <input type="hidden" name="dir" value="' . htmlspecialchars($relative_path) . '">
                                    <input type="hidden" name="delete" value="' . htmlspecialchars($file) . '">
                                    <button type="submit" class="action-btn danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                          </li>';
                }

                if (empty($folders) && empty($files)) {
                    echo '<div class="empty-state">
                            <div class="empty-icon">
                                <i class="far fa-folder-open"></i>
                            </div>
                            <div class="empty-text">This folder is empty</div>
                          </div>';
                }
                ?>
            </ul>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.querySelectorAll('.delete-form').forEach(form => {
            form.addEventListener('submit', function(e) {
                e.preventDefault();
                const filename = this.querySelector('input[name="delete"]').value;
                Swal.fire({
                    title: 'Delete file?',
                    text: "Are you sure you want to delete " + filename + "?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#4361ee',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel',
                    backdrop: 'rgba(0,0,0,0.2)'
                }).then((result) => {
                    if (result.isConfirmed) this.submit();
                });
            });
        });

        const params = new URLSearchParams(window.location.search);
        if (params.has('msg')) {
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: params.get('msg'),
                confirmButtonColor: '#4361ee',
                backdrop: 'rgba(0,0,0,0.2)'
            });
        }
    </script>
</body>
</html>