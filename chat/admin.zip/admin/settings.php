<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Database connection
include('../db.php');

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}


// Handle settings update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $maintenance = isset($_POST['maintenance']) ? 1 : 0;
    $email_api = $_POST['email_api'];
    $email = $_POST['email'];
    $upi = $_POST['upi'];
    $instagram = $_POST['instagram'];
    $telegram = $_POST['telegram'];

    // Update settings in the database
    $sql = "UPDATE settings SET 
            maintenance = $maintenance, 
            email_api = '$email_api', 
            email = '$email', 
            upi = '$upi',
            instagram = '$instagram',
            telegram = '$telegram'";
    $conn->query($sql);

    // Show success message
    echo "<script>
        Swal.fire({
            icon: 'success',
            title: 'Settings Updated',
            text: 'Your settings have been updated successfully!',
        });
    </script>";
}

// Fetch current settings
$sql = "SELECT maintenance, email_api, email, upi, instagram, telegram FROM settings";
$result = $conn->query($sql);
$settings = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        :root {
            --bg-color: #ffffff;
            --primary-color: #4e73df;
            --secondary-color: #f8f9fc;
            --accent-color: #2e59d9;
            --text-color: #5a5c69;
            --text-dark: #262626;
            --border-color: #e3e6f0;
            --success-color: #1cc88a;
            --light-bg: #f8f9fc;
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;          
           }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: #2e384d;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .header h4 {
            margin: 0;
            font-weight: 600;
            font-size: 1.25rem;
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        /* Main Content */
        .container {
            margin-top: 90px;
            max-width: 800px;
            padding: 30px;
            margin-bottom: 30px;
        }

        /* Form styling */
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--text-color);
        }
        
        .form-control {
            padding: 12px 15px;
            border-radius: 6px;
            border: 1px solid var(--border-color);
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .form-check-input {
            width: 3em;
            height: 1.5em;
            cursor: pointer;
            background-color: #d1d3e2;
            border-color: #d1d3e2;
        }
        
        .form-check-input:checked {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .form-check-label {
            margin-left: 10px;
            font-weight: 500;
        }
        
        /* API link styling */
        .api-link {
            display: inline-block;
            margin-bottom: 10px;
            color: var(--primary-color);
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .api-link:hover {
            color: var(--accent-color);
            transform: translateX(3px);
        }
        
        .api-link i {
            margin-right: 5px;
        }

        /* Submit button */
        .btn-submit {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
            padding: 12px 20px;
            font-weight: 600;
            letter-spacing: 0.5px;
            border-radius: 6px;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }
        
        .btn-submit:hover {
            background-color: var(--accent-color);
            border-color: var(--accent-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(78, 115, 223, 0.2);
        }
        
        /* Status indicator */
        .status-indicator {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 10px;
        }
        
        .status-on {
            background-color: rgba(28, 200, 138, 0.2);
            color: var(--success-color);
        }
        
        .status-off {
            background-color: rgba(231, 74, 59, 0.2);
            color: #e74a3b;
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .container {
                padding: 20px;
                margin-top: 80px;
            }
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Manage Settings</h4>
        <div></div> <!-- Empty div for spacing -->
    </div>

    <!-- Main Content -->
    <div class="container">
        <form method="POST" action="settings.php">
            <!-- Maintenance Mode Toggle -->
            <div class="form-group">
                <label for="maintenance">Maintenance Mode</label>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="maintenance" id="maintenance" 
                           <?= $settings['maintenance'] ? 'checked' : '' ?>>
                    <label class="form-check-label" for="maintenance">
                        <?= $settings['maintenance'] ? 'Enabled' : 'Disabled' ?>
                        <span class="status-indicator <?= $settings['maintenance'] ? 'status-on' : 'status-off' ?>">
                            <?= $settings['maintenance'] ? 'ACTIVE' : 'INACTIVE' ?>
                        </span>
                    </label>
                </div>
            </div>

            <!-- Email API Key -->
            <div class="form-group">
                <a href="https://www.brevo.com" target="_blank" class="api-link">
                    <i class="fas fa-external-link-alt"></i> Get Brevo API Key
                </a>
                <label for="email_api">Brevo Email API Key</label>
                <input type="text" class="form-control" name="email_api" id="email_api" 
                       value="<?= htmlspecialchars($settings['email_api']) ?>" placeholder="Enter your Brevo API key">
            </div>

            <!-- Email Address -->
            <div class="form-group">
                <label for="email">Contact Email Address</label>
                <input type="email" class="form-control" name="email" id="email" 
                       value="<?= htmlspecialchars($settings['email']) ?>" placeholder="Enter contact email">
            </div>

            <!-- UPI ID -->
            <div class="form-group">
                <label for="upi">Payment UPI ID</label>
                <input type="text" class="form-control" name="upi" id="upi" 
                       value="<?= htmlspecialchars($settings['upi']) ?>" placeholder="Enter UPI ID for payments">
            </div>

            <!-- Social Links -->
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="instagram"><i class="fab fa-instagram text-danger"></i> Instagram Link</label>
                        <input type="text" class="form-control" name="instagram" id="instagram" 
                               value="<?= htmlspecialchars($settings['instagram']) ?>" placeholder="Enter Instagram URL">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="telegram"><i class="fab fa-telegram text-primary"></i> Telegram Link</label>
                        <input type="text" class="form-control" name="telegram" id="telegram" 
                               value="<?= htmlspecialchars($settings['telegram']) ?>" placeholder="Enter Telegram URL">
                    </div>
                </div>
            </div>

            <!-- Submit Button -->
            <button type="submit" class="btn btn-primary btn-submit">
                <i class="fas fa-save"></i> Save Settings
            </button>
        </form>
    </div>

    <script>
        // Update maintenance mode label when toggled
        document.getElementById('maintenance').addEventListener('change', function() {
            const label = document.querySelector('label[for="maintenance"]');
            const status = document.querySelector('.status-indicator');
            
            if (this.checked) {
                label.innerHTML = 'Enabled <span class="status-indicator status-on">ACTIVE</span>';
            } else {
                label.innerHTML = 'Disabled <span class="status-indicator status-off">INACTIVE</span>';
            }
        });
    </script>
</body>
</html>