<?php
require '../db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php');
    exit();
}

// Function to get current daily limit
function getDailyLimit($conn) {
    $result = $conn->query("SELECT vroom_limit FROM settings LIMIT 1");
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc()['vroom_limit'];
    }
    return 3; // Default value
}

// Removed is_active check from the query
$rooms = $conn->query("SELECT * FROM voice ORDER BY id DESC");

function getUser($conn, $id) {
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    return $res['username'] ?? 'Unknown';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if (isset($_POST['ajax'])) {
        if (isset($_POST['kick'])) {
            $room_id = (int)$_POST['room_id'];
            $user_id = (int)$_POST['user_id'];
            $slots = ['user1_id', 'user2_id', 'user3_id'];
            foreach ($slots as $slot) {
                $conn->query("UPDATE voice SET $slot = NULL WHERE id = $room_id AND $slot = $user_id");
            }
            echo json_encode(['success' => true, 'message' => 'User removed from the room']);
            exit;
        }

        if (isset($_POST['end_room'])) {
            $room_id = (int)$_POST['room_id'];

            // Set room_id to NULL in voice_joins before deleting the room (safe handling)
            $conn->query("UPDATE voice_joins SET room_id = NULL WHERE room_id = $room_id");

            // Now delete the room safely
            $conn->query("DELETE FROM voice WHERE id = $room_id");

            echo json_encode(['success' => true, 'message' => 'Room ended successfully']);
            exit;
        }
    }
    
    if (isset($_POST['update_limit'])) {
        $new_limit = (int)$_POST['daily_limit'];
        if ($new_limit < 1) {
            echo json_encode(['success' => false, 'message' => 'Limit must be a positive number']);
            exit;
        }
        
        $stmt = $conn->prepare("UPDATE settings SET vroom_limit = ?");
        $stmt->bind_param("i", $new_limit);
        $success = $stmt->execute();
        $stmt->close();
        
        echo json_encode([
            'success' => $success,
            'message' => $success ? 'Limit updated successfully' : 'Failed to update limit'
        ]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Voice Connections</title>
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --success-color: #4bb543;
            --danger-color: #e63946;
            --warning-color: #ff9f1c;
            --light-color: #f8f9fa;
            --dark-color: #212529;
            --gray-color: #6c757d;
            --card-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --border-radius: 12px;
        }
        
        body {
            background-color: #f5f7fa;
            font-family: 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            color: #333;
            padding-top: 70px;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--dark-color);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .page-title {
            margin: 0;
            font-weight: 600;
            font-size: 1.25rem;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        
        .room-card {
            background: white;
            border-radius: var(--border-radius);
            box-shadow: var(--card-shadow);
            margin-bottom: 20px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .room-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
        }
        
        .room-header {
            background: var(--primary-color);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .room-id {
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .room-host {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .room-host .badge {
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 0.75rem;
        }
        
        .room-body {
            padding: 20px;
        }
        
        .user-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .user-card {
            background: #f9fafc;
            border-radius: 8px;
            padding: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid #eaeef2;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .user-name {
            font-weight: 500;
        }
        
        .empty-slot {
            color: var(--gray-color);
            font-style: italic;
        }
        
        .action-btn {
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 5px;
        }
        
        .kick-btn {
            background: var(--danger-color);
            color: white;
        }
        
        .kick-btn:hover {
            background: #d62c3a;
        }
        
        .end-room-btn {
            background: var(--warning-color);
            color: white;
            margin-top: 15px;
            padding: 8px 16px;
        }
        
        .end-room-btn:hover {
            background: #e68f1a;
        }
        
  .save-btn {
    background: var(--success-color); /* Use your custom success color */
    color: white;
    padding: 15px 32px; /* Add padding to the button */
    border: none;
    border-radius: 5px; /* Rounded corners */
    font-size: 16px;
    display: flex; /* Flexbox to align content */
    align-items: center; /* Vertically center the content */
    justify-content: center; /* Horizontally center the content */
    width: 100%; /* Full width */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s ease; /* Smooth transition for hover */
}

.save-btn i {
    margin-right: 8px; /* Space between the icon and the text */
}

.save-btn:hover {
    background: #3fa037; /* Darker shade for hover */
}

        
        .actions-container {
            display: flex;
            justify-content: flex-end;
            border-top: 1px solid #eee;
            padding-top: 15px;
            margin-top: 15px;
        }
        
        .form-group {
            margin-bottom: 1rem;
        }
        
        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }
        
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .user-list {
                grid-template-columns: 1fr;
            }
            
            .room-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4 class="page-title">Voice Connections</h4>
    <div></div> <!-- Empty div for spacing -->
</div>

<div class="container">
<!-- Daily Limit Settings Card -->
<div class="room-card">
    <div class="room-header">
        <div class="room-id">Daily Join Limit Settings</div>
    </div>
    <div class="room-body">
        <form id="limitForm">
            <div class="form-group">
                <label for="daily_limit">Maximum daily joins for free users</label>
                <input type="number" class="form-control" id="daily_limit" name="daily_limit"
                       value="<?= getDailyLimit($conn) ?>" required>
            </div>
            <button type="submit" class="action-btn save-btn w-100">
                <i class="fas fa-save"></i> Update Limit
            </button>
        </form>
    </div>
</div>

    <!-- Voice Rooms List -->
    <?php while ($room = $rooms->fetch_assoc()): ?>
        <div class="room-card">
            <div class="room-header">
                <div class="room-id">Room #<?= $room['id'] ?></div>
                <div class="room-host">
                    <span class="badge">Host</span>
                    <span><?= getUser($conn, $room['host_user_id']) ?></span>
                </div>
            </div>
            
            <div class="room-body">
                <div class="user-list">
                    <!-- User 1 -->
                    <div class="user-card">
                        <div class="user-info">
                            <div class="user-avatar">1</div>
                            <div class="<?= $room['user1_id'] ? 'user-name' : 'empty-slot' ?>">
                                <?= $room['user1_id'] ? getUser($conn, $room['user1_id']) : 'Empty Slot' ?>
                            </div>
                        </div>
                        <?php if ($room['user1_id']): ?>
                            <button class="action-btn kick-btn" onclick="kickUser(this, <?= $room['id'] ?>, <?= $room['user1_id'] ?>)">
                                <i class="fas fa-user-minus"></i> Remove
                            </button>
                        <?php endif; ?>
                    </div>
                    
                    <!-- User 2 -->
                    <div class="user-card">
                        <div class="user-info">
                            <div class="user-avatar">2</div>
                            <div class="<?= $room['user2_id'] ? 'user-name' : 'empty-slot' ?>">
                                <?= $room['user2_id'] ? getUser($conn, $room['user2_id']) : 'Empty Slot' ?>
                            </div>
                        </div>
                        <?php if ($room['user2_id']): ?>
                            <button class="action-btn kick-btn" onclick="kickUser(this, <?= $room['id'] ?>, <?= $room['user2_id'] ?>)">
                                <i class="fas fa-user-minus"></i> Remove
                            </button>
                        <?php endif; ?>
                    </div>
                    
                    <!-- User 3 -->
                    <div class="user-card">
                        <div class="user-info">
                            <div class="user-avatar">3</div>
                            <div class="<?= $room['user3_id'] ? 'user-name' : 'empty-slot' ?>">
                                <?= $room['user3_id'] ? getUser($conn, $room['user3_id']) : 'Empty Slot' ?>
                            </div>
                        </div>
                        <?php if ($room['user3_id']): ?>
                            <button class="action-btn kick-btn" onclick="kickUser(this, <?= $room['id'] ?>, <?= $room['user3_id'] ?>)">
                                <i class="fas fa-user-minus"></i> Remove
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="actions-container">
                    <button class="action-btn end-room-btn" onclick="endRoom(this, <?= $room['id'] ?>)">
                        <i class="fas fa-trash-alt"></i> End Room
                    </button>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.17.2/dist/sweetalert2.all.min.js"></script>
<script>
function kickUser(button, roomId, userId) {
    Swal.fire({
        icon: 'warning',
        title: 'Kick this user?',
        showCancelButton: true,
        confirmButtonText: 'Yes, kick'
    }).then(result => {
        if (result.isConfirmed) {
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `ajax=1&kick=1&room_id=${roomId}&user_id=${userId}`
            }).then(res => res.json()).then(data => {
                if (data.success) {
                    Swal.fire('Kicked!', data.message, 'success');
                    button.closest('.user-card').remove();
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            });
        }
    });
}

function endRoom(button, roomId) {
    Swal.fire({
        icon: 'warning',
        title: 'End this room?',
        showCancelButton: true,
        confirmButtonText: 'Yes, end it'
    }).then(result => {
        if (result.isConfirmed) {
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `ajax=1&end_room=1&room_id=${roomId}`
            }).then(res => res.json()).then(data => {
                if (data.success) {
                    Swal.fire('Room Ended', data.message, 'success');
                    button.closest('.room-card').remove();
                } else {
                    Swal.fire('Error', data.message, 'error');
                }
            });
        }
    });
}

// Handle limit form submission
document.getElementById('limitForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append('update_limit', '1');
    
    Swal.fire({
        title: 'Updating Limit...',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });
    
    fetch('', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        Swal.close();
        if (data.success) {
            Swal.fire('Success!', data.message, 'success');
        } else {
            Swal.fire('Error', data.message, 'error');
        }
    })
    .catch(error => {
        Swal.close();
        Swal.fire('Error', 'An error occurred while updating the limit', 'error');
    });
});
</script>
</body>
</html>