<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    die("Not logged in.");
}

// Verify admin
$admin_id = $_SESSION['user_id'];
$result = $conn->query("SELECT admin FROM users WHERE id = $admin_id");
if (!$result || $result->num_rows === 0) die("Admin check failed.");
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    header('Location: index.php'); // Redirect non-admin users
    exit();
}

// Function to get username by ID
function getUsername($conn, $user_id) {
    $sql = "SELECT username FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    return $user ? $user['username'] : 'Deleted User';
}

// Fetch data functions with usernames
function fetchChatData($conn) {
    $sql = "SELECT id, user1_id, user2_id, connected_at FROM chat_connections ORDER BY connected_at DESC";
    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $row['user1_name'] = getUsername($conn, $row['user1_id']);
        $row['user2_name'] = getUsername($conn, $row['user2_id']);
        $data[] = $row;
    }
    return $data;
}

function fetchVideoData($conn) {
    $sql = "SELECT id, caller_id, receiver_id, start_time, end_time FROM video_calls ORDER BY start_time DESC";
    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $row['caller_name'] = getUsername($conn, $row['caller_id']);
        $row['receiver_name'] = getUsername($conn, $row['receiver_id']);
        
        // Calculate call duration if end_time exists
        $row['duration'] = '';
        if ($row['end_time']) {
            $start = new DateTime($row['start_time']);
            $end = new DateTime($row['end_time']);
            $interval = $start->diff($end);
            $row['duration'] = sprintf(
                "%d:%02d:%02d",
                $interval->h,
                $interval->i,
                $interval->s
            );
        }
        
        $data[] = $row;
    }
    return $data;
}

$chatData = fetchChatData($conn);
$videoData = fetchVideoData($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connection Analytics</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #f8f9fc;
            --text-dark: #2e384d;
            --text-light: #5a5c69;
            --border: #e3e6f0;
            --success: #1cc88a;
            --warning: #f6c23e;
        }
        
        body {
            background-color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            padding-top: 60px;
        }
        
        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background: white;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border);
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            z-index: 1000;
        }
        
        .back-btn {
            background: none;
            border: none;
            font-size: 18px;
            color: var(--text-light);
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            border-radius: 50%;
            cursor: pointer;
        }
        
        .back-btn:hover {
            background: #f1f5f9;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 15px;
        }
        
        .card {
            border: none;
            border-radius: 8px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            background-color: var(--primary);
            color: white;
            font-weight: 600;
            border-radius: 8px 8px 0 0 !important;
            padding: 12px 20px;
        }
        
        .nav-tabs {
            border-bottom: 1px solid var(--border);
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
            white-space: nowrap;
        }
        
        .nav-tabs .nav-link {
            color: var(--text-light);
            font-weight: 500;
            border: none;
            padding: 10px 16px;
            flex: 1;
            text-align: center;
            min-width: 180px;
        }
        
        .nav-tabs .nav-link.active {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            background-color: transparent;
        }
        
        .table {
            margin-bottom: 0;
            width: 100%;
        }
        
        .table th {
            background-color: var(--secondary);
            color: var(--text-dark);
            font-weight: 600;
            padding: 12px 16px;
            white-space: nowrap;
        }
        
        .table td {
            padding: 12px 16px;
            vertical-align: middle;
        }
        
        .badge {
            font-weight: 500;
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        .user-id {
            font-weight: 600;
            color: var(--primary);
        }
        
        .user-name {
            display: block;
            font-size: 0.8rem;
            color: var(--text-light);
        }
        
        .timestamp {
            font-size: 0.85rem;
            color: var(--text-light);
            white-space: nowrap;
        }
        
        .duration {
            font-weight: 600;
            color: var(--success);
        }
        
        .connection-id {
            font-size: 0.75rem;
            color: #6c757d;
        }
        
        @media (max-width: 768px) {
            .table-responsive {
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
            }
            
            .nav-tabs .nav-link {
                min-width: 150px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4 class="mb-0">Connection Analytics</h4>
        <div style="width: 36px;"></div> <!-- Spacer -->
    </div>

    <div class="container">
        <!-- Main Card -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="fas fa-chart-line mr-2"></i>Connection Data</span>
                <div>
                    <span class="badge bg-light text-dark me-2">
                        <i class="fas fa-comments text-primary me-1"></i> <?= count($chatData) ?> Chats
                    </span>
                    <span class="badge bg-light text-dark">
                        <i class="fas fa-video text-primary me-1"></i> <?= count($videoData) ?> Calls
                    </span>
                </div>
            </div>
            
            <div class="card-body">
                <!-- Horizontal Tabs -->
                <ul class="nav nav-tabs mb-4" id="connectionsTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="chat-tab" data-bs-toggle="tab" data-bs-target="#chat" type="button" role="tab">
                            <i class="fas fa-comments me-2"></i>Chat Connections
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="video-tab" data-bs-toggle="tab" data-bs-target="#video" type="button" role="tab">
                            <i class="fas fa-video me-2"></i>Video Calls
                        </button>
                    </li>
                </ul>
                
                <!-- Tab Content -->
                <div class="tab-content" id="connectionsTabContent">
                    <!-- Chat Connections Tab -->
                    <div class="tab-pane fade show active" id="chat" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Connection ID</th>
                                        <th>Participants</th>
                                        <th>Connected At</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($chatData as $row): ?>
                                    <tr>
                                        <td class="connection-id">#<?= htmlspecialchars($row['id']) ?></td>
                                        <td>
                                            <span class="user-id">User <?= htmlspecialchars($row['user1_id']) ?></span>
                                            <span class="user-name"><?= htmlspecialchars($row['user1_name']) ?></span>
                                            <i class="fas fa-exchange-alt mx-2 text-muted"></i>
                                            <span class="user-id">User <?= htmlspecialchars($row['user2_id']) ?></span>
                                            <span class="user-name"><?= htmlspecialchars($row['user2_name']) ?></span>
                                        </td>
                                        <td class="timestamp"><?= htmlspecialchars($row['connected_at']) ?></td>
                                        <td><span class="badge bg-success bg-opacity-10 text-success">Connected</span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <!-- Video Calls Tab -->
                    <div class="tab-pane fade" id="video" role="tabpanel">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Call ID</th>
                                        <th>Participants</th>
                                        <th>Start Time</th>
                                        <th>End Time</th>
                                        <th>Duration</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($videoData as $row): ?>
                                    <tr>
                                        <td class="connection-id">#<?= htmlspecialchars($row['id']) ?></td>
                                        <td>
                                            <span class="user-id">User <?= htmlspecialchars($row['caller_id']) ?></span>
                                            <span class="user-name"><?= htmlspecialchars($row['caller_name']) ?></span>
                                            <i class="fas fa-video mx-2 text-muted"></i>
                                            <span class="user-id">User <?= htmlspecialchars($row['receiver_id']) ?></span>
                                            <span class="user-name"><?= htmlspecialchars($row['receiver_name']) ?></span>
                                        </td>
                                        <td class="timestamp"><?= htmlspecialchars($row['start_time']) ?></td>
                                        <td class="timestamp"><?= htmlspecialchars($row['end_time']) ?></td>
                                        <td class="duration"><?= $row['duration'] ? htmlspecialchars($row['duration']) : '-' ?></td>
                                        <td>
                                            <span class="badge <?= $row['end_time'] ? 'bg-success bg-opacity-10 text-success' : 'bg-warning bg-opacity-10 text-warning' ?>">
                                                <?= $row['end_time'] ? 'Completed' : 'In Progress' ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Simple refresh every 30 seconds
        setTimeout(() => {
            window.location.reload();
        }, 30000);
    </script>
</body>
</html>