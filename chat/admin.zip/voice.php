<?php
require 'db.php';
session_start();

if (empty($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

if (!isset($_SESSION['username'])) {
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();
    $_SESSION['username'] = $username;
}

$username = $_SESSION['username'];
$msg = "";

// Check if room deletion is requested
if (isset($_GET['delete_room'])) {
    $del_id = (int)$_GET['delete_room'];

    // Remove room_id link in voice_joins without deleting row
    $stmt = $conn->prepare("UPDATE voice_joins SET room_id = NULL WHERE room_id = ?");
    $stmt->bind_param("i", $del_id);
    $stmt->execute();
    $stmt->close();

    // Now safely delete from voice
    $stmt = $conn->prepare("DELETE FROM voice WHERE id = ? AND host_user_id = ?");
    $stmt->bind_param("ii", $del_id, $user_id);
    $stmt->execute();
    $stmt->close();

    $msg = "Room deleted successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voice Rooms</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
    :root {
        --bg-color: #fafafa;
        --card-bg: #ffffff;
        --border-color: #dbdbdb;
        --text-dark: #262626;
        --primary: #4361ee;
        --primary-hover: #3a56d4;
        --primary-light: #eef2ff;
        --secondary: #f8f9fa;
        --text: #212529;
        --text-light: #6c757d;
        --border: #e9ecef;
        --success: #ffe4ec;
        --verified: #1da1f2;
        --error: #ef4444;
        --card-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        --card-shadow-hover: 0 8px 15px rgba(0, 0, 0, 0.1);
        --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
    }
    
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }
    
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        background-color: var(--bg-color);
        color: var(--text);
        padding: 20px;
        line-height: 1.5;
    }
    
    .container {
        max-width: 500px;
        margin: 90px auto 90px;
    }
    
    h1, h2, h3 {
        color: var(--text);
        margin-bottom: 1rem;
    }
    
    h2 {
        font-size: 1.4rem;
        font-weight: 600;
    }
    
    h3 {
        font-size: 1.1rem;
        font-weight: 500;
        color: var(--text-light);
    }
    
    .card {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: var(--card-shadow);
        transition: var(--transition);
    }
    
    .btn {
        display: inline-block;
        background-color: var(--primary);
        color: white;
        border: none;
        padding: 12px 20px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 0.95rem;
        cursor: pointer;
        width: 100%;
        transition: var(--transition);
        text-align: center;
    }
    
    .btn:hover {
        background-color: var(--primary-hover);
    }
    
    .btn-secondary {
        background-color: var(--secondary);
        color: var(--text);
        border: 1px solid var(--border);
    }
    
    .btn-secondary:hover {
        background-color: #e9ecef;
    }
    
    .message {
        background-color: rgba(46, 204, 113, 0.1);
        border: 1px solid var(--success);
        padding: 12px 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        font-weight: 500;
        color: var(--text);
    }
    
    .message.error {
        background-color: rgba(239, 68, 68, 0.1);
        border-color: var(--error);
    }
    
    .room-list {
        margin-top: 2rem;
    }
    
    .room-item {
        background: var(--card-bg);
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
        box-shadow: var(--card-shadow);
        transition: var(--transition);
        position: relative;
    }
    
    .room-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
        margin-right: 12px;
        flex-shrink: 0;
    }
    
    .room-info {
        flex-grow: 1;
    }
    
    .room-host {
        display: flex;
        align-items: center;
        font-weight: 600;
        margin-bottom: 4px;
    }
    
    .verified-badge {
        color: var(--verified);
        margin-left: 5px;
        font-size: 0.9rem;
    }
    
    .room-details {
        display: flex;
        align-items: center;
        font-size: 0.85rem;
        color: var(--text-light);
    }
    
    .user-count {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background-color: var(--secondary);
        color: var(--text);
        width: 24px;
        height: 24px;
        border-radius: 50%;
        font-size: 0.75rem;
        font-weight: 600;
        margin-right: 8px;
    }
    
    .room-actions {
        display: flex;
        gap: 10px;
    }
    
    .action-btn {
        padding: 8px 12px;
        border-radius: 6px;
        font-weight: 500;
        font-size: 0.85rem;
        text-decoration: none;
        cursor: pointer;
        transition: var(--transition);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    
    .join-btn {
        background-color: var(--primary);
        color: white;
        border: none;
    }
    
    .full-btn {
        background-color: var(--secondary);
        color: var(--text-light);
        border: 1px solid var(--border);
        cursor: not-allowed;
    }
    
    .delete-btn {
        background-color: var(--secondary);
        color: var(--error);
        border: 1px solid #f1aeb5;
    }
    
    .join-btn:hover {
        background-color: var(--primary-hover);
    }
    
    .delete-btn:hover {
        background-color: #f1f3f5;
    }
    
    .empty-state {
        text-align: center;
        padding: 30px 0;
        color: var(--text-light);
    }
    
    .empty-state p {
        margin-top: 10px;
    }
    
    .create-btn {
        position: fixed;
        bottom: 80px;
        right: 30px;
        width: 60px;
        height: 60px;
        background-color: var(--primary);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(67, 97, 238, 0.3);
        z-index: 100;
        text-decoration: none !important;
        transition: var(--transition);
    }
    
    .create-btn:hover {
        background-color: var(--primary-hover);
        transform: scale(1.05);
    }
    
    .create-btn i {
        font-size: 24px;
    }
    
    @media (max-width: 600px) {
        body {
            padding: 15px;
        }
        
        .container {
            width: 100%;
            margin: 90px 0 90px;
        }
        
        .room-actions {
            flex-direction: column;
            gap: 8px;
        }
        
        .action-btn {
            width: 100%;
            justify-content: center;
        }
        
        .create-btn {
            bottom: 80px;
            right: 20px;
            width: 50px;
            height: 50px;
        }
    }
    
    .verified-badge {
        height: 16px;
        width: 16px;
        margin-left: 5px;
        vertical-align: middle;
    }
</style>
</head>
<body>
<?php include('menu.php'); ?>

<div class="container">
    <?php if (!empty($msg)): ?>
        <div class="message <?php echo strpos($msg, 'error') !== false ? 'error' : ''; ?>">
            <?php echo $msg; ?>
        </div>
    <?php endif; ?>
    
    <div class="room-list">
        <?php 
        // Fetch only public rooms (where room_code is NULL)
        $public_rooms = $conn->query("
            SELECT v.id, v.max_users, v.user1_id, v.user2_id, v.user3_id, 
                   u.username, u.profile_pic, u.verified, v.host_user_id 
            FROM voice v
            JOIN users u ON v.host_user_id = u.id
            WHERE v.room_code IS NULL
            ORDER BY v.created_at DESC
        ");
        
        if ($public_rooms->num_rows > 0): ?>
            <?php while ($row = $public_rooms->fetch_assoc()): ?>
                <?php
                // Count only guest users (not host)
                $count = 0;
                if ($row['user1_id']) $count++;
                if ($row['user2_id']) $count++;
                if ($row['user3_id']) $count++;
                
                // Room is full when guest count reaches max_users - 1 
                $is_full = ($count >= ($row['max_users'] - 1));
                $profilePic = $row['profile_pic'] ? htmlspecialchars($row['profile_pic']) : 'assets/default_dp.png';
                $verifiedBadge = $row['verified'] == 1 ? 
                    '<img src="assets/verified.png" class="verified-badge" alt="Verified">' : '';
                ?>
                
                <div class="room-item">
                    <img src="<?php echo $profilePic; ?>" alt="Profile" class="room-avatar">
                    <div class="room-info">
                        <div class="room-host">
                            <?php echo htmlspecialchars($row['username']); ?>
                            <?php echo $verifiedBadge; ?>
                        </div>
                        <div class="room-details">
                            <span class="user-count" data-current="<?= $count ?>" data-max="<?= $row['max_users'] ?>">
                                <?= $count + 1 ?> <!-- +1 to include host -->
                            </span>
                            / <?= $row['max_users'] ?> connected
                        </div>
                    </div>
                    <div class="room-actions">
                        <?php if ($row['host_user_id'] == $user_id): ?>
                            <!-- Host can always join, even if full -->
                            <a href="vroom.php?room_id=<?= $row['id'] ?>" class="action-btn join-btn">
                                <i class="fas fa-sign-in-alt"></i> Join
                            </a>
                            <a href="?delete_room=<?= $row['id'] ?>" class="action-btn delete-btn">
                                <i class="fas fa-trash"></i> End
                            </a>
                        <?php elseif ($is_full): ?>
                            <!-- Show full message for non-hosts -->
                            <button class="action-btn full-btn" disabled>
                                <i class="fas fa-users-slash"></i> Full
                            </button>
                        <?php else: ?>
                            <!-- Join button for non-hosts when not full -->
                            <a href="vroom.php?room_id=<?= $row['id'] ?>" class="action-btn join-btn">
                                <i class="fas fa-sign-in-alt"></i> Join
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="empty-state">
                <h3>No public rooms available</h3>
                <p>Be the first to create a public room!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Create Room Floating Button -->
<a href="vhost.php" class="create-btn">
    <i class="fas fa-plus"></i>
</a>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.17.2/dist/sweetalert2.all.min.js"></script>
<script>
// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Confirm room deletion
    document.querySelectorAll('.delete-btn').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            Swal.fire({
                title: 'End Room?',
                text: "Are you sure you want to end this room?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#4361ee',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Yes, end it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = this.getAttribute('href');
                }
            });
        });
    });

    // Prevent joining full rooms (only for non-hosts)
    document.querySelectorAll('.join-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            // Skip full check if user is host (has delete button)
            const isHost = this.closest('.room-item').querySelector('.delete-btn') !== null;
            if (isHost) return;
            
            const userCount = this.closest('.room-item').querySelector('.user-count');
            const current = parseInt(userCount.dataset.current);
            const max = parseInt(userCount.dataset.max);
            
            // Check against max-1 since host doesn't count against capacity
            if (current >= max) {
                e.preventDefault();
                Swal.fire({
                    title: 'Room Full',
                    text: 'This room has reached maximum capacity',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            }
        });
    });
});
</script>
</body>
</html>