<?php
require 'db.php';
session_start();

// Validate session and input
if (empty($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit(json_encode(['error' => 'Authentication required']));
}

$room_id = (int)($_GET['room_id'] ?? 0);
if ($room_id <= 0) {
    header('HTTP/1.1 400 Bad Request');
    exit(json_encode(['error' => 'Invalid room ID']));
}

try {
    // Get room info with host details - Removed is_active check
    $stmt = $conn->prepare("
        SELECT v.*, u.username as host_username, 
               u.profile_pic as host_profile_pic, 
               u.verified as host_verified
        FROM voice v
        JOIN users u ON v.host_user_id = u.id
        WHERE v.id = ?
    ");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $room = $stmt->get_result()->fetch_assoc();

    if (!$room) {
        header('HTTP/1.1 404 Not Found');
        exit(json_encode(['error' => 'Room not found'])); // Removed "or inactive" from message
    }

    // Prepare response with host information
    $response = [
        [
            'id' => $room['host_user_id'],
            'username' => $room['host_username'],
            'profile_pic' => $room['host_profile_pic'] ?: 'assets/default_dp.png',
            'verified' => (bool)$room['host_verified'],
            'is_host' => true
        ]
    ];

    // Get participant IDs
    $participant_ids = [];
    foreach (['user1_id', 'user2_id', 'user3_id'] as $slot) {
        if (!empty($room[$slot]) && $room[$slot] != $room['host_user_id']) {
            $participant_ids[] = $room[$slot];
        }
    }

    // Get participant details if any
    if (!empty($participant_ids)) {
        $placeholders = implode(',', array_fill(0, count($participant_ids), '?'));
        $types = str_repeat('i', count($participant_ids));
        
        $stmt = $conn->prepare("
            SELECT id, username, profile_pic, verified 
            FROM users 
            WHERE id IN ($placeholders)
        ");
        $stmt->bind_param($types, ...$participant_ids);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($user = $result->fetch_assoc()) {
            $response[] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'profile_pic' => $user['profile_pic'] ?: 'assets/default_dp.png',
                'verified' => (bool)$user['verified'],
                'is_host' => false
            ];
        }
    }

    header('Content-Type: application/json');
    echo json_encode($response);

} catch (Exception $e) {
    header('HTTP/1.1 500 Internal Server Error');
    exit(json_encode(['error' => 'Database error']));
}