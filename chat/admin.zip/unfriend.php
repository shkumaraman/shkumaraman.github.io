<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    header("Location: friends.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$friend_id = $_GET['id'];

// Remove from friend_requests table
$sql = "DELETE FROM friend_requests WHERE 
        (sender_id = ? AND receiver_id = ?) OR 
        (sender_id = ? AND receiver_id = ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
$stmt->execute();

header("Location: friends.php");
exit();
?>
