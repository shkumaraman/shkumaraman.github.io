<?php
session_start();

// Immediately return unauthorized if not logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require 'db.php';

$user_id = (int)$_SESSION['user_id'];
$status = $_POST['status'] ?? '';

// Validate status input
if (!in_array($status, ['online', 'offline'])) {
    http_response_code(400);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid status']);
    exit();
}

// Only update status and last_activity
$sql = "UPDATE status SET vcstatus = ?, last_activity = NOW() WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('si', $status, $user_id);

if ($stmt->execute()) {
    // Success response
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
} else {
    // Database error
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Database update failed']);
}

$stmt->close();
$conn->close();
?>