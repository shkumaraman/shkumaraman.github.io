<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle direct link access to a specific post
if (isset($_GET['post'])) {
    $_SESSION['view_single_post'] = (int)$_GET['post'];
}

// Handle feed filter changes
if (isset($_GET['filter'])) {
    $_SESSION['feed_filter'] = $_GET['filter'];
    header("Location: feed.php");
    exit();
}

// Handle search query
if (isset($_GET['search'])) {
    $_SESSION['feed_search'] = mysqli_real_escape_string($conn, $_GET['search']);
    header("Location: feed.php");
    exit();
}

// Clear search if requested
if (isset($_GET['clear_search'])) {
    unset($_SESSION['feed_search']);
    header("Location: feed.php");
    exit();
}

// Upload Feed
if (isset($_POST['action']) && $_POST['action'] === 'upload') {
    $text = mysqli_real_escape_string($conn, $_POST['text']);
    $image = '';
    
    if (!empty($_FILES['image']['name'])) {
        $image_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $folder = "uploads/feed/";
        if (!is_dir($folder)) mkdir($folder, 0777, true);
        $path = $folder . $image_name;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
            $image = $path;
        }
    }
    
    mysqli_query($conn, "INSERT INTO feeds (user_id, text, image) VALUES ($user_id, '$text', '$image')");
    exit;
}

// Like / Unlike
if (isset($_POST['action']) && $_POST['action'] === 'like') {
    $feed_id = (int)$_POST['feed_id'];
    $exists = mysqli_query($conn, "SELECT * FROM feed_reactions WHERE user_id=$user_id AND feed_id=$feed_id AND reaction_type='like'");
    if (mysqli_num_rows($exists)) {
        mysqli_query($conn, "DELETE FROM feed_reactions WHERE user_id=$user_id AND feed_id=$feed_id AND reaction_type='like'");
    } else {
        mysqli_query($conn, "INSERT INTO feed_reactions (user_id, feed_id, reaction_type) VALUES ($user_id, $feed_id, 'like')");
    }
    exit;
}

// Delete Feed
if (isset($_POST['action']) && $_POST['action'] === 'delete') {
    $feed_id = (int)$_POST['feed_id'];
    $owner = mysqli_query($conn, "SELECT * FROM feeds WHERE id=$feed_id AND user_id=$user_id");
    if (mysqli_num_rows($owner)) {
        // Delete associated image file if exists
        $feed = mysqli_fetch_assoc($owner);
        if (!empty($feed['image']) && file_exists($feed['image'])) {
            unlink($feed['image']);
        }
        
        mysqli_query($conn, "DELETE FROM feeds WHERE id=$feed_id");
        mysqli_query($conn, "DELETE FROM feed_reactions WHERE feed_id=$feed_id");
        mysqli_query($conn, "DELETE FROM reports WHERE feed_id=$feed_id");
    }
    exit;
}

// Report Feed
if (isset($_POST['action']) && $_POST['action'] === 'report') {
    $feed_id = (int)$_POST['feed_id'];
    $reason = mysqli_real_escape_string($conn, $_POST['reason']);
    $check = mysqli_query($conn, "SELECT * FROM reports WHERE user_id=$user_id AND feed_id=$feed_id");
    if (!mysqli_num_rows($check)) {
        mysqli_query($conn, "INSERT INTO reports (user_id, feed_id, reason) VALUES ($user_id, $feed_id, '$reason')");
    }
    exit;
}

// Add Comment
if (isset($_POST['action']) && $_POST['action'] === 'comment') {
    $feed_id = (int)$_POST['feed_id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);
    mysqli_query($conn, "INSERT INTO feed_reactions (user_id, feed_id, reaction_type, content) VALUES ($user_id, $feed_id, 'comment', '$comment')");
    
    // Return the new comment HTML to update the UI without refresh
    $new_comment_id = mysqli_insert_id($conn);
    $comment_data = mysqli_fetch_assoc(mysqli_query($conn, "
        SELECT r.*, u.username, u.profile_pic, u.verified
        FROM feed_reactions r
        JOIN users u ON r.user_id = u.id
        WHERE r.id = $new_comment_id
    "));
    
    $profilePic = !empty($comment_data['profile_pic']) ? $comment_data['profile_pic'] : 'assets/default_dp.png';
    $verifiedBadge = $comment_data['verified'] ? "<img src='assets/verified.png' class='verified-badge' alt='Verified'>" : "";
    
    echo "<div class='feed-card' id='comment-{$comment_data['id']}'>
            <img src='$profilePic' class='comment-avatar' onerror=\"this.src='assets/default_dp.png'\">
            <div class='comment-content'>
                <div class='comment-header'>
                    <b>{$comment_data['username']} $verifiedBadge</b>
                    <small>" . date('M j, Y g:i A', strtotime($comment_data['created_at'])) . "</small>
                    <button class='delete-comment-btn' onclick='deleteReaction({$comment_data['id']}, this)'>Delete</button>
                </div>
                <p>{$comment_data['content']}</p>
                <div class='comment-actions'>
                    <button class='reply-btn' onclick='toggleReplyForm({$comment_data['id']})'>Reply</button>
                </div>
                <div class='reply-form' id='reply-form-{$comment_data['id']}'>
                    <input type='text' placeholder='Write a reply...' class='reply-input' id='reply-input-{$comment_data['id']}'>
                    <button onclick='addReply({$comment_data['id']})'>Post</button>
                </div>
                <div class='replies-list' id='replies-{$comment_data['id']}'></div>
            </div>
        </div>";
    exit;
}

// Add Reply - MODIFIED TO ALLOW ANYONE TO REPLY
if (isset($_POST['action']) && $_POST['action'] === 'reply') {
    $comment_id = (int)$_POST['comment_id'];
    $reply = mysqli_real_escape_string($conn, $_POST['reply']);
    
    // Get the feed_id for this comment (no permission check)
    $feed_query = mysqli_query($conn, "SELECT f.id 
        FROM feed_reactions r
        JOIN feeds f ON r.feed_id = f.id
        WHERE r.id = $comment_id AND r.reaction_type = 'comment'");
        
    if (mysqli_num_rows($feed_query)) {
        $feed_data = mysqli_fetch_assoc($feed_query);
        $feed_id = $feed_data['id'];
        
        mysqli_query($conn, "INSERT INTO feed_reactions (user_id, feed_id, parent_id, reaction_type, content) 
                           VALUES ($user_id, $feed_id, $comment_id, 'reply', '$reply')");
        
        // Return the new reply HTML to update the UI without refresh
        $new_reply_id = mysqli_insert_id($conn);
        $reply_data = mysqli_fetch_assoc(mysqli_query($conn, "
            SELECT r.*, u.username, u.profile_pic, u.verified
            FROM feed_reactions r
            JOIN users u ON r.user_id = u.id
            WHERE r.id = $new_reply_id
        "));
        
        $profilePic = !empty($reply_data['profile_pic']) ? $reply_data['profile_pic'] : 'assets/default_dp.png';
        $verifiedBadge = $reply_data['verified'] ? "<img src='assets/verified.png' class='verified-badge' alt='Verified'>" : "";
        
        echo "<div class='feed-card' id='reply-{$reply_data['id']}'>
                <img src='$profilePic' class='reply-avatar' onerror=\"this.src='assets/default_dp.png'\">
                <div class='reply-content'>
                    <div class='reply-header'>
                        <b>{$reply_data['username']} $verifiedBadge</b>
                        <small>" . date('M j, Y g:i A', strtotime($reply_data['created_at'])) . "</small>
                        <button class='delete-reply-btn' onclick='deleteReaction({$reply_data['id']}, this)'>Delete</button>
                    </div>
                    <p>{$reply_data['content']}</p>
                </div>
            </div>";
    }
    exit;
}

// Delete Comment/Reply
if (isset($_POST['action']) && $_POST['action'] === 'delete_reaction') {
    $reaction_id = (int)$_POST['reaction_id'];
    $owner = mysqli_query($conn, "SELECT * FROM feed_reactions WHERE id=$reaction_id AND user_id=$user_id");
    if (mysqli_num_rows($owner)) {
        mysqli_query($conn, "DELETE FROM feed_reactions WHERE id=$reaction_id OR parent_id=$reaction_id");
    }
    exit;
}

// Load Feeds - MODIFIED FOR LAZY LOADING
if (isset($_GET['action']) && $_GET['action'] === 'fetch') {
    $where_clause = "";
    $order_clause = "ORDER BY RAND()"; // Random order
    $limit_clause = isset($_GET['offset']) ? "LIMIT " . (int)$_GET['offset'] . ", 5" : "LIMIT 5";
    
    // If viewing a single post from shared link
    if (isset($_SESSION['view_single_post'])) {
        $where_clause = "WHERE f.id = " . (int)$_SESSION['view_single_post'];
        unset($_SESSION['view_single_post']);
    } 
    // If viewing filtered posts
    elseif (isset($_SESSION['feed_filter'])) {
        switch ($_SESSION['feed_filter']) {
            case 'my':
                $where_clause = "WHERE f.user_id = $user_id";
                break;
            case 'friends':
                $where_clause = "WHERE f.user_id = $user_id OR f.user_id IN (
                    SELECT CASE 
                        WHEN sender_id = $user_id THEN receiver_id 
                        ELSE sender_id 
                    END 
                    FROM friend_requests 
                    WHERE (sender_id = $user_id OR receiver_id = $user_id) 
                    AND status = 'accepted'
                )";
                break;
            default: // 'all'
                $where_clause = "";
        }
    }
    
    // Add search condition if exists
    if (isset($_SESSION['feed_search']) && !empty($_SESSION['feed_search'])) {
        $search = $_SESSION['feed_search'];
        $where_clause .= ($where_clause ? " AND " : "WHERE ") . "(f.text LIKE '%$search%' OR u.username LIKE '%$search%')";
    }
    
    $feeds = mysqli_query($conn, "
        SELECT f.*, u.username, u.profile_pic, u.verified,
        (SELECT COUNT(*) FROM feed_reactions WHERE feed_id=f.id AND reaction_type='like') AS like_count,
        (SELECT COUNT(*) FROM feed_reactions WHERE feed_id=f.id AND user_id=$user_id AND reaction_type='like') AS user_liked,
        (SELECT COUNT(*) FROM feed_reactions WHERE feed_id=f.id AND reaction_type='comment') AS comment_count
        FROM feeds f
        JOIN users u ON f.user_id = u.id
        $where_clause
        $order_clause
        $limit_clause
    ");
    
    if (mysqli_num_rows($feeds) === 0 && isset($_GET['offset'])) {
        echo "no_more_posts";
        exit;
    }
    
    while ($row = mysqli_fetch_assoc($feeds)) {
        $likeText = $row['user_liked'] ? '❤️ Liked' : '🤍 Like';
        $profilePic = !empty($row['profile_pic']) ? $row['profile_pic'] : 'assets/default_dp.png';
        $verifiedBadge = $row['verified'] ? "<img src='assets/verified.png' class='verified-badge' alt='Verified'>" : "";
        
        echo "<div class='feed-card' id='feed-{$row['id']}'>
                <div class='feed-header'>
                    <div class='user-info'>
                        <img src='$profilePic' class='avatar' onerror=\"this.src='assets/default_dp.png'\">
                        <div>
                            <b>{$row['username']} $verifiedBadge</b>
                            <small>" . date('M j, Y g:i A', strtotime($row['created_at'])) . "</small>
                        </div>
                    </div>
                    " . ($row['user_id'] == $user_id ? "<button class='icon-btn' onclick='deletePost({$row['id']})' title='Delete'>✕</button>" : "") . "
                </div>
                <div class='feed-content'>
                    <p>" . htmlspecialchars($row['text']) . "</p>
                    " . (!empty($row['image']) ? "<img src='{$row['image']}' class='feed-image' onerror=\"this.style.display='none'\">" : "") . "
                </div>
                <div class='feed-actions'>
                    <button class='action-btn " . ($row['user_liked'] ? 'liked' : '') . "' onclick='likePost({$row['id']}, this)'>
                        {$likeText} <span class='count'>{$row['like_count']}</span>
                    </button>
                    <button class='action-btn' onclick='sharePost({$row['id']})' title='Share'>
                        🔗 Share
                    </button>
                    <button class='action-btn report-btn' onclick='showReportModal({$row['id']})' title='Report'>
                        🚩 Report
                    </button>
                </div>
                <div class='comments-section'>
                    <div class='comment-form'>
                        <input type='text' placeholder='Write a comment...' class='comment-input' id='comment-input-{$row['id']}'>
                        <button onclick='addComment({$row['id']})'>Post</button>
                    </div>
                    <div class='comments-list' id='comments-{$row['id']}'></div>
                    " . ($row['comment_count'] > 2 ? "<button class='view-more-comments' onclick='loadAllComments({$row['id']}, this)'>View all {$row['comment_count']} comments</button>" : "") . "
                </div>
            </div>";
    }
    exit;
}

// Load Comments (with limit for initial load)
if (isset($_GET['action']) && $_GET['action'] === 'get_comments') {
    $feed_id = (int)$_GET['feed_id'];
    $limit = isset($_GET['all']) ? "" : "LIMIT 2";
    $comments = mysqli_query($conn, "
        SELECT r.*, u.username, u.profile_pic, u.verified,
        (SELECT COUNT(*) FROM feed_reactions WHERE parent_id=r.id AND reaction_type='reply') AS reply_count
        FROM feed_reactions r
        JOIN users u ON r.user_id = u.id
        WHERE r.feed_id = $feed_id AND r.reaction_type = 'comment'
        ORDER BY r.created_at DESC
        $limit
    ");
    
    while ($comment = mysqli_fetch_assoc($comments)) {
        $profilePic = !empty($comment['profile_pic']) ? $comment['profile_pic'] : 'assets/default_dp.png';
        $verifiedBadge = $comment['verified'] ? "<img src='assets/verified.png' class='verified-badge' alt='Verified'>" : "";
        $deleteBtn = $comment['user_id'] == $user_id ? "<button class='delete-comment-btn' onclick='deleteReaction({$comment['id']}, this)'>Delete</button>" : "";
        $hasReplies = $comment['reply_count'] > 0;
        
        echo "<div class='feed-card' id='comment-{$comment['id']}'>
                <img src='$profilePic' class='comment-avatar' onerror=\"this.src='assets/default_dp.png'\">
                <div class='comment-content'>
                    <div class='comment-header'>
                        <b>{$comment['username']} $verifiedBadge</b>
                        <small>" . date('M j, Y g:i A', strtotime($comment['created_at'])) . "</small>
                        $deleteBtn
                    </div>
                    <p>{$comment['content']}</p>
                    <div class='comment-actions'>
                        <button class='reply-btn' onclick='toggleReplyForm({$comment['id']})'>Reply</button>
                        " . ($hasReplies ? "<button class='toggle-replies-btn' onclick='toggleReplies({$comment['id']}, this)'>▼ Replies ({$comment['reply_count']})</button>" : "") . "
                    </div>
                    <div class='reply-form' id='reply-form-{$comment['id']}'>
                        <input type='text' placeholder='Write a reply...' class='reply-input' id='reply-input-{$comment['id']}'>
                        <button onclick='addReply({$comment['id']})'>Post</button>
                    </div>
                    " . ($hasReplies ? "<div class='replies-list' id='replies-{$comment['id']}' style='display:none'></div>" : "") . "
                </div>
            </div>";
    }
    exit;
}

// Load Replies
if (isset($_GET['action']) && $_GET['action'] === 'get_replies') {
    $comment_id = (int)$_GET['comment_id'];
    $replies = mysqli_query($conn, "
        SELECT r.*, u.username, u.profile_pic, u.verified
        FROM feed_reactions r
        JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = $comment_id AND r.reaction_type = 'reply'
        ORDER BY r.created_at ASC
    ");
    
    while ($reply = mysqli_fetch_assoc($replies)) {
        $profilePic = !empty($reply['profile_pic']) ? $reply['profile_pic'] : 'assets/default_dp.png';
        $verifiedBadge = $reply['verified'] ? "<img src='assets/verified.png' class='verified-badge' alt='Verified'>" : "";
        $deleteBtn = $reply['user_id'] == $user_id ? "<button class='delete-reply-btn' onclick='deleteReaction({$reply['id']}, this)'>Delete</button>" : "";
        
        echo "<div class='feed-card' id='reply-{$reply['id']}'>
                <img src='$profilePic' class='reply-avatar' onerror=\"this.src='assets/default_dp.png'\">
                <div class='reply-content'>
                    <div class='reply-header'>
                        <b>{$reply['username']} $verifiedBadge</b>
                        <small>" . date('M j, Y g:i A', strtotime($reply['created_at'])) . "</small>
                        $deleteBtn
                    </div>
                    <p>{$reply['content']}</p>
                </div>
            </div>";
    }
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feed</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
     <style>
        :root {
            --primary: #1877f2;
            --background: #f0f2f5;
            --card-bg: #ffffff;
            --text: #050505;
            --text-secondary: #65676b;
            --border: #dddfe2;
            --hover: #f2f2f2;
            --liked: #f33e58;
            --report: #ff6b6b;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
           }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: white;
            color: black;
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
            z-index: 100;
        }
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }
        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .container {
            max-width: 600px;
            margin-top: 70px;
            padding: 20px;
        }
        
        .search-bar {
            margin: 0 20px 0;
            display: flex;
        }
        
        .search-bar input {
            flex: 1;
            padding: 8px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 15px;
            outline: none;
        }
        
        .search-bar button {
            color: white;
            border: 1px solid var(--border);
            padding: 0 15px;
            border-radius: 10px;
            margin-left: 8px;
            cursor: pointer;
        }
        
        #uploadForm {
            background: var(--card-bg);
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }
        
        #uploadForm input[type="text"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 10px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 15px;
            outline: none;
        }
        
        #uploadForm input[type="file"] {
            display: none;
        }
        
        .file-upload {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .file-upload-label {
            padding: 8px 12px;
            background: var(--hover);
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
        }
        
        #uploadForm button[type="submit"] {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            font-size: 15px;
        }
        
        .feed-card {
            background: var(--card-bg);
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.1);
            overflow: hidden;
            animation: fadeIn 0.3s ease-in-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .feed-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .avatar, .comment-avatar, .reply-avatar {
            border-radius: 50%;
            object-fit: cover;
            background: #e0e0e0;
        }
        
        .avatar {
            width: 40px;
            height: 40px;
            margin-right: 10px;
        }
        
        .user-info small {
            color: var(--text-secondary);
            font-size: 12px;
            display: block;
        }
        
        .verified-badge {
            width: 16px;
            height: 16px;
            vertical-align: middle;
            margin-left: 4px;
        }
        
        .icon-btn {
            background: none;
            border: none;
            font-size: 18px;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 5px;
        }
        
        .feed-content {
            padding: 12px 16px;
        }
        
        .feed-content p {
            margin-bottom: 12px;
            line-height: 1.4;
        }
        
        .feed-image {
            width: 100%;
            border-radius: 8px;
            max-height: 500px;
            object-fit: cover;
        }
        
        .feed-actions {
            display: flex;
            padding: 8px 16px;
            border-top: 1px solid var(--border);
        }
        
        .action-btn {
            flex: 1;
            background: none;
            border: none;
            padding: 8px;
            margin: 0 4px;
            border-radius: 5px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--text-secondary);
            font-size: 14px;
        }
        
        .action-btn:hover {
            background: var(--hover);
        }
        
        .action-btn.liked {
            color: var(--liked);
        }
        
        .action-btn .count {
            margin-left: 5px;
        }
        
        .report-btn {
            color: var(--text-secondary);
        }
        
        .report-btn:hover {
            background: var(--hover);
            color: var(--report);
        }
        
        /* Comments Section */
        .comments-section {
            padding: 0 16px 16px;
            border-top: 1px solid var(--border);
        }
        
        .comment-form {
            display: flex;
            margin-top: 12px;
        }
        
        .comment-input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 14px;
            outline: none;
        }
        
        .comment-form button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            margin-left: 8px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .comments-list {
            margin-top: 12px;
        }
        
        .comment {
            display: flex;
            margin-bottom: 12px;
            position: relative;
        }
        
        .comment-avatar {
            width: 32px;
            height: 32px;
            margin-right: 8px;
        }
        
        .comment-content {
            flex: 1;
        }
        
        .comment-header {
            display: flex;
            align-items: center;
            margin-bottom: 4px;
            flex-wrap: wrap;
        }
        
        .comment-header small {
            color: var(--text-secondary);
            font-size: 11px;
            margin-left: 8px;
        }
        
        .comment p {
            font-size: 14px;
            line-height: 1.4;
        }
        
        .comment-actions {
            margin-top: 4px;
            display: flex;
            gap: 8px;
        }
        
        .delete-comment-btn, .delete-reply-btn {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 12px;
            cursor: pointer;
            padding: 2px 4px;
        }
        
        .delete-comment-btn:hover, .delete-reply-btn:hover {
            color: #f33e58;
        }
        
        .reply-btn, .toggle-replies-btn {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 12px;
            cursor: pointer;
            padding: 2px 4px;
        }
        
        .reply-btn:hover, .toggle-replies-btn:hover {
            text-decoration: underline;
        }
        
        .reply-form {
            display: none;
            margin-top: 8px;
            margin-left: 40px;
        }
        
        .reply-input {
            flex: 1;
            padding: 8px 12px;
            border: 1px solid var(--border);
            border-radius: 20px;
            font-size: 14px;
            outline: none;
            width: calc(100% - 84px);
        }
        
        .reply-form button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            margin-left: 8px;
            cursor: pointer;
            font-size: 14px;
        }
        
        .replies-list {
            margin-left: 40px;
            margin-top: 8px;
        }
        
        .reply {
            display: flex;
            margin-bottom: 8px;
            position: relative;
        }
        
        .reply-avatar {
            width: 24px;
            height: 24px;
            margin-right: 8px;
        }
        
        .reply-content {
            flex: 1;
        }
        
        .reply-header {
            display: flex;
            align-items: center;
            margin-bottom: 2px;
            flex-wrap: wrap;
        }
        
        .reply-header small {
            color: var(--text-secondary);
            font-size: 10px;
            margin-left: 8px;
        }
        
        .reply p {
            font-size: 13px;
            line-height: 1.4;
        }
        
        .no-posts {
            text-align: center;
            padding: 40px;
            color: var(--text-secondary);
        }
        
        .view-more-comments {
            background: none;
            border: none;
            color: var(--text-secondary);
            font-size: 13px;
            cursor: pointer;
            padding: 4px 0;
            margin-top: 8px;
        }
        
        .view-more-comments:hover {
            text-decoration: underline;
        }
        
        /* Filter Bar */
        .filter-bar {
            position: fixed;
            bottom: 55px;
            left: 50%;
            transform: translateX(-50%);
            background: var(--card-bg);
            padding: 10px 20px;
            display: flex;
            justify-content: space-around;
            border-top: 1px solid var(--border);
            z-index: 100;
            box-shadow: 0 -2px 5px rgba(0,0,0,0.1);
            max-width: 800px;
            width: 100%;
        }
        
        .filter-btn {
            background: none;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            color: var(--text-secondary);
        }
        
        .filter-btn.active {
            background: var(--primary);
            color: white;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: var(--card-bg);
            margin: 15% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            animation: modalFadeIn 0.3s;
        }
        
        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .modal-content h3 {
            margin-bottom: 15px;
            color: var(--text);
        }
        
        .modal-content p {
            margin-bottom: 10px;
            color: var(--text-secondary);
        }
        
        .modal-content textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid var(--border);
            border-radius: 8px;
            resize: vertical;
            min-height: 100px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        
        .modal-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        
        .modal-actions button {
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 14px;
            border: 1px solid var(--border);
            background: var(--card-bg);
            color: var(--text);
        }
        
        .modal-actions button.primary {
            background: var(--primary);
            color: white;
            border: none;
        }
        
        .close-modal {
            color: var(--text-secondary);
            float: right;
            font-size: 24px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-modal:hover {
            color: var(--text);
        }
        
        @media (max-width: 600px) {
            body {
                padding: 10px;
                padding-bottom: 70px;
            }
            
            .feed-actions {
                flex-wrap: wrap;
            }
            
            .action-btn {
                flex: none;
                width: calc(33.33% - 8px);
                margin: 4px;
            }
            
            .filter-bar {
                padding: 10px;
            }
            
            .filter-btn {
                padding: 8px 12px;
                font-size: 13px;
            }
        }
    </style>
</head>
<body>
<?php include 'menu.php'; ?>
<div class="container">
<!-- Search Bar -->
<form class="search-bar" onsubmit="searchPosts(); return false;">
    <input type="text" id="searchInput" placeholder="Search posts..." value="<?php echo isset($_SESSION['feed_search']) ? htmlspecialchars($_SESSION['feed_search']) : ''; ?>">
    <button type="submit">🔍</button>
    <?php if(isset($_SESSION['feed_search'])): ?>
        <button type="button" onclick="clearSearch()" style="margin-left:5px;">✕</button>
    <?php endif; ?>
</form>

<form id="uploadForm" enctype="multipart/form-data">
    <input type="text" name="text" placeholder="What's on your mind?" required>
    <div class="file-upload">
        <label for="file-upload" class="file-upload-label">📷 Photo (Optional)</label>
        <span id="file-name">No file chosen</span>
    </div>
    <input type="file" name="image" id="file-upload" accept="image/*">
    <input type="hidden" name="action" value="upload">
    <button type="submit">Post</button>
</form>

<div id="feedContainer"></div>

<!-- Report Modal -->
<div id="reportModal" class="modal">
    <div class="modal-content">
        <span class="close-modal" onclick="closeModal()">&times;</span>
        <h3>Report Post</h3>
        <p>Please explain why you're reporting this post:</p>
        <textarea id="reportReason" placeholder="Enter reason..."></textarea>
        <div class="modal-actions">
            <button onclick="closeModal()">Cancel</button>
            <button onclick="submitReport()" class="primary">Submit</button>
        </div>
    </div>
</div>

<!-- Filter Bar -->
<div class="filter-bar">
    <button class="filter-btn <?php echo (!isset($_SESSION['feed_filter']) || $_SESSION['feed_filter'] === 'all' ? 'active' : ''); ?>" onclick="setFilter('all')">
        🌍 All
    </button>
    <button class="filter-btn <?php echo (isset($_SESSION['feed_filter']) && $_SESSION['feed_filter'] === 'friends' ? 'active' : ''); ?>" onclick="setFilter('friends')">
        👥 Friends
    </button>
    <button class="filter-btn <?php echo (isset($_SESSION['feed_filter']) && $_SESSION['feed_filter'] === 'my' ? 'active' : ''); ?>" onclick="setFilter('my')">
        👤 My Posts
    </button>
</div>
</div>
<script>
// Auto-refresh every 5 minutes (300,000 milliseconds)
const AUTO_REFRESH_INTERVAL = 300000;
let refreshInterval;
let currentReportFeedId = null;
let isLoading = false;
let allPostsLoaded = false;
let currentOffset = 0;

document.getElementById('file-upload').addEventListener('change', function(e) {
    const fileName = e.target.files[0] ? e.target.files[0].name : 'No file chosen';
    document.getElementById('file-name').textContent = fileName;
});

function fetchFeeds(initialLoad = true) {
    if (isLoading || (allPostsLoaded && !initialLoad)) return;
    
    isLoading = true;
    if (initialLoad) {
        currentOffset = 0;
        allPostsLoaded = false;
        document.getElementById('feedContainer').innerHTML = '';
    }
    
        const url = `feed.php?action=fetch&offset=${currentOffset}`;
    fetch(url)
        .then(res => res.text())
        .then(html => {
            if (html === "no_more_posts") {
                allPostsLoaded = true;
            } else if (html) {
                if (initialLoad) {
                    document.getElementById('feedContainer').innerHTML = html;
                } else {
                    document.getElementById('feedContainer').insertAdjacentHTML('beforeend', html);
                }
                
                // Load comments for each new feed
                document.querySelectorAll('.feed-card').forEach(feed => {
                    const feedId = feed.id.split('-')[1];
                    if (feedId) loadComments(feedId);
                });
                
                currentOffset += 5;
            } else if (initialLoad) {
                document.getElementById('feedContainer').innerHTML = '<div class="no-posts">No posts found. Be the first to post!</div>';
            }
            
            isLoading = false;
            // Restart auto-refresh timer
            startAutoRefresh();
        })
        .catch(error => {
            console.error('Error loading feeds:', error);
            isLoading = false;
        });
}

// Scroll event for lazy loading
window.addEventListener('scroll', function() {
    if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 500 && !isLoading && !allPostsLoaded) {
        fetchFeeds(false);
    }
});

function loadComments(feedId, showAll = false) {
    const url = showAll ? `feed.php?action=get_comments&feed_id=${feedId}&all=1` : `feed.php?action=get_comments&feed_id=${feedId}`;
    fetch(url)
        .then(res => res.text())
        .then(html => {
            const container = document.getElementById(`comments-${feedId}`);
            if (container) {
                container.innerHTML = html;
            }
        });
}

function loadAllComments(feedId, element) {
    loadComments(feedId, true);
    element.remove();
}

function loadReplies(commentId) {
    fetch(`feed.php?action=get_replies&comment_id=${commentId}`)
        .then(res => res.text())
        .then(html => {
            const container = document.getElementById(`replies-${commentId}`);
            if (container) {
                container.innerHTML = html;
            }
        })
        .catch(error => console.error('Error loading replies:', error));
}

function toggleReplies(commentId, button) {
    const repliesContainer = document.getElementById(`replies-${commentId}`);
    
    if (repliesContainer.style.display === 'block') {
        repliesContainer.style.display = 'none';
        button.textContent = `▼ Replies (${button.textContent.match(/\d+/)[0]})`;
    } else {
        // Load replies if not already loaded
        if (repliesContainer.innerHTML === '') {
            loadReplies(commentId);
        }
        repliesContainer.style.display = 'block';
        button.textContent = `▲ Hide Replies`;
    }
}

function toggleReplyForm(commentId) {
    const form = document.getElementById(`reply-form-${commentId}`);
    
    if (form.style.display === 'flex') {
        form.style.display = 'none';
    } else {
        form.style.display = 'flex';
        // Focus the input field
        const input = document.getElementById(`reply-input-${commentId}`);
        if (input) input.focus();
    }
}

function setFilter(filter) {
    fetch(`feed.php?filter=${filter}`)
        .then(() => {
            // Update active button state
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            document.querySelector(`.filter-btn[onclick="setFilter('${filter}')"]`).classList.add('active');
            
            fetchFeeds();
        });
}

function searchPosts() {
    const searchTerm = document.getElementById('searchInput').value.trim();
    if (searchTerm) {
        fetch(`feed.php?search=${encodeURIComponent(searchTerm)}`)
            .then(() => {
                fetchFeeds();
            });
    }
}

function clearSearch() {
    fetch('feed.php?clear_search=1')
        .then(() => {
            document.getElementById('searchInput').value = '';
            fetchFeeds();
        });
}

function startAutoRefresh() {
    // Clear existing interval if any
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    // Start new interval
    refreshInterval = setInterval(fetchFeeds, AUTO_REFRESH_INTERVAL);
}

function showReportModal(feedId) {
    currentReportFeedId = feedId;
    document.getElementById('reportModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('reportModal').style.display = 'none';
    document.getElementById('reportReason').value = '';
    currentReportFeedId = null;
}

function submitReport() {
    const reason = document.getElementById('reportReason').value.trim();
    if (!reason) {
        alert('Please enter a reason for reporting this post.');
        return;
    }

    if (currentReportFeedId) {
        fetch('feed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=report&feed_id=${currentReportFeedId}&reason=${encodeURIComponent(reason)}`
        }).then(() => {
            alert("Thank you for your report. We'll review this content.");
            closeModal();
        });
    }
}

document.getElementById('uploadForm').onsubmit = function(e) {
    e.preventDefault();
    let formData = new FormData(this);
    fetch('feed.php', { method: 'POST', body: formData })
        .then(() => { 
            this.reset(); 
            document.getElementById('file-name').textContent = 'No file chosen';
            fetchFeeds(); 
        });
};

function likePost(id, element) {
    fetch('feed.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `action=like&feed_id=${id}`
    }).then(() => {
        // Update like count without reload
        const countSpan = element.querySelector('.count');
        let count = parseInt(countSpan.textContent);
        
        if (element.classList.contains('liked')) {
            element.classList.remove('liked');
            element.innerHTML = '🤍 Like <span class="count">' + (count - 1) + '</span>';
        } else {
            element.classList.add('liked');
            element.innerHTML = '❤️ Liked <span class="count">' + (count + 1) + '</span>';
        }
    });
}

function deletePost(id) {
    if (confirm("Are you sure you want to delete this post?")) {
        fetch('feed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=delete&feed_id=${id}`
        }).then(() => {
            document.getElementById(`feed-${id}`).remove();
        });
    }
}

function deleteReaction(reactionId, element) {
    if (confirm("Are you sure you want to delete this?")) {
        fetch('feed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=delete_reaction&reaction_id=${reactionId}`
        }).then(() => {
            element.closest('.comment, .reply').remove();
        });
    }
}

function sharePost(id) {
    const shareUrl = window.location.origin + window.location.pathname + '?post=' + id;
    copyToClipboard(shareUrl);
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        alert("Link copied to clipboard!");
    });
}

function addComment(feedId) {
    const input = document.getElementById(`comment-input-${feedId}`);
    const comment = input.value.trim();
    
    if (comment) {
        fetch('feed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=comment&feed_id=${feedId}&comment=${encodeURIComponent(comment)}`
        }).then(res => res.text())
          .then(html => {
            input.value = '';
            const commentsContainer = document.getElementById(`comments-${feedId}`);
            if (commentsContainer) {
                // Prepend the new comment
                commentsContainer.insertAdjacentHTML('afterbegin', html);
                
                // Update comment count
                const viewMoreBtn = commentsContainer.nextElementSibling;
                if (viewMoreBtn && viewMoreBtn.classList.contains('view-more-comments')) {
                    const currentCount = parseInt(viewMoreBtn.textContent.match(/\d+/)[0]);
                    viewMoreBtn.textContent = viewMoreBtn.textContent.replace(currentCount, currentCount + 1);
                }
            }
        });
    }
}

function addReply(commentId) {
    const input = document.getElementById(`reply-input-${commentId}`);
    const reply = input.value.trim();
    
    if (reply) {
        fetch('feed.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `action=reply&comment_id=${commentId}&reply=${encodeURIComponent(reply)}`
        }).then(res => res.text())
          .then(html => {
            input.value = '';
            
            // Find or create replies container
            let repliesContainer = document.getElementById(`replies-${commentId}`);
            if (!repliesContainer) {
                // Create replies container if it doesn't exist
                const commentElement = document.getElementById(`comment-${commentId}`);
                if (commentElement) {
                    const commentContent = commentElement.querySelector('.comment-content');
                    if (commentContent) {
                        commentContent.insertAdjacentHTML('beforeend', '<div class="replies-list" id="replies-' + commentId + '"></div>');
                        repliesContainer = document.getElementById(`replies-${commentId}`);
                    }
                }
            }
            
            if (repliesContainer) {
                // Append the new reply
                repliesContainer.insertAdjacentHTML('beforeend', html);
                repliesContainer.style.display = 'block';
                
                // Update reply count in the toggle button
                const toggleBtn = document.querySelector(`#comment-${commentId} .toggle-replies-btn`);
                if (toggleBtn) {
                    const currentCount = parseInt(toggleBtn.textContent.match(/\d+/)[0]);
                    toggleBtn.textContent = toggleBtn.textContent.replace(currentCount, currentCount + 1);
                }
            }
        });
    }
}

// Handle comment submission on Enter key
document.addEventListener('keypress', function(e) {
    if (e.target.classList.contains('comment-input') && e.key === 'Enter') {
        const feedId = e.target.id.split('-')[2];
        addComment(feedId);
    }
    
    if (e.target.classList.contains('reply-input') && e.key === 'Enter') {
        const commentId = e.target.id.split('-')[2];
        addReply(commentId);
    }
});

// Initialize
window.onload = function() {
    fetchFeeds();
    
    // Check if we're viewing a shared post
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('post')) {
        // Already handled by PHP, but we can scroll to it
        setTimeout(() => {
            const postId = urlParams.get('post');
            const postElement = document.getElementById(`feed-${postId}`);
            if (postElement) {
                postElement.scrollIntoView({ behavior: 'smooth' });
            }
        }, 500);
    }
};
</script>

</body>
</html>