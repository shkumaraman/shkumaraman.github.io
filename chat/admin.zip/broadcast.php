<?php
session_start();
include 'db.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Function to make URLs clickable
function makeLinksClickable($text) {
    $pattern = '/(https?:\/\/[^\s]+)/';
    $replacement = '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>';
    return preg_replace($pattern, $replacement, $text);
}

// Fetch all broadcast messages
$stmt = $conn->prepare("SELECT * FROM broadcast ORDER BY created_at ASC");
$stmt->execute();
$messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Broadcast Messages</title>
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
        }

        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            margin: 0;
            padding: 0;
        }
        
         .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            background-color: var(--card-bg);
            color: var(--text-dark);
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        .header h4 {
            font-weight: 600;
            font-size: 18px;
            margin: 0;
        }

        .chat-container {
            max-width: 600px;
            margin: 10px auto 10px;
            height: 100vh;
            position: relative;
        }

        .broadcast-box {
            padding: 70px 15px 20px;
            overflow-y: auto;
            height: calc(100vh - 70px);
        }

        .broadcast-message {
            max-width: 75%;
            margin-bottom: 15px;
            padding: 10px 15px;
            border-radius: 18px;
            word-wrap: break-word;
            position: relative;
            background: #f1f1f1;
        }

        /* Dynamic width based on content */
        .broadcast-message.short {
            max-width: 40%;
        }

        .broadcast-message.medium {
            max-width: 60%;
        }

        .time-stamp {
            font-size: 0.7rem;
            color: #666;
            margin-top: 5px;
            text-align: right;
        }

        .media-container {
            margin-top: 10px;
            width: 100%;
            border-radius: 10px;
            overflow: hidden;
        }

        .media-container video, .media-container audio {
            width: 100%;
            outline: none;
        }

        .file-download {
            display: block;
            margin-top: 8px;
            color: var(--primary-color);
            text-decoration: none;
            font-size: 0.8rem;
            text-align: center;
            padding: 5px;
            border: 1px solid var(--primary-color);
            border-radius: 5px;
        }

        .file-download:hover {
            background-color: rgba(0, 149, 246, 0.1);
        }

        .file-info {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 8px;
        }

        .file-icon {
            margin-right: 8px;
            color: var(--primary-color);
        }

        .uploaded-img {
            max-width: 100%;
            border-radius: 10px;
            margin-top: 5px;
        }

        /* Style for clickable links in messages */
        .broadcast-message a {
            color: var(--primary-color);
            text-decoration: underline;
            word-break: break-all;
        }
    </style>
</head>
<body>
<!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Broadcast</h4>
        <div style="width: 40px;"></div> <!-- Empty div for spacing -->
    </div>
    <div class="chat-container">
        <!-- Messages Box -->
        <div class="broadcast-box" id="broadcast-box">
            <?php foreach ($messages as $message): 
                // Determine message width class based on content length
                $length = strlen($message['message']);
                $widthClass = 'long';
                if ($length < 30) $widthClass = 'short';
                elseif ($length < 100) $widthClass = 'medium';
                
                // Process message to make URLs clickable
                $messageText = makeLinksClickable(htmlspecialchars($message['message']));
            ?>
                <div class="broadcast-message <?= $widthClass ?>">
                    <p><?= nl2br($messageText) ?></p>
                    
                    <?php if ($message['file_url']): ?>
                        <div class="media-container">
                            <?php if (strpos($message['file_type'], 'video') !== false): ?>
                                <video controls>
                                    <source src="<?= htmlspecialchars($message['file_url']) ?>" type="<?= htmlspecialchars($message['file_type']) ?>">
                                    Your browser doesn't support HTML5 video.
                                </video>
                            <?php elseif (strpos($message['file_type'], 'audio') !== false): ?>
                                <audio controls>
                                    <source src="<?= htmlspecialchars($message['file_url']) ?>" type="<?= htmlspecialchars($message['file_type']) ?>">
                                    Your browser doesn't support HTML5 audio.
                                </audio>
                            <?php elseif (strpos($message['file_type'], 'image') !== false): ?>
                                <img src="<?= htmlspecialchars($message['file_url']) ?>" class="uploaded-img">
                            <?php endif; ?>
                            
                            <a href="<?= htmlspecialchars($message['file_url']) ?>" class="file-download" download>
                                <div class="file-info">
                                    <?php if (strpos($message['file_type'], 'video') !== false): ?>
                                        <i class="fas fa-file-video file-icon"></i>
                                        Download Video
                                    <?php elseif (strpos($message['file_type'], 'audio') !== false): ?>
                                        <i class="fas fa-file-audio file-icon"></i>
                                        Download Audio
                                    <?php elseif (strpos($message['file_type'], 'image') !== false): ?>
                                        <i class="fas fa-file-image file-icon"></i>
                                        Download Image
                                    <?php else: ?>
                                        <i class="fas fa-file-download file-icon"></i>
                                        Download File
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="time-stamp">
                        <?= date('h:i A | d M', strtotime($message['created_at'])) ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        window.onload = function() {
            const box = document.getElementById('broadcast-box');
            box.scrollTop = box.scrollHeight;
        };
    </script>
</body>
</html>