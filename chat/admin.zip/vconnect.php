<?php
require 'db.php';
session_start();

if (empty($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    exit("Unauthorized access");
}

$user_id = (int)$_SESSION['user_id'];
$action = $_POST['action'] ?? '';
$room_id = (int)($_POST['room_id'] ?? 0);

if (!$room_id) {
    header('HTTP/1.1 400 Bad Request');
    exit("Invalid room ID");
}

// Start transaction
$conn->begin_transaction();

try {
    // Check premium status and daily limits (unchanged from your code)
    $premium_stmt = $conn->prepare("SELECT premium FROM users WHERE id = ?");
    $premium_stmt->bind_param("i", $user_id);
    $premium_stmt->execute();
    $is_premium = $premium_stmt->get_result()->fetch_row()[0] ?? 0;
    $premium_stmt->close();

    if ($action === 'join' && $is_premium == 0) {
        $limit_stmt = $conn->prepare("SELECT vroom_limit FROM settings LIMIT 1");
        $limit_stmt->execute();
        $daily_limit = $limit_stmt->get_result()->fetch_row()[0] ?? 3;
        $limit_stmt->close();

        $count_stmt = $conn->prepare("SELECT COUNT(*) FROM voice_joins 
                                    WHERE user_id = ? AND DATE(join_time) = CURDATE()");
        $count_stmt->bind_param("i", $user_id);
        $count_stmt->execute();
        $join_count = $count_stmt->get_result()->fetch_row()[0];
        $count_stmt->close();

        if ($join_count >= $daily_limit) {
            header('HTTP/1.1 403 Forbidden');
            exit("Daily limit exceeded");
        }
    }

    // Fetch room with lock
    $stmt = $conn->prepare("SELECT * FROM voice WHERE id = ? FOR UPDATE");
    $stmt->bind_param("i", $room_id);
    $stmt->execute();
    $room = $stmt->get_result()->fetch_assoc();
    
    if (!$room) {
        header('HTTP/1.1 404 Not Found');
        exit("Room not found");
    }

    $is_host = ($room['host_user_id'] == $user_id);

    if ($action === 'join') {
        // Handle non-host joining
        if (!$is_host) {
            $is_full = true;
            foreach (['user1_id', 'user2_id', 'user3_id'] as $slot) {
                if (empty($room[$slot])) {
                    $is_full = false;
                    $stmt = $conn->prepare("UPDATE voice SET $slot = ? WHERE id = ?");
                    $stmt->bind_param("ii", $user_id, $room_id);
                    $stmt->execute();
                    
                    // Record the join
                    $join_stmt = $conn->prepare("INSERT INTO voice_joins (user_id, room_id) VALUES (?, ?)");
                    $join_stmt->bind_param("ii", $user_id, $room_id);
                    $join_stmt->execute();
                    $join_stmt->close();
                    break;
                }
            }
            
            if ($is_full) {
                header('HTTP/1.1 403 Forbidden');
                exit("Room is full");
            }
        }

    } elseif ($action === 'leave') {
        // Handle participant leaving
        if (!$is_host) {
            foreach (['user1_id', 'user2_id', 'user3_id'] as $slot) {
                if ($room[$slot] == $user_id) {
                    $stmt = $conn->prepare("UPDATE voice SET $slot = NULL WHERE id = ?");
                    $stmt->bind_param("i", $room_id);
                    $stmt->execute();
                    break;
                }
            }
        }

    } elseif ($action === 'kick' && $is_host) {
        $kick_user_id = (int)($_POST['user_id'] ?? 0);

        if ($kick_user_id === $user_id) {
            header('HTTP/1.1 400 Bad Request');
            exit("Cannot kick yourself");
        }

        // Find and remove kicked user
        $kicked = false;
        foreach (['user1_id', 'user2_id', 'user3_id'] as $slot) {
            if ($room[$slot] == $kick_user_id) {
                $stmt = $conn->prepare("UPDATE voice SET $slot = NULL WHERE id = ?");
                $stmt->bind_param("i", $room_id);
                $stmt->execute();
                $kicked = true;
                break;
            }
        }

        if (!$kicked) {
            header('HTTP/1.1 404 Not Found');
            exit("User not found in room");
        }
    }

    $conn->commit();
    echo "OK";

} catch (Exception $e) {
    $conn->rollback();
    header('HTTP/1.1 500 Internal Server Error');
    exit("Database error");
}
?>