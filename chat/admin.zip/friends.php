<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Update active_status to 1 when the user visits the page (only if it's not 2 or 3)
$sql_update_status = "UPDATE users SET active_status = 1 WHERE id = ? AND active_status NOT IN (2, 3)";
$stmt_update_status = $conn->prepare($sql_update_status);
$stmt_update_status->bind_param("i", $user_id);
$stmt_update_status->execute();

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch latest broadcast message
$sql_broadcast = "SELECT message FROM broadcast ORDER BY created_at DESC LIMIT 1";
$stmt_broadcast = $conn->prepare($sql_broadcast);
$stmt_broadcast->execute();
$result_broadcast = $stmt_broadcast->get_result();
$latest_broadcast = "No broadcasts yet";
if ($result_broadcast->num_rows > 0) {
    $broadcast_row = $result_broadcast->fetch_assoc();
    $latest_broadcast = htmlspecialchars($broadcast_row['message']);
}

// Fetch friends with latest message
$sql = "SELECT u.id, u.username, u.profile_pic, u.verified, u.active_status, 
       (SELECT message FROM inbox WHERE (sender_id = u.id AND receiver_id = ?) 
        OR (sender_id = ? AND receiver_id = u.id) 
        ORDER BY created_at DESC LIMIT 1) AS last_message
FROM users u
JOIN friend_requests fr 
    ON (fr.sender_id = u.id OR fr.receiver_id = u.id)
    AND fr.status = 'accepted'
WHERE (fr.sender_id = ? OR fr.receiver_id = ?) 
AND u.id != ?
AND u.username LIKE ?
ORDER BY (SELECT created_at FROM inbox WHERE (sender_id = u.id AND receiver_id = ?) 
        OR (sender_id = ? AND receiver_id = u.id) 
        ORDER BY created_at DESC LIMIT 1) DESC";

$stmt = $conn->prepare($sql);
$searchTerm = "%$search%";
$stmt->bind_param("iiiiisis", $user_id, $user_id, $user_id, $user_id, $user_id, $searchTerm, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Friends</title>
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --online-color: #4CAF50;
            --offline-color: #e0e0e0;
        }

        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        /* Header Styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            background-color: var(--card-bg);
            color: var(--text-dark);
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        .header h4 {
            font-weight: 600;
            font-size: 18px;
            margin: 0;
        }

        /* Search Bar */
        .search-container {
            margin-top: 60px;
            padding: 15px;
            background-color: var(--card-bg);
            position: sticky;
            top: 60px;
            z-index: 900;
            border-bottom: 1px solid var(--border-color);
        }

        #searchInput {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 14px;
            background-color: var(--bg-color);
            transition: all 0.3s;
        }

        #searchInput:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 2px rgba(0, 149, 246, 0.1);
        }

        /* Friend List */
        .friend-list {
            padding: 0;
            margin: 0;
        }

        .friend-item {
            display: flex;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-color);
            background-color: var(--card-bg);
            transition: all 0.3s;
        }

        .friend-item:hover {
            background-color: rgba(0, 149, 246, 0.05);
        }

        /* Profile Picture with Status */
        .profile-pic-container {
            position: relative;
            width: 56px;
            height: 56px;
            margin-right: 15px;
        }

        .profile-pic {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--border-color);
        }

        .status-indicator {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            border: 2px solid var(--card-bg);
        }

        .status-online {
            background-color: var(--online-color);
        }

        .status-offline {
            background-color: var(--offline-color);
        }

        /* Friend Info */
        .friend-info {
            flex-grow: 1;
        }

        .friend-name {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 3px;
            display: flex;
            align-items: center;        
            max-width: 150px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: inline-block;
  vertical-align: middle
        }

        .verified-badge {
            width: 16px;
            height: 16px;
            margin-left: 5px;
        }

        .last-message {
            font-size: 13px;
            color: var(--text-light);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            max-width: 200px;
        }

        /* Action Icons */
        .action-icons {
            display: flex;
            gap: 15px;
        }

        .action-icons a {
            color: var(--text-light);
            font-size: 18px;
            transition: all 0.3s;
        }

        .action-icons a:hover {
            color: var(--primary-color);
            transform: scale(1.1);
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }

        .empty-state i {
            font-size: 40px;
            margin-bottom: 15px;
            color: var(--border-color);
        }

        /* Responsive Adjustments */
        @media (max-width: 576px) {
            .profile-pic-container {
                width: 48px;
                height: 48px;
            }
            
            .friend-item {
                padding: 10px 12px;
            }
            
            .action-icons {
                gap: 12px;
            }
        }
        
        .talkrush-item {
            background-color: #f8f9fa;
            border-left: 4px solid #4361ee;
        }
        
        .talkrush-item .friend-name {
            color: #4361ee;
            font-weight: 700;
        }
    </style>
</head>
<body>

<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4>Friends</h4>
    <div style="width: 40px;"></div> <!-- Empty div for spacing -->
</div>

<!-- Search Input Field -->
<div class="search-container">
    <input type="text" id="searchInput" placeholder="🔍 Search friends...">
</div>

<div class="friend-list">

<!-- Add TalkRush Broadcast as first item -->
<div class="friend-item talkrush-item">
    <div class="profile-pic-container">
        <img src="assets/logo.png" class="profile-pic" alt="TalkRush">
        <div class="status-indicator status-online"></div>
    </div>
    
    <div class="friend-info">
        <div class="friend-name">
            TalkRush
            <img src="assets/verified.png" class="verified-badge" alt="Verified">
        </div>
        <div class="last-message" title="<?= $latest_broadcast ?>">
            <?= $latest_broadcast ?>
        </div>
    </div>
    
    <div class="action-icons">
        <a href="broadcast.php" title="View Broadcasts">
            <i class="fas fa-bullhorn"></i>
        </a>
    </div>
</div>

    <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="friend-item">
                <!-- Profile Picture with Status Indicator -->
                <div class="profile-pic-container">
                    <img src="<?= htmlspecialchars($row['profile_pic'] ?: 'assets/default_dp.png') ?>" class="profile-pic" alt="Profile Picture">
                    <div class="status-indicator <?= ($row['active_status'] == 1 || $row['active_status'] == 2) ? 'status-online' : 'status-offline' ?>"></div>
                </div>
                
                <!-- Friend Info -->
                <div class="friend-info">
                    <div class="friend-name">
                        <?= htmlspecialchars($row['username']) ?>
                        <?php if ($row['verified'] == 1): ?>
                            <img src="assets/verified.png" class="verified-badge" alt="Verified">
                        <?php endif; ?>
                    </div>
                    <div class="last-message" title="<?= htmlspecialchars($row['last_message'] ?: 'No messages yet') ?>">
                        <?= htmlspecialchars($row['last_message'] ?: 'No messages yet') ?>
                    </div>
                </div>
                
                <!-- Action Icons -->
                <div class="action-icons">
                    <a href="inbox.php?id=<?= $row['id'] ?>" title="Message">
                        <i class="fas fa-message"></i>
                    </a>
                    <a href="#" class="unfriend-btn" data-id="<?= $row['id'] ?>" title="Unfriend">
                        <i class="fas fa-user-times"></i>
                    </a>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="empty-state">
            <i class="fas fa-user-friends"></i>
            <p>No friends found</p>
        </div>
    <?php endif; ?>
</div>

<!-- SweetAlert2 JS -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.18.0/dist/sweetalert2.all.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function () {
    // Function to update active_status
    function sendHeartbeat(status) {
        $.ajax({
            url: "update_status.php",
            method: "POST",
            data: { status: status },
            success: function (response) {
                console.log("Status updated to", status, "Server Response:", response);
            },
            error: function (xhr, status, error) {
                console.error("Error updating status: " + error);
            }
        });
    }

    // Set status to active (1) when page loads
    sendHeartbeat(1);

    // Handle tab visibility change
    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'hidden') {
            // Tab is hidden - set inactive
            sendHeartbeat(0);
        } else {
            // Tab is visible again - set active
            sendHeartbeat(1);
        }
    });

    // Handle page unload (user closes the tab or navigates away)
    window.addEventListener('beforeunload', function () {
        const formData = new FormData();
        formData.append("status", "0");
        navigator.sendBeacon("update_status.php", formData);
    });

    // Unfriend Button Click Event
    document.querySelectorAll('.unfriend-btn').forEach(function (button) {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const userId = this.getAttribute('data-id');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, unfriend!'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `unfriend.php?id=${userId}`;
                }
            });
        });
    });

    // Search Functionality
    $('#searchInput').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.friend-item').each(function () {
            const username = $(this).find('.friend-name').text().toLowerCase();
            if (username.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
});
</script>
</body>
</html>