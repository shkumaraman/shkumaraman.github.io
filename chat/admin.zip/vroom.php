<?php
require 'db.php';
session_start();

if (empty($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$room_id = (int)($_GET['room_id'] ?? 0);

// 1. STRICT PEER ID VERIFICATION (READ ONLY)
$current_user_peer_id = null;
$peer_check = $conn->prepare("SELECT peer_id FROM status WHERE user_id = ? LIMIT 1");
$peer_check->bind_param("i", $user_id);
$peer_check->execute();
$peer_result = $peer_check->get_result();

if ($peer_result->num_rows > 0) {
    $current_user_peer_id = $peer_result->fetch_assoc()['peer_id'];
}
$peer_check->close();

// If no peer ID found, redirect with debug info
if (empty($current_user_peer_id)) {
    // Log detailed debug information
    error_log("Peer ID missing for user $user_id");
    $debug_info = $conn->query("SELECT * FROM status WHERE user_id = $user_id")->fetch_assoc();
    error_log("Debug info: " . print_r($debug_info, true));
    
    header("Location: vhost.php?error=no_peer_id&user=$user_id&debug=".urlencode(json_encode($debug_info)));
    exit;
}

// 2. PREMIUM AND LIMIT CHECKS (UNCHANGED)
$premiumCheck = $conn->prepare("SELECT premium FROM users WHERE id = ?");
$premiumCheck->bind_param("i", $user_id);
$premiumCheck->execute();
$is_premium = $premiumCheck->get_result()->fetch_assoc()['premium'] ?? 0;
$premiumCheck->close();

$limitCheck = $conn->prepare("SELECT vroom_limit FROM settings LIMIT 1");
$limitCheck->execute();
$daily_limit = $limitCheck->get_result()->fetch_assoc()['vroom_limit'] ?? 3;
$limitCheck->close();

$joinCountCheck = $conn->prepare("SELECT COUNT(*) FROM voice_joins WHERE user_id = ? AND DATE(join_time) = CURDATE()");
$joinCountCheck->bind_param("i", $user_id);
$joinCountCheck->execute();
$join_count = $joinCountCheck->get_result()->fetch_row()[0];
$joinCountCheck->close();

$join_limit_exceeded = ($is_premium != 1 && $join_count >= $daily_limit);

// 3. ROOM ACCESS VERIFICATION
$stmt = $conn->prepare("SELECT host_user_id FROM voice WHERE id = ?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$host_user_id = $stmt->get_result()->fetch_row()[0] ?? 0;
$stmt->close();

if ($join_limit_exceeded && $user_id != $host_user_id) {
    header("Location: vhost.php?error=limit_exceeded&limit=$daily_limit");
    exit;
}

// 4. ROOM DATA FETCH
$stmt = $conn->prepare("SELECT * FROM voice WHERE id = ?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();
if (!$room) die("Room not found");

$is_host = ($room['host_user_id'] == $user_id);

// 5. GET ALL USER IDs IN ROOM
$user_ids = [$room['host_user_id']];
foreach (['user1_id', 'user2_id', 'user3_id'] as $slot) {
    if (!empty($room[$slot])) {
        $user_ids[] = $room[$slot];
    }
}

// 6. GET PEER IDs (READ ONLY)
$peer_ids = [];
if (!empty($user_ids)) {
    $placeholders = implode(',', array_fill(0, count($user_ids), '?'));
    $types = str_repeat('i', count($user_ids));
    $stmt2 = $conn->prepare("SELECT user_id, peer_id FROM status WHERE user_id IN ($placeholders)");
    $stmt2->bind_param($types, ...$user_ids);
    $stmt2->execute();
    $res = $stmt2->get_result();
    
    while ($row = $res->fetch_assoc()) {
        if (!empty($row['peer_id'])) {
            $peer_ids[] = $row['peer_id'];
        }
    }
    $stmt2->close();
}

// 7. HOST INFO
$host = null;
$stmt3 = $conn->prepare("SELECT id, username, profile_pic, verified FROM users WHERE id = ?");
$stmt3->bind_param("i", $room['host_user_id']);
$stmt3->execute();
$host = $stmt3->get_result()->fetch_assoc();
$stmt3->close();

// 8. FRIEND STATUS CHECK
$is_friend = false;
$request_status = null;
if ($host && $user_id != $host['id']) {
    $stmtF = $conn->prepare("SELECT status FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?) 
        OR (sender_id = ? AND receiver_id = ?)");
    $stmtF->bind_param("iiii", $user_id, $host['id'], $host['id'], $user_id);
    $stmtF->execute();
    $resF = $stmtF->get_result();
    
    if ($row = $resF->fetch_assoc()) {
        $request_status = $row['status'];
        $is_friend = ($request_status === 'accepted');
    }
    $stmtF->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Voice Room</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f5f7fa;
            color: #333;
            height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .header {
            background: linear-gradient(135deg, #6e8efb, #a777e3);
            color: white;
            padding: 15px 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }

        .status {
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .host-profile {
            text-align: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            width: 90%;
            max-width: 300px;
        }

        .host-pic {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid #6e8efb;
            object-fit: cover;
            margin: 0 auto 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .host-info {
            margin-top: 10px;
        }

        .username {
            font-weight: bold;
            font-size: 1.2rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .verified-icon {
            width: 18px;
            height: 18px;
            margin-left: 5px;
        }

        .friend-btn {
            background: #6e8efb;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            margin-top: 15px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }

        .friend-btn:hover {
            background: #5a7df4;
            transform: translateY(-2px);
        }

        .friend-btn:disabled {
            background: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .users-container {
            width: 100%;
            max-width: 800px;
        }

        .users-title {
            font-size: 1.1rem;
            margin-bottom: 15px;
            color: #555;
            text-align: center;
        }

        .users-list {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
        }

        .user-card {
            background: white;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
            text-align: center;
            width: 100px;
            transition: all 0.3s;
        }

        .user-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .user-pic {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto;
            border: 2px solid #ddd;
        }

        .user-name {
            font-size: 0.9rem;
            margin-top: 8px;
            font-weight: 500;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .kick-btn {
            background: #ff4757;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 15px;
            margin-top: 10px;
            font-size: 0.8rem;
            cursor: pointer;
            transition: all 0.2s;
        }

        .kick-btn:hover {
            background: #ff6b81;
        }

        .controls {
            background: white;
            padding: 15px 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 30px;
            box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
            position: sticky;
            bottom: 0;
        }

        .control-btn {
            background: #f1f3f6;
            border: none;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            color: #555;
            font-size: 1.3rem;
        }

        .control-btn:hover {
            background: #e1e5eb;
            transform: scale(1.1);
        }

        .control-btn.active {
            background: #6e8efb;
            color: white;
        }

        .control-btn.end-call {
            background: #ff4757;
            color: white;
        }

        .control-btn.end-call:hover {
            background: #ff6b81;
        }

        .hidden {
            display: none;
        }

        .no-users {
            text-align: center;
            width: 100%;
            color: #777;
            font-style: italic;
        }
        
        .status-message {
    padding: 10px 15px;
    background: #ffebee;
    color: #c62828;
    border-radius: 5px;
    margin: 10px auto;
    text-align: center;
    max-width: 80%;
    transition: all 0.3s ease;
}

.status-message.hidden {
    opacity: 0;
    height: 0;
    padding: 0;
    margin: 0;
    overflow: hidden;
}

.status-message.visible {
    opacity: 1;
    height: auto;
    padding: 10px 15px;
    margin: 10px auto;
}
    </style>
</head>
<body>
    <div class="header">
        <h2>Voice Room #<?= $room_id ?></h2>
        <div class="status"><?= $is_host ? "You are the host" : "Connected as listener" ?></div>
    </div>

    <div class="main-content">
        <!-- Host Profile -->
        <div class="host-profile">
            <?php if ($host): ?>
                <img src="<?= htmlspecialchars($host['profile_pic'] ?: 'assets/default_dp.png') ?>" class="host-pic" alt="Host">
                <div class="host-info">
                    <div class="username">
                        <?= htmlspecialchars($host['username']) ?>
                        <?php if ($host['verified']): ?>
                            <img src="assets/verified.png" class="verified-icon" alt="Verified">
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($user_id != $host['id']): ?>
                        <div>
                            <?php if ($is_friend): ?>
                                <button class="friend-btn" disabled><i class="fas fa-user-friends"></i> Friends</button>
                            <?php elseif ($request_status === 'pending'): ?>
                                <button class="friend-btn" disabled><i class="fas fa-clock"></i> Request Sent</button>
                            <?php else: ?>
                                <button class="friend-btn" id="friend-request-btn" onclick="sendFriendRequest(<?= $host['id'] ?>)">
                                    <i class="fas fa-user-plus"></i> Add Friend
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div id="connection-status" class="status-message hidden"></div>
        
        <!-- Connected Users -->
        <div class="users-container">
            <div class="users-title">Connected Listeners</div>
            <div class="users-list" id="users-list"></div>
        </div>

        <!-- Audio elements (hidden) -->
        <div id="peers" class="hidden"></div>
    </div>

    <!-- Bottom Controls -->
    <div class="controls">
        <button class="control-btn" id="mic-btn" title="Toggle Microphone">
            <i class="fas fa-microphone"></i>
        </button>
        
        <button class="control-btn" id="speaker-btn" title="Toggle Speaker">
            <i class="fas fa-volume-up"></i>
        </button>
        
        <button class="control-btn end-call" id="leave-btn" title="Leave Room">
            <i class="fas fa-phone-slash"></i>
        </button>
    </div>

<script src="https://cdn.jsdelivr.net/npm/peerjs@1.5.4/dist/peerjs.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.17.2/dist/sweetalert2.all.min.js"></script>
<script>
const roomId = <?= $room_id ?>;
const isHost = <?= $is_host ? 'true' : 'false' ?>;
const userId = <?= json_encode($user_id) ?>;
const currentPeerId = <?= json_encode($current_user_peer_id) ?>;
const existingPeers = <?= json_encode($peer_ids) ?>;
const hostUserId = <?= json_encode($room['host_user_id']) ?>;

let localStream;
let isMicOn = true;
let isSpeakerOn = true;
let hasJoined = false;
const activeConnections = {};
const connectionAttempts = {};

const peerConfig = {
    config: {
        'iceServers': [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' },
            { urls: 'stun:stun3.l.google.com:19302' },
            { urls: 'stun:stun4.l.google.com:19302' },
            { 
                urls: 'turn:global.turn.twilio.com:3478?transport=udp',
                username: 'YOUR_TWILIO_USERNAME',
                credential: 'YOUR_TWILIO_CREDENTIAL'
            }
        ],
        iceTransportPolicy: 'all',
        iceCandidatePoolSize: 5
    },
    debug: 2
};

const peer = new Peer(currentPeerId, peerConfig);

const micBtn = document.getElementById('mic-btn');
const speakerBtn = document.getElementById('speaker-btn');
const leaveBtn = document.getElementById('leave-btn');
const connectionStatus = document.getElementById('connection-status');
const usersList = document.getElementById('users-list');

function initializeVoiceChat() {
    if (!currentPeerId) {
        showErrorAndRedirect("System error: Missing peer ID");
        return;
    }
    setupMediaDevices()
        .then(() => setupPeerEventHandlers())
        .catch(handleMediaError);
}

function setupMediaDevices() {
    return navigator.mediaDevices.getUserMedia({
        audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true
        },
        video: false
    }).then(stream => {
        localStream = stream;
        localStream.getAudioTracks()[0].enabled = true;
    });
}

function setupPeerEventHandlers() {
    peer.on('call', call => {
        call.answer(localStream);
        call.on('stream', remoteStream => {
            addAudioElement(call.peer, remoteStream);
            updateConnectionStatus(`Connected`, 'success');
        });
        call.on('close', () => {
            removeAudioElement(call.peer);
            updateConnectionStatus(`Disconnected`, 'warning');
        });
        call.on('error', err => {
            removeAudioElement(call.peer);
            updateConnectionStatus(`Error: ${err.message}`, 'error');
        });
    });

    peer.on('open', id => {
        updateConnectionStatus('Connected', 'success');
        existingPeers.forEach(peerId => {
            if (peerId && peerId !== id) {
                connectWithRetry(peerId);
            }
        });
        registerInRoom();
    });

    peer.on('disconnected', () => {
        updateConnectionStatus('Reconnecting...', 'warning');
        setTimeout(() => peer.reconnect(), 2000);
    });

    peer.on('error', err => {
        let errorMessage = 'Connection error occurred';
        switch(err.type) {
            case 'peer-unavailable':
                errorMessage = 'The other user is unavailable';
                break;
            case 'network':
                errorMessage = 'Network issues detected';
                setTimeout(() => peer.reconnect(), 2000);
                break;
            case 'server-error':
                errorMessage = 'Server connection problem';
                setTimeout(() => peer.reconnect(), 2000);
                break;
            case 'unavailable-id':
                errorMessage = 'Your session appears to be active elsewhere';
                showErrorAndRedirect(errorMessage);
                return;
        }
        updateConnectionStatus(errorMessage, 'error');
    });
}

function connectWithRetry(peerId, attempt = 1) {
    if (activeConnections[peerId] || peerId === peer.id) return;
    if (attempt > 3) return;
    updateConnectionStatus(`Connecting...`, 'info');
    const call = peer.call(peerId, localStream);
    activeConnections[peerId] = call;
    connectionAttempts[peerId] = attempt;
    call.on('stream', remoteStream => {
        addAudioElement(peerId, remoteStream);
        updateConnectionStatus(`Connected`, 'success');
    });
    call.on('close', () => {
        cleanupConnection(peerId);
        updateConnectionStatus(`Disconnected`, 'warning');
    });
    call.on('error', err => {
        cleanupConnection(peerId);
        updateConnectionStatus(`Error`, 'error');
        setTimeout(() => {
            connectWithRetry(peerId, attempt + 1);
        }, 1000 * attempt);
    });
}

function cleanupConnection(peerId) {
    removeAudioElement(peerId);
    delete activeConnections[peerId];
    delete connectionAttempts[peerId];
}

function addAudioElement(peerId, stream) {
    removeAudioElement(peerId);
    const audio = document.createElement('audio');
    audio.srcObject = stream;
    audio.autoplay = true;
    audio.dataset.peer = peerId;
    audio.muted = !isSpeakerOn;
    audio.onerror = () => {
        removeAudioElement(peerId);
    };
    document.getElementById('peers').appendChild(audio);
}

function removeAudioElement(peerId) {
    const audio = document.querySelector(`audio[data-peer="${peerId}"]`);
    if (audio) {
        audio.srcObject = null;
        audio.remove();
    }
}

function registerInRoom() {
    fetch('vconnect.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            action: 'join',
            room_id: roomId
        })
    }).then(response => {
        if (!response.ok) throw new Error('Failed to register in room');
        hasJoined = true;
        startUserListUpdates();
    }).catch(err => {
        showErrorAndRedirect('Failed to join room. Please try again.');
    });
}

function updateConnectionStatus(message, type = 'info') {
    connectionStatus.textContent = message;
    connectionStatus.className = `status-message visible ${type}`;
    setTimeout(() => {
        connectionStatus.classList.remove('visible');
    }, 5000);
}

function showErrorAndRedirect(message) {
    Swal.fire({
        title: 'Connection Error',
        text: message,
        icon: 'error'
    }).then(() => {
        window.location.href = "vhost.php";
    });
}

function startUserListUpdates() {
    fetchUsers();
    setInterval(fetchUsers, 3000);
}

function fetchUsers() {
    fetch(`vusers.php?room_id=${roomId}&user_id=${userId}`)
        .then(res => res.json())
        .then(users => {
            if (Array.isArray(users)) {
                updateUserList(users);
                checkIfKicked(users.map(u => u.id.toString()));
            }
        })
        .catch(console.error);
}

function updateUserList(users) {
    usersList.innerHTML = '';
    if (users.length === 0) {
        usersList.appendChild(createNoUsersMessage());
        return;
    }
    users.forEach(user => {
        usersList.appendChild(createUserCard(user));
    });
}

function checkIfKicked(userIds) {
    if (!isHost && !userIds.includes(userId.toString())) {
        Swal.fire({
            title: 'Removed from Room',
            text: 'You have been removed from the voice room',
            icon: 'info',
            confirmButtonColor: '#6e8efb',
        }).then(() => {
            leaveRoom();
        });
    }
}

function createNoUsersMessage() {
    const msg = document.createElement('div');
    msg.className = 'no-users';
    msg.textContent = 'No listeners connected';
    return msg;
}

function createUserCard(user) {
    const card = document.createElement('div');
    card.className = 'user-card';
    card.dataset.userId = user.id;
    const img = document.createElement('img');
    img.src = user.profile_pic || 'assets/default_dp.png';
    img.className = 'user-pic';
    card.appendChild(img);
    const name = document.createElement('div');
    name.className = 'user-name';
    name.textContent = user.id === userId ? 'You' + (isHost ? ' (Host)' : '') : user.username;
    card.appendChild(name);
    if (user.verified) {
        const verifiedIcon = document.createElement('img');
        verifiedIcon.src = 'assets/verified.png';
        verifiedIcon.className = 'verified-icon';
        name.appendChild(verifiedIcon);
    }
    if (isHost && user.id !== userId) {
        const kickBtn = document.createElement('button');
        kickBtn.className = 'kick-btn';
        kickBtn.innerHTML = '<i class="fas fa-user-times"></i> Kick';
        kickBtn.onclick = () => kickUser(user.id, user.username);
        card.appendChild(kickBtn);
    }
    return card;
}

function toggleMicrophone() {
    isMicOn = !isMicOn;
    if (localStream) {
        localStream.getAudioTracks()[0].enabled = isMicOn;
    }
    micBtn.classList.toggle('active', !isMicOn);
    micBtn.innerHTML = isMicOn 
        ? '<i class="fas fa-microphone"></i>' 
        : '<i class="fas fa-microphone-slash"></i>';
}

function toggleSpeaker() {
    isSpeakerOn = !isSpeakerOn;
    const audios = document.querySelectorAll('#peers audio');
    audios.forEach(audio => {
        audio.muted = !isSpeakerOn;
    });
    speakerBtn.classList.toggle('active', !isSpeakerOn);
    speakerBtn.innerHTML = isSpeakerOn 
        ? '<i class="fas fa-volume-up"></i>' 
        : '<i class="fas fa-volume-mute"></i>';
}

function confirmLeave() {
    Swal.fire({
        title: 'Leave Room?',
        text: 'Are you sure you want to leave this voice room?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#ff4757',
        cancelButtonColor: '#6e8efb',
        confirmButtonText: 'Yes, leave',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            leaveRoom();
        }
    });
}

function leaveRoom() {
    Object.values(activeConnections).forEach(conn => conn.close());
    navigator.sendBeacon('vconnect.php', new URLSearchParams({
        action: 'leave',
        room_id: roomId
    }));
    window.location.href = "vhost.php";
}

function kickUser(userId, username) {
    Swal.fire({
        title: 'Kick User?',
        html: `Are you sure you want to kick <b>${username}</b> from the room?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ff4757',
        cancelButtonColor: '#6e8efb',
        confirmButtonText: 'Yes, kick',
        cancelButtonText: 'Cancel'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('vconnect.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'kick',
                    room_id: roomId,
                    user_id: userId
                })
            }).then(res => {
                if (res.ok) {
                    const card = document.querySelector(`.user-card[data-user-id="${userId}"]`);
                    if (card) card.remove();
                    Swal.fire({
                        title: 'User Kicked',
                        text: `${username} has been removed`,
                        icon: 'success',
                        timer: 1500
                    });
                } else {
                    throw new Error('Kick failed');
                }
            }).catch(err => {
                Swal.fire({
                    title: 'Error',
                    text: 'Failed to kick user',
                    icon: 'error'
                });
            });
        }
    });
}

micBtn.addEventListener('click', toggleMicrophone);
speakerBtn.addEventListener('click', toggleSpeaker);
leaveBtn.addEventListener('click', confirmLeave);

document.addEventListener('DOMContentLoaded', () => {
    updateUserStatus(1);
    initializeVoiceChat();
});

window.addEventListener('beforeunload', () => {
    updateUserStatus(0);
    Object.values(activeConnections).forEach(conn => conn.close());
    navigator.sendBeacon('vconnect.php', new URLSearchParams({
        action: 'leave',
        room_id: roomId
    }));
});

function updateUserStatus(status) {
    fetch('update_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ status: status }),
        keepalive: true
    }).catch(console.error);
}
</script>

</body>
</html>