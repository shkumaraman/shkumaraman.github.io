<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';

// Fetch friend request notifications with search
$sql_requests = "SELECT f.id, u.username, u.profile_pic, f.sender_id, f.created_at 
                 FROM friend_requests f
                 JOIN users u ON f.sender_id = u.id
                 WHERE f.receiver_id = ? AND f.status = 'pending'";
if (!empty($search_term)) {
    $sql_requests .= " AND u.username LIKE ?";
}
$stmt_requests = $conn->prepare($sql_requests);
if (!empty($search_term)) {
    $search_param = "%$search_term%";
    $stmt_requests->bind_param("is", $user_id, $search_param);
} else {
    $stmt_requests->bind_param("i", $user_id);
}
$stmt_requests->execute();
$friend_requests = $stmt_requests->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch admin notifications with search
$sql_admin = "SELECT id, message, created_at FROM notifications 
              WHERE (user_id = ? OR user_id IS NULL)";
if (!empty($search_term)) {
    $sql_admin .= " AND message LIKE ?";
}
$sql_admin .= " ORDER BY created_at DESC";
$stmt_admin = $conn->prepare($sql_admin);
if (!empty($search_term)) {
    $search_param = "%$search_term%";
    $stmt_admin->bind_param("is", $user_id, $search_param);
} else {
    $stmt_admin->bind_param("i", $user_id);
}
$stmt_admin->execute();
$admin_notifications = $stmt_admin->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch story like notifications with search
$sql_likes = "SELECT si.id AS interaction_id, u.username, u.profile_pic, si.interacted_at 
              FROM story_interactions si
              JOIN stories s ON si.group_id = s.group_id
              JOIN users u ON si.user_id = u.id
              WHERE s.user_id = ? AND si.user_id != ? AND si.liked = 1";
if (!empty($search_term)) {
    $sql_likes .= " AND u.username LIKE ?";
}
$sql_likes .= " ORDER BY si.interacted_at DESC";
$stmt_likes = $conn->prepare($sql_likes);
if (!empty($search_term)) {
    $search_param = "%$search_term%";
    $stmt_likes->bind_param("iis", $user_id, $user_id, $search_param);
} else {
    $stmt_likes->bind_param("ii", $user_id, $user_id);
}
$stmt_likes->execute();
$like_notifications = $stmt_likes->get_result()->fetch_all(MYSQLI_ASSOC);

// Fetch post interaction notifications with search
$sql_interactions = "SELECT 
    fr.id, 
    fr.feed_id, 
    fr.reaction_type, 
    fr.content AS comment_text,
    fr.created_at,
    fr.parent_id,
    u.username,
    u.profile_pic,
    u.verified,
    f.text AS post_text,
    f.image AS post_image,
    original_comment.user_id AS original_commenter_id
FROM feed_reactions fr
JOIN users u ON fr.user_id = u.id
JOIN feeds f ON fr.feed_id = f.id
LEFT JOIN feed_reactions original_comment ON fr.parent_id = original_comment.id
WHERE (f.user_id = ? OR original_comment.user_id = ?) AND fr.user_id != ?";
if (!empty($search_term)) {
    $sql_interactions .= " AND (u.username LIKE ? OR fr.content LIKE ? OR f.text LIKE ?)";
}
$sql_interactions .= " ORDER BY fr.created_at DESC";
$stmt_interactions = $conn->prepare($sql_interactions);
if (!empty($search_term)) {
    $search_param = "%$search_term%";
    $stmt_interactions->bind_param("iiisss", $user_id, $user_id, $user_id, 
                                  $search_param, $search_param, $search_param);
} else {
    $stmt_interactions->bind_param("iii", $user_id, $user_id, $user_id);
}
$stmt_interactions->execute();
$post_interactions = $stmt_interactions->get_result()->fetch_all(MYSQLI_ASSOC);

// Delete notification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_notification'])) {
    $notification_id = $_POST['notification_id'];
    $type = $_POST['type'];

    if ($type === 'friend_request') {
        $delete_sql = "DELETE FROM friend_requests WHERE id = ?";
    } elseif ($type === 'admin') {
        $delete_sql = "DELETE FROM notifications WHERE id = ?";
    } else {
        header("Location: notification.php");
        exit();
    }

    $stmt_delete = $conn->prepare($delete_sql);
    $stmt_delete->bind_param("i", $notification_id);
    $stmt_delete->execute();
    header("Location: notification.php");
    exit();
}

// Accept/Decline Friend Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['action'] === 'accept' ? 'accepted' : 'rejected';
    $stmt = $conn->prepare("UPDATE friend_requests SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $request_id);
    $stmt->execute();
    header("Location: notification.php");
    exit();
}

// Merge all notifications into a single array with proper timestamps
$notifications = [];

foreach ($friend_requests as $req) {
    $notifications[] = [
        'type' => 'friend_request',
        'id' => $req['id'],
        'username' => $req['username'],
        'profile_pic' => $req['profile_pic'],
        'timestamp' => $req['created_at'],
        'data' => $req
    ];
}

foreach ($admin_notifications as $note) {
    $notifications[] = [
        'type' => 'admin',
        'id' => $note['id'],
        'message' => $note['message'],
        'timestamp' => $note['created_at'],
        'data' => $note
    ];
}

foreach ($like_notifications as $like) {
    $notifications[] = [
        'type' => 'story_like',
        'id' => $like['interaction_id'],
        'username' => $like['username'],
        'profile_pic' => $like['profile_pic'],
        'timestamp' => $like['interacted_at'],
        'data' => $like
    ];
}

foreach ($post_interactions as $interaction) {
    $notification_type = 'post_' . $interaction['reaction_type'];
    
    if ($interaction['reaction_type'] === 'reply' && $interaction['original_commenter_id'] == $user_id) {
        $notification_type = 'reply_to_comment';
    }
    
    $notifications[] = [
        'type' => $notification_type,
        'id' => $interaction['id'],
        'username' => $interaction['username'],
        'profile_pic' => $interaction['profile_pic'],
        'timestamp' => $interaction['created_at'],
        'feed_id' => $interaction['feed_id'],
        'content' => $interaction['comment_text'],
        'verified' => $interaction['verified'],
        'post_text' => $interaction['post_text'],
        'post_image' => $interaction['post_image'],
        'data' => $interaction
    ];
}

// Sort by timestamp in descending order (newest first)
usort($notifications, function($a, $b) {
    return strtotime($b['timestamp']) <=> strtotime($a['timestamp']);
});

function makeUrlsClickable($text) {
    $pattern = '/(https?:\/\/[^\s]+|www\.[^\s]+)/i';
    return preg_replace($pattern, '<a href="$0" target="_blank">$0</a>', $text);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --bg-color: #ffffff;
            --text-color: #121212;
            --card-bg: #f8f9fa;
            --border-color: #e0e0e0;
            --primary-color: #4361ee;
            --hover-color: #f0f0f0;
        }
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            padding-bottom: 60px;
        }
        .container {
            max-width: 600px;
            margin-top: 60px;
            padding: 0;
            background: white;
        }
        .notification {
            background: white;
            padding: 16px;
            margin: 0;
            border-bottom: 1px solid #dbdbdb;
            position: relative;
            display: flex;
            align-items: flex-start;
            word-break: break-word;
            overflow-wrap: anywhere;
            hyphens: auto;
        }
        .notification-content {
            flex-grow: 1;
            padding-right: 30px;
            min-width: 0;
        }
        .notification p {
            margin: 0;
            color: #262626;
            font-size: 14px;
            line-height: 1.4;
            white-space: pre-wrap;
            word-wrap: break-word;
        }
        .notification strong {
            font-weight: 600;
        }
        .btn-small {
            padding: 5px 10px;
            font-size: 12px;
            font-weight: 600;
            border-radius: 4px;
            margin-top: 8px;
            white-space: nowrap;
        }
        .btn-success {
            background-color: #0095f6;
            border: none;
        }
        .btn-danger {
            background-color: transparent;
            color: #ed4956;
            border: 1px solid #dbdbdb;
        }
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: white;
            color: black;
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
            z-index: 100;
        }
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }
        .back-btn:hover {
            background-color: #f0f0f0;
        }
        .delete-btn {
            position: absolute;
            top: 16px;
            right: 16px;
            border: none;
            background: none;
            color: #8e8e8e;
            font-size: 16px;
            cursor: pointer;
            padding: 0;
        }
        .delete-btn:hover {
            color: #262626;
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #8e8e8e;
        }
        .empty-state i {
            font-size: 40px;
            margin-bottom: 16px;
            color: #dbdbdb;
        }
        .profile-pic {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            border: 1px solid #dbdbdb;
            flex-shrink: 0;
        }
        .admin-icon {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f0f0f0;
            border: 1px solid #dbdbdb;
        }
        h4 {
            font-weight: 600;
            font-size: 16px;
            margin: 0;
        }
        .notification-actions {
            display: flex;
            gap: 8px;
            margin-top: 8px;
            flex-wrap: wrap;
        }
        a {
            color: #0095f6;
            text-decoration: none;
        }
        .notification a {
            word-break: break-all;
        }
        .verified-badge {
            width: 16px;
            height: 16px;
            margin-left: 4px;
            vertical-align: middle;
        }
        .admin-header {
            display: flex;
            align-items: center;
        }
        .admin-header strong {
            margin-left: 6px;
        }
        .view-post-btn {
            display: inline-block;
            margin-top: 8px;
            color: #0095f6;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }
        .post-preview {
            margin-top: 8px;
            padding: 8px;
            background: #fafafa;
            border-radius: 8px;
            border: 1px solid #dbdbdb;
            max-height: 100px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .post-preview img {
            max-width: 100%;
            max-height: 80px;
            object-fit: contain;
            border-radius: 4px;
        }
        .input-group {
            margin-left: 10px;
        }
        .input-group .form-control-sm {
            height: 30px;
            font-size: 12px;
        }
        .input-group .btn-sm {
            height: 30px;
            padding: 0 8px;
            font-size: 12px;
        }
        .search-results-header {
            padding: 12px 16px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #dbdbdb;
            font-size: 14px;
        }
    </style>
</head>
<body>

<!-- Header with Search -->
<div class="header">
    <button class="back-btn" onclick="window.location.href='dashboard.php'">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4>Notifications</h4>
    <form method="GET" action="notification.php" style="display: flex; align-items: center;">
        <div class="input-group" style="width: 150px;">
            <input type="text" name="search" class="form-control form-control-sm" 
                   placeholder="Search..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
            <button class="btn btn-outline-secondary btn-sm" type="submit">
                <i class="fas fa-search"></i>
            </button>
            <?php if(isset($_GET['search'])) : ?>
                <a href="notification.php" class="btn btn-outline-secondary btn-sm">
                    <i class="fas fa-times"></i>
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="container">
    <?php if (!empty($search_term)): ?>
        <div class="search-results-header">
            <strong>Search Results</strong> for "<?= htmlspecialchars($search_term) ?>"
            <small style="color: #8e8e8e;"><?= count($notifications) ?> notification(s) found</small>
        </div>
    <?php endif; ?>

    <?php if (empty($notifications)): ?>
        <div class="empty-state">
            <i class="far fa-bell"></i>
            <p><?= isset($_GET['search']) ? 'No notifications match your search' : 'No new notifications' ?></p>
        </div>
    <?php endif; ?>

    <?php foreach ($notifications as $n): ?>
        <div class="notification">
            <?php if ($n['type'] === 'admin'): ?>
                <div class="admin-icon">
                    <img src="assets/logo.png" alt="Talkrush" style="width: 30px;">
                </div>
            <?php else: ?>
                <img src="<?= !empty($n['profile_pic']) ? htmlspecialchars($n['profile_pic']) : 'assets/default_dp.png' ?>" class="profile-pic" alt="Profile" onerror="this.src='assets/default_dp.png'">
            <?php endif; ?>
            
            <div class="notification-content">
                <?php if ($n['type'] === 'friend_request'): ?>
                    <p><strong><?= htmlspecialchars($n['username']) ?></strong> sent you a friend request.</p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                    <div class="notification-actions">
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= $n['id'] ?>">
                            <button type="submit" name="action" value="accept" class="btn btn-success btn-small">Accept</button>
                        </form>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="request_id" value="<?= $n['id'] ?>">
                            <button type="submit" name="action" value="rejected" class="btn btn-danger btn-small">Reject</button>
                        </form>
                    </div>
                <?php elseif ($n['type'] === 'admin'): ?>
                    <div class="admin-header">
                        <strong>Talkrush</strong>
                        <img src="assets/verified.png" alt="Verified" class="verified-badge">
                    </div>
                    <p><?= makeUrlsClickable(htmlspecialchars($n['message'])) ?></p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                <?php elseif ($n['type'] === 'story_like'): ?>
                    <p><strong><?= htmlspecialchars($n['username']) ?></strong> liked your story.</p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                <?php elseif ($n['type'] === 'post_like'): ?>
                    <p><strong><?= htmlspecialchars($n['username']) ?><?= $n['verified'] ? ' <img src="assets/verified.png" class="verified-badge" alt="Verified">' : '' ?></strong> liked your post.</p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                    <div class="post-preview">
                        <?= htmlspecialchars(mb_substr($n['post_text'], 0, 100)) . (mb_strlen($n['post_text']) > 100 ? '...' : '') ?>
                        <?php if (!empty($n['post_image'])): ?>
                            <img src="<?= htmlspecialchars($n['post_image']) ?>" alt="Post image">
                        <?php endif; ?>
                    </div>
                    <span class="view-post-btn" onclick="window.location.href='feed.php?post=<?= $n['feed_id'] ?>'">View Post</span>
                <?php elseif ($n['type'] === 'post_comment'): ?>
                    <p><strong><?= htmlspecialchars($n['username']) ?><?= $n['verified'] ? ' <img src="assets/verified.png" class="verified-badge" alt="Verified">' : '' ?></strong> commented on your post: "<?= htmlspecialchars(mb_substr($n['content'], 0, 100)) . (mb_strlen($n['content']) > 100 ? '...' : '') ?>"</p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                    <div class="post-preview">
                        <?= htmlspecialchars(mb_substr($n['post_text'], 0, 100)) . (mb_strlen($n['post_text']) > 100 ? '...' : '') ?>
                        <?php if (!empty($n['post_image'])): ?>
                            <img src="<?= htmlspecialchars($n['post_image']) ?>" alt="Post image">
                        <?php endif; ?>
                    </div>
                    <span class="view-post-btn" onclick="window.location.href='feed.php?post=<?= $n['feed_id'] ?>'">View Post</span>
                <?php elseif ($n['type'] === 'post_reply' || $n['type'] === 'reply_to_comment'): ?>
                    <p><strong><?= htmlspecialchars($n['username']) ?><?= $n['verified'] ? ' <img src="assets/verified.png" class="verified-badge" alt="Verified">' : '' ?></strong> replied to your <?= $n['type'] === 'reply_to_comment' ? 'comment' : 'post' ?>: "<?= htmlspecialchars(mb_substr($n['content'], 0, 100)) . (mb_strlen($n['content']) > 100 ? '...' : '') ?>"</p>
                    <small style="color: #8e8e8e; font-size: 12px;"><?= date('M j, Y g:i A', strtotime($n['timestamp'])) ?></small>
                    <div class="post-preview">
                        <?= htmlspecialchars(mb_substr($n['post_text'], 0, 100)) . (mb_strlen($n['post_text']) > 100 ? '...' : '') ?>
                        <?php if (!empty($n['post_image'])): ?>
                            <img src="<?= htmlspecialchars($n['post_image']) ?>" alt="Post image">
                        <?php endif; ?>
                    </div>
                    <span class="view-post-btn" onclick="window.location.href='feed.php?post=<?= $n['feed_id'] ?>'">View Post</span>
                <?php endif; ?>
            </div>
            
            <?php if (!in_array($n['type'], ['story_like', 'post_like', 'post_comment', 'post_reply', 'reply_to_comment'])): ?>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="notification_id" value="<?= $n['id'] ?>">
                    <input type="hidden" name="type" value="<?= $n['type'] ?>">
                    <button type="submit" name="delete_notification" class="delete-btn">&times;</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>