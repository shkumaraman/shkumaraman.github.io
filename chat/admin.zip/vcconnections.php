<?php
session_start();
include "db.php";

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];

    // Check if there's an active call for the user
    $sql = "SELECT * FROM video_calls WHERE (caller_id = ? OR receiver_id = ?) AND end_time IS NULL";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Active call found, check the connected user's status
        $row = $result->fetch_assoc();
        $connected_user = ($row['caller_id'] == $user_id) ? $row['receiver_id'] : $row['caller_id'];

        $status_sql = "SELECT vcstatus FROM status WHERE user_id = ?";
        $status_stmt = $conn->prepare($status_sql);
        $status_stmt->bind_param("i", $connected_user);
        $status_stmt->execute();
        $status_result = $status_stmt->get_result();

        if ($status_result->num_rows > 0) {
            $status_row = $status_result->fetch_assoc();
            if ($status_row['vcstatus'] !== "online") {
                echo "reload"; // Reload if connected user is offline
                exit;
            }
        } else {
            echo "reload"; // Reload if no status found for connected user
            exit;
        }
    } else {
        // Check if the user's call has ended
        $sql_end = "SELECT * FROM video_calls WHERE (caller_id = ? OR receiver_id = ?) AND end_time IS NOT NULL";
        $stmt_end = $conn->prepare($sql_end);
        $stmt_end->bind_param("ii", $user_id, $user_id);
        $stmt_end->execute();
        $result_end = $stmt_end->get_result();

        if ($result_end->num_rows > 0) {
            echo "reload"; // Reload if the call has ended
            exit;
        }
    }
}
?>
