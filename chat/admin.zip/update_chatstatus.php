<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "User not logged in."]);
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle POST request (only status updates now)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['status'])) {
        // Update user status only
        $status = in_array($_POST['status'], ['online', 'offline']) ? $_POST['status'] : 'offline';

        $sql = "UPDATE users SET status = ?, last_activity = NOW() WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", $status, $user_id);

        if ($stmt->execute()) {
            echo json_encode(["status" => "success", "message" => "Status updated."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update status."]);
        }
        $stmt->close();
        exit();
    }
    
    echo json_encode(["status" => "error", "message" => "Invalid request."]);
    exit();
}

// Handle GET request (fetch current status)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['get_status'])) {
    $sql = "SELECT status FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($status);
    $stmt->fetch();
    $stmt->close();

    echo json_encode([
        "status" => "success",
        "data" => [
            "status" => $status ?: 'offline'
        ]
    ]);
    exit();
}

// Handle GET request (fetch Peer ID - read only)
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['get_peer_id'])) {
    $sql = "SELECT peer_id FROM status WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($peer_id);
    $stmt->fetch();
    $stmt->close();

    echo json_encode([
        "status" => "success",
        "data" => [
            "peer_id" => $peer_id ?: null
        ]
    ]);
    exit();
}

echo json_encode(["status" => "error", "message" => "Invalid request."]);
?>