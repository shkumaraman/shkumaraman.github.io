<?php
session_start();
require 'db.php';  // Include the database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['new_password'])) {
    $newPassword = $_POST['new_password'];
    $email = $_SESSION['otp_email'];

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update the user's password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->bind_param("ss", $hashedPassword, $email);

    if ($stmt->execute()) {
        // Clear the OTP and OTP expiry in the database
        $stmt = $conn->prepare("UPDATE users SET otp = NULL, otp_expiry = NULL WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();

        // Clear the session
        session_unset();
        session_destroy();

        echo 'success';
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>