<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch all plans from the database with discount calculation
$current_date = date('Y-m-d');
$sql = "SELECT *, 
        CASE 
            WHEN is_discounted = 1 AND (discount_expiry IS NULL OR discount_expiry >= '$current_date') 
            THEN price * (1 - discounted_price/100) 
            ELSE price 
        END AS final_price
        FROM plans 
        ORDER BY price ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Premium Plans</title>
    <!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --premium-gold: #ffd700;
            --premium-purple: #833ab4;
            --discount-color: #e63946;
            --success-color: #28a745;
        }

        body {
            background-color: #f8f9fa;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
        }

        /* Header Styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            background-color: var(--card-bg);
            color: var(--text-dark);
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }

        .header h4 {
            font-weight: 600;
            font-size: 18px;
            margin: 0;
        }

        /* Main Content */
        .container {
            max-width: 1200px;
            margin-top: 70px;
            padding: 20px;
        }

        .page-title {
            text-align: center;
            margin-bottom: 30px;
            color: var(--text-dark);
            font-weight: 600;
        }

        /* Plan Cards */
        .plan-card {
            border: none;
            border-radius: 16px;
            padding: 25px;
            background: var(--card-bg);
            margin-bottom: 25px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            z-index: 1;
            height: 100%;
            display: flex;
            flex-direction: column;
        }

        .plan-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, #833ab4, #fd1d1d, #fcb045);
        }

        .plan-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.12);
        }

        .plan-card.popular {
            border: 2px solid var(--premium-gold);
        }

        .plan-card.popular::after {
            content: "MOST POPULAR";
            position: absolute;
            top: 10px;
            right: -30px;
            background: var(--premium-gold);
            color: #000;
            padding: 3px 30px;
            font-size: 12px;
            font-weight: bold;
            transform: rotate(45deg);
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .plan-card h3 {
            color: var(--premium-purple);
            font-weight: 700;
            margin-bottom: 15px;
            font-size: 22px;
        }

        .price-container {
            margin-bottom: 15px;
        }

        .original-price {
            font-size: 18px;
            color: var(--text-light);
            text-decoration: line-through;
            margin-right: 8px;
        }

        .final-price {
            font-size: 28px;
            font-weight: 700;
            color: var(--premium-purple);
        }

        .discount-badge {
            background-color: rgba(230, 57, 70, 0.15);
            color: var(--discount-color);
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
            margin-left: 10px;
        }

        .expiry-badge {
            background-color: rgba(230, 57, 70, 0.15);
            color: var(--discount-color);
            padding: 5px 12px;
            border-radius: 50px;
            font-weight: 600;
            display: inline-block;
            margin: 5px 0;
            font-size: 0.8em;
        }

        .plan-card .duration {
            color: var(--text-light);
            margin-bottom: 20px;
        }

        .plan-features {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
            flex-grow: 1;
        }

        .plan-features li {
            padding: 8px 0;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #f0f0f0;
        }

        .plan-features li:last-child {
            border-bottom: none;
        }

        .plan-features li i {
            color: var(--success-color);
            margin-right: 10px;
            font-size: 18px;
        }

        .btn-select {
            background: linear-gradient(45deg, #833ab4, #fd1d1d, #fcb045);
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s;
            box-shadow: 0 4px 10px rgba(131, 58, 180, 0.2);
            margin-top: auto;
        }

        .btn-select:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(131, 58, 180, 0.3);
            color: white;
        }

        /* Ribbon for Discount */
        .ribbon {
            position: absolute;
            top: 15px;
            right: -15px;
            width: 60px;
            height: 60px;
            overflow: hidden;
            z-index: 2;
        }

        .ribbon span {
            position: absolute;
            display: block;
            width: 90px;
            padding: 5px 0;
            background: linear-gradient(45deg, #ff0000, #ff6b6b);
            color: #fff;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            right: -5px;
            top: 15px;
            transform: rotate(45deg);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }
            
            .plan-card {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4>Premium Plans</h4>
        <div style="width: 40px;"></div> <!-- Empty div for spacing -->
    </div>

    <div class="container">
        <h1 class="page-title">Upgrade Your Experience</h1>
        
        <div class="row">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): 
                    $has_discount = $row['is_discounted'] && (!$row['discount_expiry'] || $row['discount_expiry'] >= $current_date);
                    $discount_percent = $row['discounted_price'];
                    $original_price = $row['price'];
                    $final_price = $row['final_price'];
                ?>
                    <div class="col-md-4">
                        <div class="plan-card">
                            <?php if ($has_discount): ?>
                                <div class="ribbon">
                                    <span>SAVE <?= $discount_percent ?>%</span>
                                </div>
                            <?php endif; ?>
                            
                            <h3><?= htmlspecialchars($row['name']) ?></h3>
                            
                            <div class="price-container">
                                <?php if ($has_discount): ?>
                                    <span class="original-price">₹<?= number_format($original_price, 2) ?></span>
                                <?php endif; ?>
                                <span class="final-price">₹<?= number_format($final_price, 2) ?></span>
                                <?php if ($has_discount): ?>
                                    <span class="discount-badge"><?= $discount_percent ?>% OFF</span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($has_discount && $row['discount_expiry']): ?>
                                <div class="expiry-badge">
                                    <i class="fas fa-clock me-1"></i>
                                    Offer ends <?= date('M d, Y', strtotime($row['discount_expiry'])) ?>
                                </div>
                            <?php endif; ?>
                            
                            <p class="duration"><?= $row['duration'] ?> days access</p>
                            <p><?= htmlspecialchars($row['description']) ?></p>
                            
                            <ul class="plan-features">
                                <?php
                                $features = explode(",", $row['features']);
                                foreach ($features as $feature): ?>
                                    <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars(trim($feature)) ?></li>
                                <?php endforeach; ?>
                            </ul>
                            
                            <button class="btn btn-select" onclick="window.location.href='payment.php?plan_id=<?= $row['id'] ?>'">
                                Select Plan
                            </button>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12 text-center">
                    <div class="alert alert-info">
                        No premium plans available at the moment. Please check back later.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
<!-- Bootstrap Bundle JS (includes Popper) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>