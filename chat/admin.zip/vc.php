<?php
session_start();

// Redirect to login if user is not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require 'db.php'; // Include your database connection file

$user_id = $_SESSION['user_id'];

// Initialize all variables with default values
$peer_id = null;
$status = null;
$is_sender = false;
$friend_id = null;
$friend_request_id = null;
$row = null;

// Fetch user's peer_id from status table
$sql = "SELECT peer_id FROM status WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$status_data = $result->fetch_assoc();

// Set peer_id from database
$peer_id = $status_data['peer_id'] ?? null;

// Get current user's details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get the connected user from video_calls table
$sql = "SELECT * FROM video_calls WHERE caller_id = ? OR receiver_id = ? ORDER BY start_time DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$call = $result->fetch_assoc();

if ($call) {
    // Find who is the connected person
    $friend_id = ($call['caller_id'] == $user_id) ? $call['receiver_id'] : $call['caller_id'];

    // Check friend request status if friend_id exists
    if ($friend_id) {
        $sql = "SELECT * FROM friend_requests WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiii", $user_id, $friend_id, $friend_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row) {
            $status = $row['status'] ?? null;
            $is_sender = ($row['sender_id'] == $user_id);
            $friend_request_id = $row['id'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stranger Video Call</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
            --online-color: #4CAF50;
            --offline-color: #e0e0e0;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        color: black;
        text-align: center; }
        h2 { margin: 20px 0;
        }
        .video-container { position: relative; width: 100vw; height: 85vh; background: black; margin-top: 60px;}
        #remote-video { width: 100%; height: 100%; object-fit: cover; }
        #local-video {
            position: absolute; top: 10px; right: 10px;
            width: 100px; height: 140px; border-radius: 10px;
            border: 2px solid white; object-fit: cover; background: black;
        }
        .controls {
            position: absolute; bottom: 20px; left: 50%;
            transform: translateX(-50%); background: rgba(0, 0, 0, 0.6);
            padding: 10px 20px; border-radius: 50px; display: flex; gap: 15px;
        }
        button {
            padding: 12px 24px; border: none; border-radius: 50px;
            background: #444; color: white; cursor: pointer;
            display: flex; align-items: center; gap: 8px; font-size: 16px;
        }
        button:hover { background: #555; }
        #end-call-btn { background: #ff4d4d; }
        #skip-btn { background: #4d79ff; }
        .fas { font-size: 18px; }
        /* Header Styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
            width: 100%;
            background-color: var(--card-bg);
            color: var(--text-dark);
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            box-shadow: 0 1px 5px rgba(0,0,0,0.05);
        }

        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        #friend-status-container {
    display: flex;
    gap: 10px;
    margin-left: auto;
}

#send-request-btn, #accept-btn {
    padding: 8px 16px; /* Reduced padding from 12px 24px */
    border-radius: 8px; /* Reduced border radius from 50px */
    font-size: 14px; /* Slightly smaller font */
    height: 36px; /* Fixed height for consistency */
    display: flex;
    align-items: center;
    justify-content: center;
    white-space: nowrap; /* Prevent text wrapping */
}

#send-request-btn {
    background-color: var(--primary-color);
}

#accept-btn {
    background-color: #4CAF50; /* Green color for accept button */
}

#send-request-btn:hover {
    background-color: #0077cc; /* Darker blue on hover */
}

#accept-btn:hover {
    background-color: #3e8e41; /* Darker green on hover */
}
    </style>
</head>
<body>
<div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <img id="receiver-pic" src="assets/default_dp.png" alt="User" 
         style="width: 40px; height: 40px; border-radius: 50%; border: 2px solid white;">
    <span id="receiver-name" style="font-size: 16px; margin-left: 10px; color: black;">No user connected</span>
    <img id="receiver-verified" src="assets/verified.png" alt="Verified" 
         style="width: 16px; height: 16px; margin-left: 5px; vertical-align: middle; display: none;">
    
    <!-- Friend request status and send/accept buttons -->
<div id="friend-status-container">
        <button id="send-request-btn" style="display: none;" 
                onclick="sendFriendRequest(<?php echo isset($friend_id) ? $friend_id : 'null'; ?>)">
            Send Request
        </button>
        <button id="accept-btn" style="display: none;" 
                onclick="acceptFriendRequest(<?php echo isset($friend_request_id) ? $friend_request_id : 'null'; ?>)">
            Accept Request
        </button>
    </div>
</div>

    <div class="video-container">
        <video id="remote-video" autoplay playsinline></video>
        <video id="local-video" autoplay muted playsinline></video>
    </div>

<div id="loading-overlay" style="
    position: fixed;
    top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(0, 0, 0, 0.8); color: white;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    font-size: 20px; font-weight: bold;
    z-index: 999; display: none;">
    
    <img src="assets/logo.png" alt="Loading..." style="padding: 10px; border-radius: 10px; background-color: #fff; width: 80px; height: 80px; margin-bottom: 10px;">
    Connecting to a stranger...
</div>

    <div class="controls">
    <button id="mute-btn" style="margin-left: 0;">
        <i class="fas fa-microphone"></i> Mute
    </button>
    <button id="skip-btn">
        <i class="fas fa-forward"></i> Skip
    </button>
</div>
<script src="https://cdn.jsdelivr.net/npm/peerjs@latest/dist/peerjs.min.js"></script>
<script src="https://code.jquery.com/jquery-latest.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.18.0/dist/sweetalert2.all.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>

 <script>
// Global variables
var peer = null;
var currentCall = null;
var localStream = null;
var peerIdFromDB = <?php echo json_encode($peer_id); ?>;
var friendStatus = <?php echo isset($status) ? json_encode($status) : 'null'; ?>;
var isSender = <?php echo isset($is_sender) ? json_encode($is_sender) : 'false'; ?>;
var friendRequestId = <?php echo isset($friend_request_id) ? json_encode($friend_request_id) : 'null'; ?>;
var isMuted = false;
var shouldCheckConnection = true;
var controller = null;
var skipInProgress = false; // New flag to track skip status

// Initialize PeerJS
function initializePeer() {
    const peerConfig = {
        config: {
            'iceServers': [
                { url: 'stun:stun.l.google.com:19302' },
                { url: 'stun:stun1.l.google.com:19302' },
                { url: 'stun:stun2.l.google.com:19302' }
            ]
        }
    };

    if (peerIdFromDB) {
        peer = new Peer(peerIdFromDB, peerConfig);
        console.log("Using existing Peer ID from database:", peerIdFromDB);
    } else {
        console.error("No peer_id found in database");
        Swal.fire({
            icon: 'error',
            title: 'Connection Error',
            text: 'Unable to establish connection. Please try again later.',
            confirmButtonColor: '#d33',
        }).then(() => {
            window.location.href = 'index.php';
        });
        return;
    }

    peer.on("open", function () {
        console.log("Peer connection opened with ID:", peer.id);
        updateStatus("online");
    });

    peer.on("call", function(call) {
        shouldCheckConnection = false;
        answerCall(call);
    });

    peer.on("disconnected", function () {
        console.log("Peer Disconnected. Reconnecting...");
        showLoading();
        setTimeout(() => {
            peer.reconnect();
        }, 2000);
    });

    peer.on("close", function() {
        console.log("Connection closed. Reinitializing...");
        showLoading();
        setTimeout(initializePeer, 3000);
    });

    peer.on("error", function (err) {
        console.error("PeerJS Error:", err);
        if (err.type === 'disconnected') {
            console.log("Attempting to reconnect...");
            showLoading();
            setTimeout(initializePeer, 3000);
        } else if (err.type === 'peer-unavailable') {
            if (!skipInProgress) {
                Swal.fire({
                    icon: 'error',
                    title: 'User Unavailable',
                    text: 'The user you are trying to connect with is not available.',
                    confirmButtonColor: '#d33',
                }).then(() => {
                    handleSkip();
                });
            }
        }
    });
}

// Get User Media (Camera & Mic)
function getUserMediaStream(callback) {
    navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
            localStream = stream;
            document.getElementById("local-video").srcObject = stream;
            if (callback) callback(stream);
        })
        .catch(err => {
            console.error("Error accessing camera:", err);
            if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                Swal.fire({
                    icon: 'error',
                    title: 'Camera/Mic Access Denied',
                    text: 'Please enable camera and microphone access to use this feature.',
                    confirmButtonColor: '#d33',
                });
            }
        });
}

// Show Loading
function showLoading() {
    document.getElementById("loading-overlay").style.display = "flex";
}

// Hide Loading
function hideLoading() {
    document.getElementById("loading-overlay").style.display = "none";
}

// Fetch Stranger Details
function fetchStrangerDetails() {
    console.log("Fetching data...");
    showLoading();

    fetch("vcconnect.php")
        .then(response => response.json())
        .then(data => {
            hideLoading();
            console.log("Received Data:", data);

            if (data.error) {
                console.error("Error:", data.error);
                Swal.fire({
                    icon: "error",
                    title: "No Match Found!",
                    text: "No stranger is available at the moment. Please try again later.",
                    confirmButtonColor: "#d33",
                });

                document.getElementById("receiver-name").innerText = "No user connected";
                document.getElementById("receiver-pic").src = "assets/default_dp.png";
                document.getElementById("receiver-verified").style.display = "none";
            } else {
                document.getElementById("receiver-name").innerText = data.username;
                document.getElementById("receiver-pic").src = data.profile_pic;

                if (data.verified == 1) {
                    document.getElementById("receiver-verified").style.display = "inline-block";
                } else {
                    document.getElementById("receiver-verified").style.display = "none";
                }

                if (friendStatus === 'pending') {
                    if (isSender) {
                        document.getElementById("send-request-btn").style.display = "none";
                        document.getElementById("accept-btn").style.display = "none";
                    } else {
                        document.getElementById("send-request-btn").style.display = "none";
                        document.getElementById("accept-btn").style.display = "inline-block";
                    }
                } else if (friendStatus === 'accepted') {
                    document.getElementById("send-request-btn").style.display = "none";
                    document.getElementById("accept-btn").style.display = "none";
                } else if (friendStatus === 'rejected' || !friendStatus) {
                    document.getElementById("send-request-btn").style.display = "inline-block";
                    document.getElementById("accept-btn").style.display = "none";
                }

                startCall(data.peer_id);
            }
        })
        .catch(err => {
            hideLoading();
            console.error("Fetch Error:", err);
            Swal.fire({
                icon: "error",
                title: "Oops!",
                text: "Something went wrong while fetching a stranger. Please try again later.",
                confirmButtonColor: "#d33",
            });
        });
}

// Answer incoming call
function answerCall(call) {
    console.log("Answering call...");
    getUserMediaStream(function (stream) {
        currentCall = call;
        call.answer(stream);
        call.on("stream", function (remoteStream) {
            document.getElementById("remote-video").srcObject = remoteStream;
        });
        
        call.on("close", function() {
            console.log("Call ended by remote peer");
            shouldCheckConnection = true;
            if (!skipInProgress) {
                handleSkip();
            }
        });
        
        call.on("error", function(err) {
            console.error("Call error:", err);
            shouldCheckConnection = true;
            if (!skipInProgress) {
                Swal.fire({
                    icon: 'error',
                    title: 'Call Error',
                    text: 'The call encountered an error. Trying to reconnect...',
                    confirmButtonColor: '#d33',
                });
                handleSkip();
            }
        });
    });
}

// Start a new call with a stranger
function startCall(peerId) {
    shouldCheckConnection = false;
    getUserMediaStream(function (stream) {
        localStream = stream;
        document.getElementById("local-video").srcObject = stream;

        const call = peer.call(peerId, stream);
        currentCall = call;
        call.on("stream", function (remoteStream) {
            document.getElementById("remote-video").srcObject = remoteStream;
        });
        
        call.on("close", function() {
            console.log("Call ended normally");
            shouldCheckConnection = true;
            if (!skipInProgress) {
                handleSkip();
            }
        });
        
        call.on("error", function(err) {
            console.error("Call error:", err);
            shouldCheckConnection = true;
            if (!skipInProgress) {
                Swal.fire({
                    icon: 'error',
                    title: 'Call Ended',
                    text: 'The call encountered an error.',
                    confirmButtonColor: '#d33',
                });
                handleSkip();
            }
        });
    });
}

// Handle skip functionality
function handleSkip() {
    if (skipInProgress) return;
    skipInProgress = true;
    
    showLoading();
    
    if (currentCall) {
        currentCall.close();
        console.log("Current call ended");
    }
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
        document.getElementById("local-video").srcObject = null;
    }

    document.getElementById("receiver-name").innerText = "No user connected";
    document.getElementById("receiver-pic").src = "assets/default_dp.png";
    document.getElementById("receiver-verified").style.display = "none";

    fetch("vcskip.php")
        .then(res => res.json())
        .then(data => {
            hideLoading();
            skipInProgress = false;
            if (data.error) {
                Swal.fire({
                    icon: 'error',
                    title: 'No Match Found!',
                    text: 'No available users found. Please try again after some time!',
                    confirmButtonColor: '#d33',
                });
            } else {
                document.getElementById("receiver-name").innerText = data.username;
                document.getElementById("receiver-pic").src = data.profile_pic;

                if (data.verified == 1) {
                    document.getElementById("receiver-verified").style.display = "inline-block";
                } else {
                    document.getElementById("receiver-verified").style.display = "none";
                }

                startCall(data.peer_id);
            }
        })
        .catch(err => {
            hideLoading();
            skipInProgress = false;
            console.error("Error skipping stranger:", err);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Something went wrong. Please try again later.',
                confirmButtonColor: '#d33',
            });
        });
}

// Skip to New Stranger with confirmation
function skipStranger() {
    if (skipInProgress) return;
    
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to skip to a new stranger?",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, skip!'
    }).then((result) => {
        if (result.isConfirmed) {
            handleSkip();
        }
    });
}

// Update User Status (Online/Offline)
function updateStatus(status) {
    console.log(`Updating status: ${status}`);

    fetch("vcstatus.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `status=${status}`
    })
        .then(res => res.json())
        .then(data => {
            console.log("Server Response:", data);
            if (data.error) {
                console.error("Status Update Error:", data.error);
            }
        })
        .catch(err => console.error("Error updating status:", err));
}

// Check VC Connection Status
function checkVCConnectionStatus() {
    if (!shouldCheckConnection || skipInProgress) return;
    
    if (controller) {
        controller.abort();
    }

    controller = new AbortController();
    const { signal } = controller;

    fetch("vcconnections.php", { signal })
    .then(response => response.text())
    .then(data => {
        if (data.trim() === "reload" && shouldCheckConnection && !skipInProgress) {
            handleSkip();
        }
    })
    .catch(error => {
        if (error.name !== "AbortError") {
            console.error("VC Connection Check Error:", error);
        }
    });
}

// Mute/Unmute Function
function toggleMute() {
    isMuted = !isMuted;
    localStream.getAudioTracks()[0].enabled = !isMuted;

    var muteButton = document.getElementById("mute-btn");
    if (isMuted) {
        muteButton.innerHTML = '<i class="fas fa-microphone-slash"></i> Unmute';
    } else {
        muteButton.innerHTML = '<i class="fas fa-microphone"></i> Mute';
    }
}

// Send Friend Request
function sendFriendRequest(friendId) {
    fetch('send_friend_request.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `receiver_id=${friendId}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Friend Request Sent!',
                    text: 'Your friend request has been sent successfully.',
                    confirmButtonColor: '#3085d6',
                });
                document.getElementById("send-request-btn").style.display = "none";
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Error sending friend request: ' + data.message,
                    confirmButtonColor: '#d33',
                });
            }
        })
        .catch(err => {
            console.error('Error:', err);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Something went wrong. Please try again later.',
                confirmButtonColor: '#d33',
            });
        });
}

// Accept Friend Request
function acceptFriendRequest(requestId) {
    fetch('accept_friend_request.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `request_id=${requestId}`
    })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire({
                    icon: 'success',
                    title: 'Friend Request Accepted!',
                    text: 'You are now friends.',
                    confirmButtonColor: '#3085d6',
                });
                document.getElementById("accept-btn").style.display = "none";
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Error accepting friend request: ' + data.message,
                    confirmButtonColor: '#d33',
                });
            }
        })
        .catch(err => {
            console.error('Error:', err);
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: 'Something went wrong. Please try again later.',
                confirmButtonColor: '#d33',
            });
        });
}

// Event Listeners
document.getElementById("mute-btn").addEventListener("click", toggleMute);
document.getElementById("skip-btn").addEventListener("click", skipStranger);

// Handle visibility changes
document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
        updateStatus("offline");
    } else {
        updateStatus("online");
    }
});

// Handle page unload
window.addEventListener("beforeunload", function () {
    updateStatus("offline");
    if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
    }
    if (currentCall) currentCall.close();
});

// Initialize on page load
window.onload = function () {
    initializePeer();
    fetchStrangerDetails();
    updateStatus("online");
    
    // Check connection status every 5 seconds
    setInterval(checkVCConnectionStatus, 5000);
};
</script>
</body>
</html>