<?php
session_start();
include 'db.php'; // Database connection

// Redirect if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Get the selected plan ID from the URL
$plan_id = $_GET['plan_id'];
$current_date = date('Y-m-d');

// Fetch the selected plan with discount calculation
$sql = "SELECT *,
        CASE 
            WHEN is_discounted = 1 AND (discount_expiry IS NULL OR discount_expiry >= '$current_date') 
            THEN price * (1 - discounted_price/100) 
            ELSE price 
        END AS final_price
        FROM plans WHERE id = $plan_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $plan = $result->fetch_assoc();
    $has_discount = $plan['is_discounted'] && (!$plan['discount_expiry'] || $plan['discount_expiry'] >= $current_date);
} else {
    die("Plan not found.");
}

// Fetch UPI ID from the settings table
$sql_settings = "SELECT upi FROM settings LIMIT 1";
$result_settings = $conn->query($sql_settings);

if ($result_settings->num_rows > 0) {
    $settings = $result_settings->fetch_assoc();
    $upi_id = $settings['upi'];
} else {
    die("UPI ID not found in settings.");
}

// Calculate final amount and format for UPI
$amount = $has_discount ? $plan['final_price'] : $plan['price'];
$formatted_amount = number_format($amount, 2, '.', ''); // Ensures 2 decimal places
$upi_url = "upi://pay?pa=$upi_id&pn=TalkRush&am=$formatted_amount&cu=INR";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Payment - TalkRush</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #4361ee;
            --secondary-color: #3f37c9;
            --accent-color: #4cc9f0;
            --success-color: #4bb543;
            --danger-color: #e63946;
            --warning-color: #ff9f1c;
            --light-color: #f8f9fa;
            --dark-color: #212529;
        }
        
        body {
            background-color: #f5f7fb;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #e0e0e0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--dark-color);
            font-size: 20px;
            cursor: pointer;
            padding: 5px;
            border-radius: 50%;
            transition: all 0.3s;
        }
        
        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .container {
            margin-top: 80px;
            padding-bottom: 40px;
        }
        
        .payment-card {
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            margin-bottom: 25px;
            transition: transform 0.3s;
            border: none;
        }
        
        .payment-card:hover {
            transform: translateY(-5px);
        }
        
        .payment-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 20px;
            text-align: center;
        }
        
        .payment-body {
            padding: 25px;
        }
        
        .upi-qr-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
            text-align: center;
            border: 1px dashed #e0e0e0;
        }
        
        .upi-qr {
            max-width: 100%;
            height: auto;
            margin: 0 auto 15px;
            border-radius: 8px;
        }
        
        .payment-amount {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .original-price {
            font-size: 14px;
            color: #666;
            text-decoration: line-through;
        }
        
        .plan-name {
            font-size: 22px;
            font-weight: 700;
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .price-container {
            margin-bottom: 15px;
        }
        
        .final-price {
            font-size: 32px;
            font-weight: 800;
            color: var(--success-color);
        }
        
        .discount-badge {
            background-color: rgba(230, 57, 70, 0.15);
            color: var(--danger-color);
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            display: inline-block;
            margin-left: 10px;
        }
        
        .expiry-badge {
            background-color: rgba(255, 159, 28, 0.15);
            color: var(--warning-color);
            padding: 4px 10px;
            border-radius: 50px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
            margin-top: 5px;
        }
        
        .plan-features {
            list-style-type: none;
            padding: 0;
            margin: 20px 0;
        }
        
        .plan-features li {
            padding: 8px 0;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .plan-features li:last-child {
            border-bottom: none;
        }
        
        .plan-features li i {
            color: var(--success-color);
            margin-right: 10px;
            font-size: 18px;
        }
        
        .payment-steps {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .step {
            display: flex;
            margin-bottom: 15px;
            align-items: center;
        }
        
        .step-number {
            background-color: var(--accent-color);
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-weight: bold;
            flex-shrink: 0;
        }
        
        .step-content {
            flex-grow: 1;
        }
        
        .upi-apps {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-top: 20px;
            flex-wrap: wrap;
        }
        
        .upi-app {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s;
        }
        
        .upi-app:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        
        .upi-app img {
            width: 30px;
            height: 30px;
            object-fit: contain;
        }
        
        .note {
            background: #fff8e1;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #ffc107;
            font-size: 14px;
        }
        
        .ribbon {
            position: absolute;
            top: 15px;
            right: -15px;
            width: 60px;
            height: 60px;
            overflow: hidden;
            z-index: 2;
        }
        
        .ribbon span {
            position: absolute;
            display: block;
            width: 90px;
            padding: 5px 0;
            background: linear-gradient(45deg, #ff0000, #ff6b6b);
            color: #fff;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
            right: -5px;
            top: 15px;
            transform: rotate(45deg);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>

<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="history.back()">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4 style="margin: 0; font-weight: 600;">Complete Payment</h4>
    <div></div> <!-- Empty div for spacing -->
</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <!-- Payment Steps -->
            <div class="payment-steps">
                <h5 style="font-weight: 600; margin-bottom: 20px; color: var(--primary-color);">Payment Instructions</h5>
                <div class="step">
                    <div class="step-number">1</div>
                    <div class="step-content">Scan the QR code below using any UPI payment app</div>
                </div>
                <div class="step">
                    <div class="step-number">2</div>
                    <div class="step-content">Verify the payment amount and recipient details</div>
                </div>
                <div class="step">
                    <div class="step-number">3</div>
                    <div class="step-content">Complete the payment using your UPI PIN</div>
                </div>
                <div class="step">
                    <div class="step-number">4</div>
                    <div class="step-content">Your subscription will be activated automatically</div>
                </div>
            </div>
            
            <!-- QR Code Section -->
            <div class="payment-card">
                <div class="payment-header">
                    <h5 style="margin: 0; font-weight: 600;">Scan to Pay</h5>
                </div>
                <div class="payment-body text-center">
                    <div class="upi-qr-container">
                        <img id="qrImage" src="" alt="UPI QR Code" class="upi-qr">
                        <div class="payment-amount">
                            Amount: ₹<?= number_format($amount, 2) ?>
                            <?php if ($has_discount): ?>
                                <span class="original-price">(Originally ₹<?= number_format($plan['price'], 2) ?>)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="upi-apps">
                        <div class="upi-app">
                            <img src="assets/gpay.png" alt="Google Pay">
                        </div>
                        <div class="upi-app">
                            <img src="assets/phonepe.png" alt="PhonePe">
                        </div>
                        <div class="upi-app">
                            <img src="assets/paytm.png" alt="Paytm">
                        </div>
                        <div class="upi-app">
                            <img src="assets/bhim.png" alt="BHIM">
                        </div>
                    </div>
                    
                    <div class="note">
                        <i class="fas fa-info-circle" style="color: #ffc107; margin-right: 5px;"></i>
                        After successful payment, your subscription will be activated within 5 minutes.
If it doesn't activate, please contact us through the Help section.
                    </div>
                </div>
            </div>
            
            <!-- Plan Details -->
            <div class="payment-card">
                <div class="payment-header">
                    <h5 style="margin: 0; font-weight: 600;">Plan Details</h5>
                </div>
                <div class="payment-body">
                    <?php if ($has_discount): ?>
                        <div class="ribbon">
                            <span>SAVE <?= $plan['discounted_price'] ?>%</span>
                        </div>
                    <?php endif; ?>
                    
                    <h3 class="plan-name"><?= htmlspecialchars($plan['name']) ?></h3>
                    <p style="color: #666;"><?= htmlspecialchars($plan['description']) ?></p>
                    
                    <div class="price-container">
                        <?php if ($has_discount): ?>
                            <span class="original-price">₹<?= number_format($plan['price'], 2) ?></span>
                        <?php endif; ?>
                        <span class="final-price">₹<?= number_format($amount, 2) ?></span>
                        <?php if ($has_discount): ?>
                            <span class="discount-badge"><?= $plan['discounted_price'] ?>% OFF</span>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($has_discount && $plan['discount_expiry']): ?>
                        <div class="expiry-badge">
                            <i class="fas fa-clock me-1"></i>
                            Offer ends <?= date('M d, Y', strtotime($plan['discount_expiry'])) ?>
                        </div>
                    <?php endif; ?>
                    
                    <p style="color: #666; margin-bottom: 20px;"><strong>Duration:</strong> <?= $plan['duration'] ?> days</p>
                    
                    <h6 style="font-weight: 600; margin-bottom: 15px; color: var(--primary-color);">Features:</h6>
                    <ul class="plan-features">
                        <?php
                        $features = explode(",", $plan['features']);
                        foreach ($features as $feature): ?>
                            <li><i class="fas fa-check-circle"></i> <?= htmlspecialchars(trim($feature)) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<!-- JavaScript to Generate QR Code -->
<script>
    // UPI URL from PHP with properly formatted amount
    const upiUrl = "<?= $upi_url ?>";
    
    // QRServer API URL
    const qrServerUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiUrl)}&bgcolor=ffffff&color=000000&margin=10&qzone=1`;
    
    // Set the QR code image source
    document.getElementById('qrImage').src = qrServerUrl;
    
    // Add animation to elements
    document.addEventListener('DOMContentLoaded', function() {
        const elements = document.querySelectorAll('.payment-card, .payment-steps');
        elements.forEach((el, index) => {
            setTimeout(() => {
                el.style.opacity = '1';
                el.style.transform = 'translateY(0)';
            }, index * 150);
        });
    });
</script>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/628cf08f7b967b117990ff27/1g3r8nd3d';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>