<?php
session_start();
include('db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die(json_encode(['error' => 'Not logged in']));
}

$user_id = $_SESSION['user_id'];
$response = [
    'hasPendingRequests' => false,
    'hasNewNotifications' => false,
    'latestReactions' => [], // Array to store latest feed reactions
    'storyLikes' => [], // Array to store new story likes
    'commentReplies' => [] // Array to store replies to user's comments
];

// Check for pending friend requests where current user is receiver
$requestQuery = "SELECT COUNT(*) as count FROM friend_requests 
                WHERE receiver_id = $user_id AND status = 'pending'";
$requestResult = $conn->query($requestQuery);
if ($requestResult && $row = $requestResult->fetch_assoc()) {
    $response['hasPendingRequests'] = $row['count'] > 0;
}

// Check for unread notifications
$notificationQuery = "SELECT COUNT(*) as count FROM notifications
                     WHERE user_id = $user_id AND status = 'unread'";
$notificationResult = $conn->query($notificationQuery);
if ($notificationResult && $row = $notificationResult->fetch_assoc()) {
    if ($row['count'] > 0) {
        $response['hasNewNotifications'] = true;
    }
}

// Fetch latest reactions (likes, comments, replies) from feed_reactions
$reactionQuery = "SELECT 
                    fr.id, 
                    fr.feed_id, 
                    fr.reaction_type, 
                    fr.content AS comment_text,
                    fr.created_at,
                    u.username,
                    u.profile_pic,
                    u.verified,
                    f.text AS post_text,
                    f.image AS post_image
                FROM feed_reactions fr
                JOIN users u ON fr.user_id = u.id
                JOIN feeds f ON fr.feed_id = f.id
                WHERE f.user_id = $user_id AND fr.user_id != $user_id
                ORDER BY fr.created_at DESC
                LIMIT 5"; // Adjust limit as needed

$reactionResult = $conn->query($reactionQuery);
if ($reactionResult) {
    $response['latestReactions'] = $reactionResult->fetch_all(MYSQLI_ASSOC);
}

// Fetch replies to user's comments
$commentReplyQuery = "SELECT 
                        fr.id,
                        fr.feed_id,
                        fr.content AS reply_text,
                        fr.created_at,
                        u.username,
                        u.profile_pic,
                        u.verified,
                        f.text AS post_text,
                        f.image AS post_image,
                        original_comment.content AS original_comment
                    FROM feed_reactions fr
                    JOIN users u ON fr.user_id = u.id
                    JOIN feeds f ON fr.feed_id = f.id
                    JOIN feed_reactions original_comment ON fr.parent_id = original_comment.id
                    WHERE original_comment.user_id = $user_id 
                    AND fr.user_id != $user_id
                    AND fr.reaction_type = 'reply'
                    ORDER BY fr.created_at DESC
                    LIMIT 5"; // Adjust limit as needed

$commentReplyResult = $conn->query($commentReplyQuery);
if ($commentReplyResult) {
    $response['commentReplies'] = $commentReplyResult->fetch_all(MYSQLI_ASSOC);
}

// Fetch story likes (likes on the user's stories)
$storyLikeQuery = "SELECT 
                    si.id, 
                    si.user_id, 
                    si.liked, 
                    u.username, 
                    u.profile_pic
                  FROM story_interactions si
                  JOIN stories s ON si.group_id = s.group_id
                  JOIN users u ON si.user_id = u.id
                  WHERE s.user_id = $user_id AND si.liked = 1 
                  ORDER BY si.interacted_at DESC
                  LIMIT 5"; // Adjust limit as needed

$storyLikeResult = $conn->query($storyLikeQuery);
if ($storyLikeResult) {
    $response['storyLikes'] = $storyLikeResult->fetch_all(MYSQLI_ASSOC);
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Close connection
$conn->close();
?>