<?php
// Database connection
include('db.php'); // Correct database connection

// Use server default timezone (no timezone set here)
$current_date = date('Y-m-d');
$current_time = date('H:i');

echo "Script running at: $current_date $current_time\n";

// 1. Handle expired premium subscriptions
$sql = "SELECT id FROM users WHERE premium_expiry <= '$current_date' AND premium = 1";
$result = $conn->query($sql);

if ($result === false) {
    echo "Error fetching expired premium users: " . $conn->error . "\n";
} elseif ($result->num_rows > 0) {
    $update_sql = "UPDATE users 
                   SET premium = 0, 
                       verified = CASE WHEN verified = 1 THEN 0 ELSE verified END, 
                       premium_expiry = NULL 
                   WHERE premium_expiry <= '$current_date' AND premium = 1";
    if ($conn->query($update_sql) === TRUE) {
        echo "Expired premium subscriptions have been updated.\n";
    } else {
        echo "Error updating expired premium subscriptions: " . $conn->error . "\n";
    }
} else {
    echo "No expired premium subscriptions found.\n";
}

// 2. Handle expired discounts in plans table
$discount_sql = "UPDATE plans 
                SET is_discounted = 0,
                    discount_expiry = NULL,
                    discounted_price = 0
                WHERE discount_expiry IS NOT NULL 
                AND discount_expiry <= '$current_date'";
if ($conn->query($discount_sql) === TRUE) {
    echo ($conn->affected_rows > 0) ? "Expired discounts have been cleared from plans.\n" : "No expired discounts found in plans.\n";
} else {
    echo "Error updating discounts: " . $conn->error . "\n";
}

// 3. Mark online users as offline in users table
$offline_status_sql = "UPDATE users SET `status` = 'offline' WHERE `status` = 'online'";
if ($conn->query($offline_status_sql) === TRUE) {
    echo ($conn->affected_rows > 0) ? "All online users have been marked offline in the users table.\n" : "No users were marked offline in the users table.\n";
} else {
    echo "Error updating user status: " . $conn->error . "\n";
}

// 4. Mark active users as inactive in users table
$offline_active_sql = "UPDATE users SET active_status = 0 WHERE active_status = 1";
if ($conn->query($offline_active_sql) === TRUE) {
    echo ($conn->affected_rows > 0) ? "All active users have been marked inactive in the users table.\n" : "No active users were marked inactive in the users table.\n";
} else {
    echo "Error updating active status in users table: " . $conn->error . "\n";
}

// 5. Mark all users as offline in status table
$offline_sql_status = "UPDATE status SET vcstatus = 'offline' WHERE vcstatus = 'online'";
if ($conn->query($offline_sql_status) === TRUE) {
    echo ($conn->affected_rows > 0) ? "All users have been marked offline in the status table.\n" : "No users were marked offline in the status table.\n";
} else {
    echo "Error updating status table: " . $conn->error . "\n";
}

// 6. Delete voice_joins for rooms not created today
$voice_joins_delete_sql = "
    DELETE vj 
    FROM voice_joins vj
    INNER JOIN voice v ON vj.room_id = v.id
    WHERE DATE(v.created_at) < CURDATE()
";
if ($conn->query($voice_joins_delete_sql) === TRUE) {
    echo ($conn->affected_rows > 0) ? "Old voice_joins entries have been deleted.\n" : "No old voice_joins entries found.\n";
} else {
    echo "Error deleting old voice_joins: " . $conn->error . "\n";
}

// 7. Delete voice rooms not created today
$delete_old_rooms_sql = "DELETE FROM voice WHERE DATE(created_at) < CURDATE()";
if ($conn->query($delete_old_rooms_sql) === TRUE) {
    echo ($conn->affected_rows > 0) ? "Old voice rooms have been deleted.\n" : "No old voice rooms to delete.\n";
} else {
    echo "Error deleting old voice rooms: " . $conn->error . "\n";
}

// 8. Delete expired stories and their images
$expired_stories_sql = "SELECT id, image_url FROM stories WHERE expires_at <= NOW()";
$expired_stories = $conn->query($expired_stories_sql);

if ($expired_stories && $expired_stories->num_rows > 0) {
    while ($story = $expired_stories->fetch_assoc()) {
        $image_path = __DIR__ . '/' . $story['image_url'];

        echo "Processing story ID: {$story['id']}, Image: {$image_path}\n";

        if (!empty($story['image_url']) && file_exists($image_path)) {
            if (unlink($image_path)) {
                echo "Image deleted: $image_path\n";
            } else {
                echo "Failed to delete image: $image_path\n";
            }
        } else {
            echo "Image file not found or path is empty: $image_path\n";
        }

        $conn->query("DELETE FROM story_interactions WHERE group_id = '{$story['id']}'");
        $conn->query("DELETE FROM stories WHERE id = '{$story['id']}'");
    }
    echo "Expired stories and associated images have been processed.\n";
} else {
    echo "No expired stories to delete.\n";
}

$conn->close();
?>
