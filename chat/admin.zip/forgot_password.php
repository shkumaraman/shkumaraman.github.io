<?php
session_start();
require 'db.php';  // Include the database connection

// Fetch API key and email from the settings table
$settingsQuery = "SELECT email_api, email FROM settings LIMIT 1";
$settingsResult = $conn->query($settingsQuery);
$settings = $settingsResult->fetch_assoc();

// Brevo API key and email from settings
$apiKey = $settings['email_api'] ?? '';  // Fetch API key from settings with null coalescing
$senderEmail = $settings['email'] ?? '';  // Fetch email from settings with null coalescing

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');  // Redirect to dashboard if logged in
    exit();
}

// Generate a random OTP (6 digits) - DON'T MODIFY THIS FUNCTION
function generateOtp() {
    return rand(100000, 999999);  // Generates a 6-digit OTP
}

// Send OTP to the user email - DON'T MODIFY THIS FUNCTION
function sendOtpEmail($email, $otp) {
    global $apiKey, $senderEmail;  // Use the fetched API key and email

    $url = 'https://api.brevo.com/v3/smtp/email';  // Brevo API endpoint for sending transactional emails

    $data = [
        'sender' => ['email' => $senderEmail],  // Use the email from settings
        'to' => [['email' => $email]],  // Recipient's email
        'subject' => 'Your OTP Code',
        'htmlContent' => '<html><body><h3>Your OTP code is: ' . $otp . '</h3><p>This OTP will expire in 5 minutes.</p></body></html>',
    ];

    // Initialize cURL session
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'api-key: ' . $apiKey,
        'Content-Type: application/json',
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    // Execute cURL request and get the response
    $response = curl_exec($ch);

    // Check if the request was successful
    if(curl_errno($ch)) {
        return 'Failed to send OTP. Please try again.';
    }
    curl_close($ch);

    return 'OTP sent successfully!';
}

// Initialize variables
$email = '';
$otpMessage = '';
$verificationMessage = '';
$remainingTime = 0;  // Remaining time in seconds
$messageType = '';   // To store message type (success, error, warning)

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['email'])) {
        // Email submission
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $otpMessage = 'Invalid email format';
            $messageType = 'error';
        } else {
            // First check if email exists in users table
            $checkEmailStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $checkEmailStmt->bind_param("s", $email);
            $checkEmailStmt->execute();
            $checkEmailResult = $checkEmailStmt->get_result();
            
            if ($checkEmailResult->num_rows === 0) {
                $otpMessage = 'This email is not registered with us';
                $messageType = 'warning';
                $checkEmailStmt->close();
            } else {
                // Email exists, proceed with OTP
                $checkEmailStmt->close();
                
                // Check if the user has a recent OTP request
                $stmt = $conn->prepare("SELECT otp_expiry FROM users WHERE email = ?");
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();

                if ($user && isset($user['otp_expiry']) && $user['otp_expiry'] > date('Y-m-d H:i:s')) {
                    // Calculate remaining time
                    $remainingTime = strtotime($user['otp_expiry']) - time();
                    $otpMessage = 'Please wait ' . gmdate("i:s", $remainingTime) . ' minutes before requesting a new OTP.';
                    $messageType = 'warning';
                } else {
                    // Generate OTP and save it in the database
                    $otp = generateOtp();
                    $otpExpiry = date('Y-m-d H:i:s', time() + 300);  // OTP expires in 5 minutes

                    // Update the user's OTP and OTP expiry in the database
                    $stmt = $conn->prepare("UPDATE users SET otp = ?, otp_expiry = ? WHERE email = ?");
                    $stmt->bind_param("sss", $otp, $otpExpiry, $email);

                    if ($stmt->execute()) {
                        // Send OTP to the user email
                        $otpMessage = sendOtpEmail($email, $otp);
                        $messageType = strpos($otpMessage, 'Failed') === false ? 'success' : 'error';
                        $_SESSION['otp_email'] = $email;  // Store email in session for verification
                        $_SESSION['otp_attempts'] = 0;    // Initialize OTP attempts counter
                    } else {
                        $otpMessage = "Error processing your request. Please try again.";
                        $messageType = 'error';
                    }
                }
                $stmt->close();
            }
        }
    } elseif (isset($_POST['otp'])) {
        // OTP verification will be handled via AJAX
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css"><style>
        :root {
            --bg-color: #ffffff;
            --primary-color: #4e73df;
            --success-color: #1cc88a;
            --danger-color: #e74a3b;
            --warning-color: #f6c23e;
            --light-color: #f8f9fc;
            --dark-color: #5a5c69;
        }
        
        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;          
           }
        
        .container {
            margin-top: 100px;
            max-width: 500px;
        }
        
        .card {
            border: none;
            border-radius: 0.35rem;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
        }
        
        .card-header {
            background-color: var(--primary-color);
            color: white;
            font-weight: 600;
            border-radius: 0.35rem 0.35rem 0 0 !important;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }
        
        .btn-primary:hover {
            background-color: #2e59d9;
            border-color: #2653d4;
        }
        
        .btn-success {
            background-color: var(--success-color);
            border-color: var(--success-color);
        }
        
        .btn-success:hover {
            background-color: #17a673;
            border-color: #149e6e;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .disabled {
            pointer-events: none;
            opacity: 0.6;
        }
        
        .message {
            margin-top: 10px;
            padding: 10px;
            border-radius: 4px;
            font-weight: 600;
        }
        
        .success {
            background-color: rgba(28, 200, 138, 0.1);
            color: var(--success-color);
            border-left: 4px solid var(--success-color);
        }
        
        .error {
            background-color: rgba(231, 74, 59, 0.1);
            color: var(--danger-color);
            border-left: 4px solid var(--danger-color);
        }
        
        .warning {
            background-color: rgba(246, 194, 62, 0.1);
            color: var(--warning-color);
            border-left: 4px solid var(--warning-color);
        }
        
        #timer {
            font-weight: 600;
            color: var(--danger-color);
            margin-top: 10px;
        }
        
        .header {
            position: fixed;
            top: 0;
            left: 0;
            z-index: 9999;
            width: 100%;
            background: white;
            color: var(--dark-color);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
        }
        
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }

        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: var(--dark-color);
        }
        
        .password-input-group {
            position: relative;
        }
        
        .input-group-text {
            background-color: var(--light-color);
        }
        
        .progress {
            height: 5px;
            margin-top: 5px;
        }
        
        .progress-bar {
            transition: width 0.3s ease;
        }
        
        .password-strength-weak {
            background-color: var(--danger-color);
        }
        
        .password-strength-medium {
            background-color: var(--warning-color);
        }
        
        .password-strength-strong {
            background-color: var(--success-color);
        }
        
        .password-hint {
            font-size: 0.8rem;
            color: var(--dark-color);
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <!-- Header with Back Button -->
    <div class="header">
        <button class="back-btn" onclick="history.back()">
            <i class="fas fa-arrow-left"></i>
        </button>
        <h4 class="mb-0">Forgot Password</h4>
        <div style="width: 24px;"></div> <!-- Empty div for spacing -->
    </div>

    <div class="container">
        <!-- Email Input Card -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold">Step 1: Verify Email</h6>
            </div>
            <div class="card-body">
                <form method="POST" id="emailForm">
                    <div class="mb-3">
                        <label for="email" class="form-label">Enter your email address</label>
                        <div class="input-group">
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($email); ?>" required
                                   placeholder="example@domain.com">
                            <button type="submit" class="btn btn-primary" id="sendOtpBtn">
                                <span id="sendOtpText">Send OTP</span>
                                <span id="sendOtpSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                        <?php if ($otpMessage): ?>
                            <div class="message <?php echo $messageType; ?> mt-3">
                                <?php echo htmlspecialchars($otpMessage); ?>
                            </div>
                        <?php endif; ?>
                        <div id="timer" class="mt-2"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- OTP Verification Card (initially hidden) -->
        <div class="card mb-4" id="otpCard" style="display: none;">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold">Step 2: Enter OTP</h6>
            </div>
            <div class="card-body">
                <form id="otpForm">
                    <div class="mb-3">
                        <label for="otp" class="form-label">Enter the 6-digit OTP sent to your email</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="otp" name="otp" required
                                   maxlength="6" pattern="\d{6}" title="Please enter a 6-digit number"
                                   placeholder="123456">
                            <button type="submit" id="verifyOtpBtn" class="btn btn-primary">
                                <span id="verifyOtpText">Verify</span>
                                <span id="verifyOtpSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                            </button>
                        </div>
                        <small class="text-muted">Check your spam folder if you don't see the email.</small>
                        <div id="otpMessage" class="message mt-3" style="display: none;"></div>
                        <div id="otpAttempts" class="text-danger mt-2" style="display: none;"></div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Password Reset Card (initially hidden) -->
        <div class="card mb-4" id="passwordCard" style="display: none;">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold">Step 3: Set New Password</h6>
            </div>
            <div class="card-body">
                <form id="passwordForm">
                    <div class="mb-3 password-input-group">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required disabled>
                        <i class="fas fa-eye password-toggle" id="toggleNewPassword"></i>
                        <div class="progress mt-1">
                            <div class="progress-bar" id="passwordStrength" role="progressbar" style="width: 0%"></div>
                        </div>
                        <div class="password-hint">
                            Password must be at least 8 characters and include uppercase, lowercase, number, and special character.
                        </div>
                    </div>
                    
                    <div class="mb-3 password-input-group">
                        <label for="confirm_password" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required disabled>
                        <i class="fas fa-eye password-toggle" id="toggleConfirmPassword"></i>
                        <div id="passwordMatch" class="password-hint"></div>
                    </div>
                    
                    <button type="submit" id="updatePasswordBtn" class="btn btn-success w-100" disabled>
                        <span id="updatePasswordText">Update Password</span>
                        <span id="updatePasswordSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div class="modal fade" id="successModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title">Success</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Your password has been updated successfully!</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" data-bs-dismiss="modal" id="redirectToLogin">Go to Login</button>
                </div>
            </div>
        </div>
    </div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            let remainingTime = <?php echo $remainingTime; ?>;
            let otpAttempts = 0;
            const maxOtpAttempts = 3;
            
            // Password strength indicators
            const strengthClasses = {
                0: '',
                1: 'password-strength-weak',
                2: 'password-strength-medium',
                3: 'password-strength-strong',
                4: 'password-strength-strong'
            };
            
            // Show OTP card if email is already submitted
            if ($('#email').val()) {
                $('#otpCard').show();
            }
            
            // Timer function
            function updateTimer() {
                if (remainingTime > 0) {
                    const minutes = Math.floor(remainingTime / 60);
                    const seconds = remainingTime % 60;
                    $('#timer').html(`Please wait ${minutes}:${seconds.toString().padStart(2, '0')} before requesting a new OTP.`);
                    $('#sendOtpBtn').prop('disabled', true);
                    remainingTime--;
                    setTimeout(updateTimer, 1000);
                } else {
                    $('#timer').html('');
                    $('#sendOtpBtn').prop('disabled', false);
                }
            }
            
            // Start timer if needed
            if (remainingTime > 0) {
                updateTimer();
            }
            
            // Email form submission
            $('#emailForm').on('submit', function(e) {
                e.preventDefault();
                const email = $('#email').val().trim();
                
                if (!email) {
                    showMessage('error', 'Please enter your email address');
                    return;
                }
                
                // Simple email validation
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                    showMessage('error', 'Please enter a valid email address');
                    return;
                }
                
                // Show loading state
                $('#sendOtpText').addClass('d-none');
                $('#sendOtpSpinner').removeClass('d-none');
                $('#sendOtpBtn').prop('disabled', true);
                
                // Submit form via AJAX
                $.ajax({
                    url: window.location.href,
                    type: 'POST',
                    data: { email: email },
                    success: function(response) {
                        // Create a temporary DOM element to parse the response
                        const $response = $('<div>').html(response);
                        const message = $response.find('.message').text();
                        const messageType = $response.find('.message').attr('class').includes('success') ? 'success' : 
                                          $response.find('.message').attr('class').includes('warning') ? 'warning' : 'error';
                        
                        showMessage(messageType, message);
                        
                        if (messageType === 'success') {
                            $('#otpCard').show();
                            remainingTime = 300; // 5 minutes
                            updateTimer();
                        }
                    },
                    error: function() {
                        showMessage('error', 'An error occurred. Please try again.');
                    },
                    complete: function() {
                        $('#sendOtpText').removeClass('d-none');
                        $('#sendOtpSpinner').addClass('d-none');
                        $('#sendOtpBtn').prop('disabled', false);
                    }
                });
            });
            
            // OTP form submission
            $('#otpForm').on('submit', function(e) {
                e.preventDefault();
                const otp = $('#otp').val().trim();
                
                if (!otp || !/^\d{6}$/.test(otp)) {
                    showOtpMessage('error', 'Please enter a valid 6-digit OTP');
                    return;
                }
                
                // Show loading state
                $('#verifyOtpText').addClass('d-none');
                $('#verifyOtpSpinner').removeClass('d-none');
                $('#verifyOtpBtn').prop('disabled', true);
                
                $.ajax({
                    url: 'verify_otp.php',
                    type: 'POST',
                    data: { otp: otp },
                    success: function(response) {
                        if (response === 'success') {
                            showOtpMessage('success', 'OTP verified successfully!');
                            $('#passwordCard').show();
                            $('#new_password, #confirm_password, #updatePasswordBtn').prop('disabled', false);
                        } else {
                            otpAttempts++;
                            if (otpAttempts >= maxOtpAttempts) {
                                showOtpMessage('error', 'Maximum OTP attempts reached. Please request a new OTP.');
                                $('#otp').prop('disabled', true);
                                $('#verifyOtpBtn').prop('disabled', true);
                                remainingTime = 300; // 5 minutes cooldown
                                updateTimer();
                            } else {
                                showOtpMessage('error', 'Invalid OTP. ' + (maxOtpAttempts - otpAttempts) + ' attempts remaining.');
                            }
                        }
                    },
                    error: function() {
                        showOtpMessage('error', 'An error occurred. Please try again.');
                    },
                    complete: function() {
                        $('#verifyOtpText').removeClass('d-none');
                        $('#verifyOtpSpinner').addClass('d-none');
                        $('#verifyOtpBtn').prop('disabled', false);
                    }
                });
            });
            
            // Password form submission
            $('#passwordForm').on('submit', function(e) {
                e.preventDefault();
                const newPassword = $('#new_password').val();
                const confirmPassword = $('#confirm_password').val();
                
                if (newPassword !== confirmPassword) {
                    showPasswordMatch(false);
                    return;
                }
                
                // Validate password strength
                if (!isPasswordStrong(newPassword)) {
                    showPasswordMatch(false, 'Password does not meet requirements');
                    return;
                }
                
                // Show loading state
                $('#updatePasswordText').addClass('d-none');
                $('#updatePasswordSpinner').removeClass('d-none');
                $('#updatePasswordBtn').prop('disabled', true);
                
                $.ajax({
                    url: 'update_password.php',
                    type: 'POST',
                    data: { new_password: newPassword },
                    success: function(response) {
                        if (response === 'success') {
                            $('#successModal').modal('show');
                        } else {
                            showPasswordMatch(false, 'Failed to update password. Please try again.');
                        }
                    },
                    error: function() {
                        showPasswordMatch(false, 'An error occurred. Please try again.');
                    },
                    complete: function() {
                        $('#updatePasswordText').removeClass('d-none');
                        $('#updatePasswordSpinner').addClass('d-none');
                        $('#updatePasswordBtn').prop('disabled', false);
                    }
                });
            });
            
            // Redirect to login after success
            $('#redirectToLogin').on('click', function() {
                window.location.href = 'index.php';
            });
            
            // Password strength checker
            $('#new_password').on('input', function() {
                const password = $(this).val();
                const strength = calculatePasswordStrength(password);
                
                // Update progress bar
                const percentage = strength * 25;
                $('#passwordStrength')
                    .css('width', percentage + '%')
                    .removeClass()
                    .addClass('progress-bar ' + strengthClasses[strength]);
                
                // Enable/disable submit button based on strength
                if (strength >= 2 && password.length >= 8) {
                    $('#updatePasswordBtn').prop('disabled', false);
                } else {
                    $('#updatePasswordBtn').prop('disabled', true);
                }
            });
            
            // Password match checker
            $('#confirm_password').on('input', function() {
                const password = $('#new_password').val();
                const confirm = $(this).val();
                
                if (confirm.length > 0) {
                    showPasswordMatch(password === confirm);
                } else {
                    $('#passwordMatch').text('').removeClass('text-success text-danger');
                }
            });
            
            // Toggle password visibility
            $('#toggleNewPassword').on('click', function() {
                togglePasswordVisibility('#new_password', $(this));
            });
            
            $('#toggleConfirmPassword').on('click', function() {
                togglePasswordVisibility('#confirm_password', $(this));
            });
            
            // Helper functions
            function showMessage(type, message) {
                $('.message').remove();
                $('#emailForm').append(
                    `<div class="message ${type} mt-3">${message}</div>`
                );
            }
            
            function showOtpMessage(type, message) {
                $('#otpMessage')
                    .removeClass('success error warning')
                    .addClass(type)
                    .text(message)
                    .show();
                
                if (type === 'error') {
                    $('#otpAttempts').text(`${otpAttempts}/${maxOtpAttempts} attempts`).show();
                } else {
                    $('#otpAttempts').hide();
                }
            }
            
            function showPasswordMatch(isMatch, customMessage = '') {
                const $match = $('#passwordMatch');
                if (customMessage) {
                    $match.text(customMessage).removeClass('text-success text-danger').addClass('text-danger');
                    return;
                }
                
                if ($('#confirm_password').val().length === 0) {
                    $match.text('').removeClass('text-success text-danger');
                } else if (isMatch) {
                    $match.text('Passwords match').removeClass('text-danger').addClass('text-success');
                } else {
                    $match.text('Passwords do not match').removeClass('text-success').addClass('text-danger');
                }
            }
            
            function togglePasswordVisibility(inputId, icon) {
                const input = $(inputId);
                const type = input.attr('type') === 'password' ? 'text' : 'password';
                input.attr('type', type);
                icon.toggleClass('fa-eye fa-eye-slash');
            }
            
            function calculatePasswordStrength(password) {
                let strength = 0;
                
                // Length check
                if (password.length > 0) strength++;
                if (password.length >= 8) strength++;
                
                // Complexity checks
                if (/[A-Z]/.test(password)) strength++;
                if (/[0-9]/.test(password)) strength++;
                if (/[^A-Za-z0-9]/.test(password)) strength++;
                
                // Cap at 4
                return Math.min(strength, 4);
            }
            
            function isPasswordStrong(password) {
                return password.length >= 8 &&
                       /[A-Z]/.test(password) &&
                       /[a-z]/.test(password) &&
                       /[0-9]/.test(password) &&
                       /[^A-Za-z0-9]/.test(password);
            }
        });
    </script>
</body>
</html>