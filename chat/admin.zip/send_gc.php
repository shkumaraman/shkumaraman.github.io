<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$response = ['success' => false];

try {
    if (isset($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        // Handle image upload
        $uploadDir = 'uploads/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = uniqid() . '_' . $_SESSION['user_id'] . '.jpg';
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['media']['tmp_name'], $filePath)) {
            // Insert into database
            $stmt = $conn->prepare("INSERT INTO group_chat (sender_id, message, media) VALUES (?, ?, ?)");
            $message = 'Image shared';
            $stmt->bind_param("iss", $_SESSION['user_id'], $message, $fileName);
            
            if ($stmt->execute()) {
                $response = [
                    'success' => true,
                    'filename' => $fileName,
                    'message' => $message
                ];
            } else {
                $response['error'] = 'Database error';
            }
        } else {
            $response['error'] = 'File upload failed';
        }
    } elseif (isset($_POST['message']) && !empty(trim($_POST['message']))) {
        // Handle text message
        $message = trim($_POST['message']);
        $stmt = $conn->prepare("INSERT INTO group_chat (sender_id, message) VALUES (?, ?)");
        $stmt->bind_param("is", $_SESSION['user_id'], $message);
        
        if ($stmt->execute()) {
            $response = [
                'success' => true,
                'message' => $message
            ];
        } else {
            $response['error'] = 'Database error';
        }
    } else {
        $response['error'] = 'No content provided';
    }
} catch (Exception $e) {
    $response['error'] = $e->getMessage();
}

// Always return JSON
header('Content-Type: application/json');
echo json_encode($response);
?>