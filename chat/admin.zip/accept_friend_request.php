<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
    exit();
}

$request_id = $_POST['request_id'];

// Update friend request status to 'accepted'
$sql = "UPDATE friend_requests SET status = 'accepted' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $request_id);

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Friend request accepted']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to accept friend request']);
}
?>