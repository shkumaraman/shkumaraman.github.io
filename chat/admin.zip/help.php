<?php
session_start();
include 'db.php'; // Include database connection

// Redirect to login if the user is not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch social media links from the settings table
$query = "SELECT telegram, instagram, email FROM settings LIMIT 1";
$result = $conn->query($query);

// Default values in case database doesn't return anything
$telegram_url = '#';
$instagram_url = '#';
$support_email = '#';

// Fetch data if available
if ($result && $row = $result->fetch_assoc()) {
    $telegram_url = !empty($row['telegram']) ? $row['telegram'] : '#';
    $instagram_url = !empty($row['instagram']) ? $row['instagram'] : '#';
    $support_email = !empty($row['email']) ? $row['email'] : '#';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help and Support</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
        :root {
            --primary-color: #0095f6;
            --secondary-color: #8e8e8e;
            --bg-color: #fafafa;
            --card-bg: #ffffff;
            --border-color: #dbdbdb;
            --text-dark: #262626;
            --text-light: #8e8e8e;
        }

        body {
            background-color: var(--bg-color);
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            min-height: 100vh;
        }

         .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background-color: white;
            color: black;
            padding: 12px 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #dbdbdb;
            z-index: 100;
        }
        .back-btn {
            background: transparent;
            border: none;
            color: var(--text-dark);
            font-size: 20px;
            cursor: pointer;
            padding: 8px;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }
        .back-btn:hover {
            background-color: #f0f0f0;
        }
        
        /* Main Content */
        .container {
            max-width: 600px;
            margin-top: 70px;
            padding: 20px;
        }

        .support-card {
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            border: 1px solid var(--border-color);
        }

        .support-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 15px;
        }

        .support-text {
            color: var(--text-light);
            font-size: 15px;
            line-height: 1.5;
            margin-bottom: 25px;
        }

        /* Button Styles */
        .btn-contact {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s;
            width: 100%;
            margin-bottom: 15px;
            text-decoration: none;
        }

        .btn-telegram {
            background-color: #0088cc;
            color: white;
            border: none;
        }

        .btn-telegram:hover {
            background-color: #0077b5;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 136, 204, 0.2);
        }

        .btn-instagram {
            background: linear-gradient(45deg, #405DE6, #5851DB, #833AB4, #C13584, #E1306C, #FD1D1D);
            color: white;
            border: none;
        }

        .btn-email {
            background-color: #d44638;
            color: white;
            border: none;
        }

        .btn-instagram:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(193, 53, 132, 0.2);
        }

        .btn-email:hover {
            background-color: #c23321;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(212, 70, 56, 0.2);
        }

        .btn-icon {
            margin-right: 10px;
            font-size: 18px;
        }

        /* Responsive Adjustments */
        @media (max-width: 576px) {
            .container {
                padding: 15px;
            }
            
            .support-card {
                padding: 20px;
            }
            
            .support-title {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
<!-- Header with Back Button -->
<div class="header">
    <button class="back-btn" onclick="window.location.href='dashboard.php'">
        <i class="fas fa-arrow-left"></i>
    </button>
    <h4>Help</h4>
    <div style="width: 24px;"></div>
</div>

    <div class="container">
        <div class="support-card">
            <h2 class="support-title">Contact Us for Assistance</h2>
            <p class="support-text">If you have any issues related to payments or need any other support, please contact us through one of our official channels below:</p>

            <div class="d-grid gap-3">
                <a href="<?= htmlspecialchars($telegram_url) ?>" class="btn-contact btn-telegram" target="_blank">
                    <i class="fab fa-telegram btn-icon"></i> Contact on Telegram
                </a>
                <a href="<?= htmlspecialchars($instagram_url) ?>" class="btn-contact btn-instagram" target="_blank">
                    <i class="fab fa-instagram btn-icon"></i> Contact on Instagram
                </a>
                <a href="mailto:<?= htmlspecialchars($support_email) ?>" class="btn-contact btn-email">
                    <i class="fas fa-envelope btn-icon"></i> Email Us
                </a>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>