<?php
// menu.php
include('db.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Get user info using prepared statement
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get connection history with friend status
$history_query = "SELECT 
                    ch.connection_time,
                    u.id AS user_id,
                    u.username,
                    (
                        SELECT COUNT(*) FROM friend_requests 
                        WHERE status = 'accepted' 
                        AND (
                            (sender_id = ? AND receiver_id = u.id) 
                            OR 
                            (sender_id = u.id AND receiver_id = ?)
                        )
                    ) AS is_friend,
                    (
                        SELECT id FROM friend_requests
                        WHERE ((sender_id = ? AND receiver_id = u.id) 
                              OR (sender_id = u.id AND receiver_id = ?))
                        AND status = 'pending'
                        LIMIT 1
                    ) AS pending_request_id,
                    (
                        SELECT sender_id FROM friend_requests
                        WHERE ((sender_id = ? AND receiver_id = u.id) 
                              OR (sender_id = u.id AND receiver_id = ?))
                        AND status = 'pending'
                        LIMIT 1
                    ) AS request_sender_id
                FROM connection_history ch
                JOIN users u ON ch.user2_id = u.id
                WHERE ch.user1_id = ?
                ORDER BY ch.connection_time DESC
                LIMIT 10";

$stmt = $conn->prepare($history_query);
$stmt->bind_param("iiiiiii", $user_id, $user_id, $user_id, $user_id, $user_id, $user_id, $user_id);
$stmt->execute();
$history_result = $stmt->get_result();

$connection_history = [];
if ($history_result->num_rows > 0) {
    while ($row = $history_result->fetch_assoc()) {
        $connection_history[] = [
            'user_id' => $row['user_id'],
            'username' => $row['username'],
            'connection_time' => date("M j, Y g:i A", strtotime($row['connection_time'])),
            'is_friend' => $row['is_friend'] > 0,
            'has_pending_request' => !is_null($row['pending_request_id']),
            'request_id' => $row['pending_request_id'],
            'is_request_sender' => ($row['request_sender_id'] == $user_id),
            'show_accept_button' => (!$row['is_friend'] && !is_null($row['pending_request_id']) && $row['request_sender_id'] != $user_id)
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@latest/css/all.min.css">
    <style>
    :root {
      --primary-color: #0095f6;
      --secondary-color: #8e8e8e;
      --bg-color: #fafafa;
      --card-bg: #ffffff;
      --border-color: #dbdbdb;
      --text-dark: #262626;
      --text-light: #8e8e8e;
      --error-color: #ff4757;
      --premium-color: #ffd700;
      --story-gradient: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888);
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background-color: var(--bg-color);
      margin: 0;
      padding: 0;
      min-height: 100vh;
      position: relative;
      padding-bottom: 80px;
    }

    .header {
      position: fixed;
      top: 0;
      left: 0;
      z-index: 1000;
      width: 100%;
      background: var(--card-bg);
      padding: 12px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--border-color);
      box-shadow: 0 1px 5px rgba(0,0,0,0.05);
    }

    .header .left-section, 
    .header .right-section {
      display: flex;
      gap: 15px;
      align-items: center;
    }

    .header button, 
    .header a {
      background: none;
      border: none;
      color: var(--text-dark);
      font-size: 20px;
      cursor: pointer;
      padding: 8px;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: all 0.3s;
      text-decoration: none !important;
    }

    .header button:hover, 
    .header a:hover {
      background-color: #f0f0f0;
    }

    .notification-btn {
      position: relative;
    }

    .notification-dot {
      position: absolute;
      top: 0;
      right: 2px;
      width: 10px;
      height: 10px;
      background-color: var(--error-color);
      border-radius: 50%;
      border: 2px solid var(--card-bg);
      display: none;
    }

    .notification-bar {
      position: fixed;
      top: 64px;
      left: 0;
      right: 0;
      background-color: var(--primary-color);
      color: white;
      text-align: center;
      padding: 3px 0;
      font-size: 14px;
      z-index: 999;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      display: none;
    }

    .notification-bar a {
      color: white;
      text-decoration: underline;
      margin-left: 8px;
      font-weight: bold;
    }

    .notification-bar.show {
      display: block;
      animation: slideDown 0.3s ease-out;
    }

    .notification-dot.show {
      display: block;
    }

    @keyframes slideDown {
      from { transform: translateY(-100%); }
      to { transform: translateY(0); }
    }

    .slide-menu {
      height: 100%;
      width: 280px;
      position: fixed;
      z-index: 999;
      top: 0;
      left: -280px;
      background-color: var(--card-bg);
      overflow-x: hidden;
      transition: 0.4s;
      padding-top: 70px;
      box-shadow: 2px 0 15px rgba(0,0,0,0.1);
    }

    .slide-menu.open {
      left: 0;
    }

    .slide-menu a {
      padding: 14px 24px;
      text-decoration: none;
      font-size: 16px;
      color: var(--text-dark);
      display: flex;
      align-items: center;
      transition: all 0.3s;
      border-left: 4px solid transparent;
      margin: 4px 0;
      font-weight: 500;
    }

    .slide-menu a i {
      margin-right: 16px;
      width: 20px;
      text-align: center;
      color: var(--secondary-color);
    }

    .slide-menu a:hover {
      background-color: #f5f5f5;
      color: var(--primary-color);
      border-left: 4px solid var(--primary-color);
    }

    .slide-menu a:hover i {
      color: var(--primary-color);
    }

    .buy-premium-btn-container {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      padding: 15px;
      border-top: 1px solid var(--border-color);
      text-align: center;
    }

    .buy-premium-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 20px;
      background-color: var(--premium-color);
      color: #000;
      text-decoration: none;
      border-radius: 30px;
      font-weight: 600;
      transition: all 0.3s;
      width: 90%;
    }

    .buy-premium-btn i {
      margin-right: 8px;
    }

    .buy-premium-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .buy-premium-btn.premium-active {
      background-color: var(--premium-color);
      cursor: default;
    }

    .history-slider {
      height: 100%;
      width: 280px;
      position: fixed;
      z-index: 999;
      top: 0;
      right: -280px;
      background-color: var(--card-bg);
      overflow-x: hidden;
      transition: 0.4s;
      padding-top: 70px;
      box-shadow: -2px 0 15px rgba(0,0,0,0.1);
    }

    .history-slider.open {
      right: 0;
    }

    .history-slider h4 {
      padding: 15px 20px;
      margin: 0;
      border-bottom: 1px solid var(--border-color);
      font-size: 18px;
      font-weight: 600;
      color: var(--text-dark);
    }

    .history-item {
      padding: 10px 20px;
      border-bottom: 1px solid var(--border-color);
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: all 0.3s;
      line-height: 1.3;
    }

    .history-item strong {
      font-weight: 600;
      color: var(--text-dark);
      display: block;
      margin-bottom: 1px;
    }

    .history-item small {
      font-size: 12px;
      color: var(--text-light);
      display: block;
      margin-top: 1px;
    }

    .friend-request-btn {
      background-color: var(--primary-color);
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 8px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
      min-width: 90px;
      text-align: center;
    }

    .friend-request-btn:hover:not(:disabled) {
      background-color: #0077cc;
      transform: translateY(-1px);
    }

    .friend-request-btn:disabled {
      background-color: #dbdbdb;
      color: var(--text-light);
      cursor: not-allowed;
    }

    .bottom-footer {
      position: fixed;
      bottom: 0;
      left: 0;
      width: 100%;
      background-color: var(--card-bg);
      display: flex;
      justify-content: space-around;
      align-items: center;
      padding: 10px 0;
      box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
      z-index: 900;
    }

    .footer-btn {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-decoration: none;
      color: var(--secondary-color);
      font-size: 12px;
      transition: all 0.3s;
      padding: 5px 10px;
    }

    .footer-btn i {
      font-size: 20px;
      margin-bottom: 3px;
    }

    .footer-btn span {
      font-size: 10px;
    }

    .footer-btn:hover {
      color: var(--primary-color);
    }

    .main-btn {
      background: var(--story-gradient);
      color: white !important;
      border-radius: 50%;
      width: 45px;
      height: 45px;
      display: flex;
      justify-content: center;
      align-items: center;
      margin-top: -20px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    .main-btn i {
      font-size: 24px;
      margin-bottom: 0;
    }

    @media (max-width: 768px) {
      body {
        padding-bottom: 80px;
      }
      
      .slide-menu, .history-slider {
        width: 240px;
      }
      
      .slide-menu {
        left: -240px;
      }
      
      .history-slider {
        right: -240px;
      }
      
      .footer-btn span {
        display: none;
      }
      
      .footer-btn i {
        font-size: 24px;
      }
      
      .main-btn {
        width: 50px;
        height: 50px;
      }
    }
    </style>
</head>
<body>
    <!-- Header Section -->
    <div class="header">
        <div class="left-section">
            <button class="menu-btn" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div class="right-section">
            <a href="notification.php" class="notification-btn">
                <i class="fa-solid fa-bell"></i>
                <span class="notification-dot"></span>
            </a>
            <button class="history-btn" onclick="toggleHistory()">
                <i class="fa-solid fa-clock-rotate-left"></i>
            </button>
        </div>
    </div>

    <!-- Notification bar below header -->
    <div class="notification-bar">
        You have new friend requests! <a href="notification.php">View</a>
    </div>

    <!-- The Slide Menu -->
    <div id="slideMenu" class="slide-menu">
        <a href="dashboard.php"><i class="fas fa-home"></i> Home</a>
        <a href="friends.php"><i class="fas fa-user-friends"></i> Friends</a>
        <a href="broadcast.php"><i class="fas fa-bullhorn"></i> Broadcast</a>
        <a href="plan.php"><i class="fas fa-clipboard-list"></i> Plan</a>
        <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
        <a href="help.php"><i class="fas fa-question-circle"></i> Help</a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Log Out</a>
        
        <!-- Buy Premium Button -->
        <div class="buy-premium-btn-container">
            <a href="<?php echo ($user['premium'] == 0) ? 'plan.php' : 'javascript:void(0);'; ?>" 
               class="buy-premium-btn <?php echo ($user['premium'] == 1) ? 'premium-active' : ''; ?>">
                <i class="fa-solid fa-crown"></i>
                <?php echo ($user['premium'] == 0) ? 'Buy Premium' : 'Premium'; ?>
            </a>
        </div>
    </div>

    <!-- History Slider -->
    <div id="historySlider" class="history-slider">
        <h4>Connection History</h4>
        <div id="historyContent">
            <?php if (!empty($connection_history)): ?>
                <?php foreach ($connection_history as $item): ?>
                    <div class="history-item" data-user-id="<?= $item['user_id'] ?>" <?= $item['request_id'] ? 'data-request-id="'.$item['request_id'].'"' : '' ?>>
                        <div>
                            <strong><?= htmlspecialchars($item['username']) ?></strong>
                            <small>Connected: <?= htmlspecialchars($item['connection_time']) ?></small>
                            <?php if ($item['is_friend']): ?>
                                <small>Status: Friends</small>
                            <?php endif; ?>
                        </div>
                        <div>
                            <?php if ($item['is_friend']): ?>
                                <button class="friend-request-btn" disabled>Friends</button>
                            <?php elseif ($item['show_accept_button']): ?>
                                <button class="friend-request-btn" onclick="acceptFriendRequest(<?= $item['user_id'] ?>, this)">Accept</button>
                            <?php elseif ($item['has_pending_request'] && $item['is_request_sender']): ?>
                                <button class="friend-request-btn" disabled>Request Sent</button>
                            <?php elseif ($item['has_pending_request']): ?>
                                <button class="friend-request-btn" disabled>Pending</button>
                            <?php else: ?>
                                <button class="friend-request-btn" onclick="sendFriendRequest(<?= $item['user_id'] ?>, this)">Add Friend</button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="history-item">
                    <p>No connection history found.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bottom Footer -->
    <div class="bottom-footer">
        <a href="dashboard.php" class="footer-btn">
            <i class="fas fa-home"></i>
            <span>Home</span>
        </a>
        <a href="story.php" class="footer-btn">
            <i class="fas fa-circle-play"></i>
            <span>Stories</span>
        </a>
        <a href="voice.php" class="footer-btn main-btn">
            <i class="fas fa-microphone"></i>
        </a>
        <a href="feed.php" class="footer-btn">
            <i class="fas fa-newspaper"></i>
            <span>Feed</span>
        </a>
        <a href="settings.php" class="footer-btn">
            <i class="fas fa-cog"></i>
            <span>Settings</span>
        </a>
    </div>

    <!-- Bootstrap Bundle JS (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@latest/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        // DOM Elements
        const slideMenu = document.getElementById("slideMenu");
        const historySlider = document.getElementById("historySlider");
        const notificationDot = document.querySelector(".notification-dot");
        const notificationBar = document.querySelector(".notification-bar");
        
        // Toggle menu and history slider
        function toggleMenu() {
            slideMenu.classList.toggle("open");
            historySlider.classList.remove("open");
        }
        
        function toggleHistory() {
            historySlider.classList.toggle("open");
            slideMenu.classList.remove("open");
        }
        
        // Close sliders when clicking outside
        document.addEventListener("click", function(e) {
            if (!e.target.closest("#slideMenu") && !e.target.closest(".menu-btn") && slideMenu.classList.contains("open")) {
                slideMenu.classList.remove("open");
            }
            if (!e.target.closest("#historySlider") && !e.target.closest(".history-btn") && historySlider.classList.contains("open")) {
                historySlider.classList.remove("open");
            }
        });
        
        // Friend Request Functions
        function sendFriendRequest(userId, btn) {
            fetch("send_friend_request.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `receiver_id=${userId}`,
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === "success") {
                        btn.textContent = "Request Sent";
                        btn.disabled = true;
                        checkNewNotifications();
                    } else {
                        alert("Error: " + data.message);
                    }
                })
                .catch(error => {
                    console.error("Error sending friend request:", error);
                });
        }
        
        function acceptFriendRequest(userId, btn) {
            const historyItem = btn.closest(".history-item");
            const requestId = historyItem ? historyItem.getAttribute("data-request-id") : null;
            
            if (!requestId) {
                alert("Invalid request.");
                return;
            }
            
            fetch("accept_friend_request.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `request_id=${requestId}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    btn.textContent = "✓ Friends";
                    btn.style.backgroundColor = "#28a745";
                    btn.disabled = true;
                    btn.onclick = null;
                    checkNewNotifications();
                    
                    // Add status text if not already present
                    if (!historyItem.querySelector("small:last-child").textContent.includes("Status")) {
                        const statusElement = document.createElement("small");
                        statusElement.textContent = "Status: Friends";
                        historyItem.querySelector("div").appendChild(statusElement);
                    }
                } else {
                    alert("Error: " + (data.message || "Failed to accept request"));
                }
            })
            .catch(error => {
                console.error("Error:", error);
                alert("Failed to accept request. Please try again.");
            });
        }
        
// Notification Functions
function checkNewNotifications() {
    fetch("check_notifications.php")
        .then(response => response.json())
        .then(data => {
            // Check if there are any new notifications
            const hasAlerts = data.hasPendingRequests || 
                            data.hasNewNotifications || 
                            data.latestReactions.length > 0 || 
                            data.storyLikes.length > 0 ||
                            data.commentReplies.length > 0;

            // Show or hide the red dot on the bell icon
            if (hasAlerts) {
                notificationDot.classList.add("show");
            } else {
                notificationDot.classList.remove("show");
            }

            // If there are new notifications, show the generic message
            if (hasAlerts) {
                notificationBar.style.display = "block";
                
                // Check for specific notification types to show more detailed messages
                if (data.hasPendingRequests) {
                    notificationBar.innerHTML = `You have new friend requests. <a href="notification.php">View</a>`;
                } else if (data.commentReplies.length > 0) {
                    const replyCount = data.commentReplies.length;
                    notificationBar.innerHTML = `You have ${replyCount} new ${replyCount === 1 ? 'reply' : 'replies'} to your comments. <a href="notification.php">View</a>`;
                } else if (data.latestReactions.length > 0) {
                    const reaction = data.latestReactions[0];
                    const username = reaction.username;
                    const type = reaction.reaction_type === 'like' ? 'liked' : 'commented on';
                    notificationBar.innerHTML = `${username} ${type} your post. <a href="notification.php">View</a>`;
                } else if (data.storyLikes.length > 0) {
                    const like = data.storyLikes[0];
                    notificationBar.innerHTML = `${like.username} liked your story. <a href="notification.php">View</a>`;
                } else {
                    notificationBar.innerHTML = `You have new notifications. <a href="notification.php">View</a>`;
                }
            } else {
                notificationBar.style.display = "none";
            }
        })
        .catch(error => {
            console.error("Error checking notifications:", error);
        });
}

// Call immediately and then every 30 seconds
checkNewNotifications();
setInterval(checkNewNotifications, 30000);

        // User Status Functions
        function updateUserStatus(status) {
            fetch("update_status.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `status=${status}`,
                keepalive: true
            }).catch(error => {
                console.error("Error updating status:", error);
            });
        }
        
        // Set online status when page loads
        updateUserStatus(1);
        
        // Set offline status when page unloads
        window.addEventListener("beforeunload", function() {
            updateUserStatus(0);
        });
        
        // Handle pagehide event for mobile/browser compatibility
        window.addEventListener("pagehide", function() {
            updateUserStatus(0);
        });
        
        // Handle tab visibility changes
        document.addEventListener("visibilitychange", function() {
            if (document.visibilityState === "hidden") {
                updateUserStatus(0);
            } else {
                updateUserStatus(1);
            }
        });
        
        // Expose functions to global scope
        window.toggleMenu = toggleMenu;
        window.toggleHistory = toggleHistory;
        window.sendFriendRequest = sendFriendRequest;
        window.acceptFriendRequest = acceptFriendRequest;
    });
    </script>
</body>
</html>